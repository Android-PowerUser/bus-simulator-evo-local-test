package android.support.v4.media.session;

import android.content.Context;
import android.os.RemoteException;
import androidx.annotation.RequiresApi;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@RequiresApi(24)
class MediaControllerCompat$MediaControllerImplApi24 extends MediaControllerCompat$MediaControllerImplApi23 {
    public MediaControllerCompat$MediaControllerImplApi24(final Context context, final MediaSessionCompat.Token token) throws RemoteException {
        new MediaControllerCompat$MediaControllerImplApi21(context, token) { // from class: android.support.v4.media.session.MediaControllerCompat$MediaControllerImplApi23
            @Override // android.support.v4.media.session.MediaControllerCompat$MediaControllerImplApi21
            public MediaControllerCompat.TransportControls getTransportControls() {
                Object transportControls = MediaControllerCompatApi21.getTransportControls(this.mControllerObj);
                if (transportControls != null) {
                    return new MediaControllerCompat.TransportControlsApi23(transportControls);
                }
                return null;
            }
        };
    }

    @Override // android.support.v4.media.session.MediaControllerCompat$MediaControllerImplApi23, android.support.v4.media.session.MediaControllerCompat$MediaControllerImplApi21
    public MediaControllerCompat.TransportControls getTransportControls() {
        Object transportControls = MediaControllerCompatApi21.getTransportControls(this.mControllerObj);
        if (transportControls != null) {
            return new MediaControllerCompat.TransportControlsApi24(transportControls);
        }
        return null;
    }
}
