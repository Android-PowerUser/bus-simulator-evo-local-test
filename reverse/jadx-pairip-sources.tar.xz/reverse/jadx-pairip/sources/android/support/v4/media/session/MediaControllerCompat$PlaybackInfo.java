package android.support.v4.media.session;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class MediaControllerCompat$PlaybackInfo {
    public static final int PLAYBACK_TYPE_LOCAL = 1;
    public static final int PLAYBACK_TYPE_REMOTE = 2;
    private final int mAudioStream;
    private final int mCurrentVolume;
    private final int mMaxVolume;
    private final int mPlaybackType;
    private final int mVolumeControl;

    MediaControllerCompat$PlaybackInfo(int i, int i2, int i3, int i4, int i5) {
        this.mPlaybackType = i;
        this.mAudioStream = i2;
        this.mVolumeControl = i3;
        this.mMaxVolume = i4;
        this.mCurrentVolume = i5;
    }

    public int getPlaybackType() {
        return this.mPlaybackType;
    }

    public int getAudioStream() {
        return this.mAudioStream;
    }

    public int getVolumeControl() {
        return this.mVolumeControl;
    }

    public int getMaxVolume() {
        return this.mMaxVolume;
    }

    public int getCurrentVolume() {
        return this.mCurrentVolume;
    }
}
