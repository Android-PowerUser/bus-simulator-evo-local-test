package io.bidmachine.banner;

import androidx.annotation.NonNull;
import io.bidmachine.AdRequest;
import io.bidmachine.BannerAdSize;
import io.bidmachine.TargetingParams;
import io.bidmachine.models.DataRestrictions;
import io.bidmachine.unified.UnifiedBannerAdRequestParams;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class BannerRequest extends AdRequest<BannerRequest, BannerAdRequestParameters, UnifiedBannerAdRequestParams> {
    private BannerRequest(@NonNull BannerAdRequestParameters bannerAdRequestParameters) {
        super(bannerAdRequestParameters);
    }

    @NonNull
    public BannerAdSize getBannerAdSize() {
        return getAdRequestParameters().getBannerAdSize();
    }

    @Deprecated(since = "3.5.0")
    public BannerSize getSize() {
        return BannerSize.fromBannerAdSize(getBannerAdSize());
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @NonNull
    public UnifiedBannerAdRequestParams createUnifiedAdRequestParams(@NonNull BannerAdRequestParameters adRequestParameters, @NonNull TargetingParams targetingParams, @NonNull DataRestrictions dataRestrictions) {
        return new BannerUnifiedAdRequestParams(adRequestParameters, targetingParams, dataRestrictions, (1) null);
    }
}
