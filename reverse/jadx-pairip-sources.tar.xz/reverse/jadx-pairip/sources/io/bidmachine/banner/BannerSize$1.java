package io.bidmachine.banner;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
/* synthetic */ class BannerSize$1 {
    static final /* synthetic */ int[] $SwitchMap$io$bidmachine$banner$BannerSize;

    static {
        int[] iArr = new int[BannerSize.values().length];
        $SwitchMap$io$bidmachine$banner$BannerSize = iArr;
        try {
            iArr[BannerSize.Size_300x250.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            $SwitchMap$io$bidmachine$banner$BannerSize[BannerSize.Size_728x90.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
    }
}
