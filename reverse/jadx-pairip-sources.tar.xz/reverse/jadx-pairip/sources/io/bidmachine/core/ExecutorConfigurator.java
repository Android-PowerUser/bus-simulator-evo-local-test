package io.bidmachine.core;

import androidx.annotation.FloatRange;
import androidx.annotation.VisibleForTesting;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class ExecutorConfigurator {

    @VisibleForTesting
    public static final float DEFAULT_CPU_USAGE_FRACTION = 0.25f;

    @VisibleForTesting
    public static final float DEFAULT_SERVICE_TIME_RATIO = 0.100000024f;

    @VisibleForTesting
    public static final float DEFAULT_WAIT_TIME_RATIO = 0.9f;

    @VisibleForTesting
    public static final float MIN_CPU_USAGE_FRACTION = 1.0E-4f;
    private final int corePoolSize;
    private final int maximumPoolSize;

    public ExecutorConfigurator() {
        this(0.25f, 0.9f);
    }

    public ExecutorConfigurator(@FloatRange(from = 0.0d, to = 1.0d) float cpuUsageFraction) {
        this(cpuUsageFraction, 0.9f);
    }

    public ExecutorConfigurator(@FloatRange(from = 0.0d, to = 1.0d) float cpuUsageFraction, @FloatRange(from = 0.0d, to = 1.0d) float waitTimeRatio) {
        float fEnsureMinimumCpuUsage = ensureMinimumCpuUsage(cpuUsageFraction);
        float fEnsureValidWaitTimeRatio = ensureValidWaitTimeRatio(waitTimeRatio);
        int iCalculateCorePoolSize = calculateCorePoolSize(availableProcessors(), fEnsureMinimumCpuUsage);
        this.corePoolSize = iCalculateCorePoolSize;
        this.maximumPoolSize = calculateMaximumPoolSize(iCalculateCorePoolSize, 1.0f - fEnsureValidWaitTimeRatio, fEnsureValidWaitTimeRatio);
    }

    public int getCorePoolSize() {
        return this.corePoolSize;
    }

    public int getMaximumPoolSize() {
        return this.maximumPoolSize;
    }

    @VisibleForTesting
    int availableProcessors() {
        return Runtime.getRuntime().availableProcessors();
    }

    @VisibleForTesting
    static float ensureMinimumCpuUsage(float cpuUsageFraction) {
        return Math.max(cpuUsageFraction, 1.0E-4f);
    }

    @VisibleForTesting
    static float ensureValidWaitTimeRatio(float waitTimeRatio) {
        return Math.max(0.0f, Math.min(1.0f, waitTimeRatio));
    }

    @VisibleForTesting
    static int calculateCorePoolSize(int availableProcessors, float cpuUsageFraction) {
        return Math.max(1, Math.round(availableProcessors * cpuUsageFraction));
    }

    @VisibleForTesting
    static int calculateMaximumPoolSize(int corePoolSize, float serviceTimeRatio, float waitTimeRatio) {
        if (serviceTimeRatio <= 0.0f) {
            return Integer.MAX_VALUE;
        }
        return Math.round(corePoolSize * ((waitTimeRatio / serviceTimeRatio) + 1.0f));
    }
}
