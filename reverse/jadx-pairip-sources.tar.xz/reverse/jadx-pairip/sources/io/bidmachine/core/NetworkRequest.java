package io.bidmachine.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.explorestack.protobuf.AbstractMessage;
import com.safedk.android.internal.partials.BidMachineNetworkBridge;
import io.bidmachine.media3.extractor.MpegAudioUtil;
import io.bidmachine.util.network.NetworkUtils;
import io.bidmachine.util.taskmanager.TaskManager;
import io.bidmachine.util.taskmanager.coroutine.NetworkTaskManager;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public abstract class NetworkRequest<RequestDataType, RequestResultType, ErrorResultType> {

    @NonNull
    private static final TaskManager TASK_MANAGER = new NetworkTaskManager();

    @Nullable
    private Callback<RequestResultType, ErrorResultType> callback;

    @Nullable
    private CancelCallback cancelCallback;

    @Nullable
    private ArrayList<RequestDataEncoder<RequestDataType, RequestResultType, ErrorResultType>> contentEncoders;

    @Nullable
    private URLConnection currentConnection;
    private State currentState = State.Idle;

    @Nullable
    private RequestDataBinder<RequestDataType, RequestResultType, ErrorResultType> dataBinder;

    @Nullable
    private ArrayList<RequestDataEncoder<RequestDataType, RequestResultType, ErrorResultType>> dataEncoders;

    @Nullable
    private ErrorResultType errorResult;

    @NonNull
    private final Method method;

    @Nullable
    private final String path;

    @Nullable
    private final RequestDataType requestData;

    @Nullable
    private RequestResultType requestResult;

    public interface CancelCallback {
        void onCanceled();
    }

    protected String getBaseUrl() throws Exception {
        return "TODO: implement url";
    }

    @NonNull
    protected abstract ErrorResultType obtainError(@Nullable URLConnection connection, int responseCode);

    @NonNull
    protected abstract ErrorResultType obtainError(@Nullable URLConnection connection, @Nullable Throwable t);

    public NetworkRequest(@NonNull Method method, @Nullable String path, @Nullable RequestDataType requestData) {
        this.method = method;
        this.path = path;
        this.requestData = requestData;
    }

    public void setDataBinder(@Nullable RequestDataBinder<RequestDataType, RequestResultType, ErrorResultType> dataBinder) {
        this.dataBinder = dataBinder;
    }

    public void addDataEncoder(RequestDataEncoder<RequestDataType, RequestResultType, ErrorResultType> encoder) {
        if (this.dataEncoders == null) {
            this.dataEncoders = new ArrayList<>();
        }
        this.dataEncoders.add(encoder);
    }

    public void addContentEncoder(RequestDataEncoder<RequestDataType, RequestResultType, ErrorResultType> encoder) {
        if (this.contentEncoders == null) {
            this.contentEncoders = new ArrayList<>();
        }
        this.contentEncoders.add(encoder);
    }

    public void setCallback(@Nullable Callback<RequestResultType, ErrorResultType> callback) {
        this.callback = callback;
    }

    public void setCancelCallback(@Nullable CancelCallback cancelCallback) {
        this.cancelCallback = cancelCallback;
    }

    @NonNull
    public Method getMethod() {
        return this.method;
    }

    @Nullable
    public String getPath() {
        return this.path;
    }

    public void request() {
        request(TASK_MANAGER);
    }

    public void request(@NonNull TaskManager taskManager) {
        try {
            taskManager.execute(new NetworkRequestRunner(this, (1) null));
        } catch (Throwable th) {
            Logger.w(th);
            Callback<RequestResultType, ErrorResultType> callback = this.callback;
            if (callback != null) {
                callback.onFail(obtainError((URLConnection) null, th));
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code duplicated, block: B:84:0x0142  */
    /* JADX WARN: Undo finally extract visitor
    java.lang.NullPointerException: Cannot invoke "Object.hashCode()" because "this.second" is null
    	at jadx.core.utils.Pair.hashCode(Pair.java:35)
    	at java.base/java.util.HashMap.hash(HashMap.java:338)
    	at java.base/java.util.HashMap.getNode(HashMap.java:576)
    	at java.base/java.util.HashMap.containsKey(HashMap.java:602)
    	at jadx.core.dex.visitors.finaly.traverser.state.TraverserGlobalCommonState.hasBlocksBeenCached(TraverserGlobalCommonState.java:35)
    	at jadx.core.dex.visitors.finaly.traverser.handlers.MergePathActivePathTraverserHandler.handle(MergePathActivePathTraverserHandler.java:174)
    	at jadx.core.dex.visitors.finaly.traverser.handlers.AbstractActivePathTraverserHandler.process(AbstractActivePathTraverserHandler.java:19)
    	at jadx.core.dex.visitors.finaly.traverser.TraverserController.processHandlerImplementations(TraverserController.java:43)
    	at jadx.core.dex.visitors.finaly.traverser.TraverserController.advance(TraverserController.java:156)
    	at jadx.core.dex.visitors.finaly.traverser.TraverserController.process(TraverserController.java:79)
    	at jadx.core.dex.visitors.finaly.traverser.handlers.MergePathActivePathTraverserHandler.handle(MergePathActivePathTraverserHandler.java:158)
    	at jadx.core.dex.visitors.finaly.traverser.handlers.AbstractActivePathTraverserHandler.process(AbstractActivePathTraverserHandler.java:19)
    	at jadx.core.dex.visitors.finaly.traverser.TraverserController.processHandlerImplementations(TraverserController.java:43)
    	at jadx.core.dex.visitors.finaly.traverser.TraverserController.advance(TraverserController.java:156)
    	at jadx.core.dex.visitors.finaly.traverser.TraverserController.process(TraverserController.java:79)
    	at jadx.core.dex.visitors.finaly.MarkFinallyVisitor.findCommonInsns(MarkFinallyVisitor.java:404)
    	at jadx.core.dex.visitors.finaly.MarkFinallyVisitor.extractFinally(MarkFinallyVisitor.java:284)
    	at jadx.core.dex.visitors.finaly.MarkFinallyVisitor.processTryBlock(MarkFinallyVisitor.java:202)
    	at jadx.core.dex.visitors.finaly.MarkFinallyVisitor.visit(MarkFinallyVisitor.java:135)
     */
    public void process() {
        URLConnection uRLConnection;
        State state;
        URL url;
        InputStream inputStream;
        ByteArrayOutputStream byteArrayOutputStream;
        InputStream inputStreamUrlConnectionGetInputStream;
        ByteArrayOutputStream byteArrayOutputStream2;
        RequestDataBinder<RequestDataType, RequestResultType, ErrorResultType> requestDataBinder;
        BufferedOutputStream bufferedOutputStream;
        this.currentState = State.Running;
        try {
            if (this.path != null) {
                url = new URL(getBaseUrl() + "/" + this.path);
            } else {
                url = new URL(getBaseUrl());
            }
            URLConnection uRLConnectionOpenConnection = url.openConnection();
            try {
                this.currentConnection = uRLConnectionOpenConnection;
                this.method.apply(uRLConnectionOpenConnection);
                prepareRequestParams(uRLConnectionOpenConnection);
                byte[] bArrObtainRequestData = obtainRequestData(uRLConnectionOpenConnection);
                if (bArrObtainRequestData != null) {
                    byte[] bArrEncodeRequestData = encodeRequestData(uRLConnectionOpenConnection, bArrObtainRequestData);
                    uRLConnectionOpenConnection.setDoOutput(true);
                    try {
                        bufferedOutputStream = new BufferedOutputStream(BidMachineNetworkBridge.urlConnectionGetOutputStream(uRLConnectionOpenConnection));
                        try {
                            bufferedOutputStream.write(bArrEncodeRequestData);
                            Utils.flush(bufferedOutputStream);
                            Utils.close(bufferedOutputStream);
                        } catch (Throwable th) {
                            th = th;
                            Utils.flush(bufferedOutputStream);
                            Utils.close(bufferedOutputStream);
                            throw th;
                        }
                    } catch (Throwable th2) {
                        th = th2;
                        bufferedOutputStream = null;
                    }
                }
                try {
                    int iObtainResponseCode = obtainResponseCode(uRLConnectionOpenConnection);
                    if (isCanceled()) {
                        Utils.flush((Flushable) null);
                        Utils.close((Closeable) null);
                        Utils.close((Closeable) null);
                        if (uRLConnectionOpenConnection instanceof HttpURLConnection) {
                            BidMachineNetworkBridge.httpUrlConnectionDisconnect((HttpURLConnection) uRLConnectionOpenConnection);
                        }
                        this.currentConnection = null;
                        if (isCanceled()) {
                            return;
                        }
                        this.currentState = this.errorResult == null ? State.Success : State.Fail;
                        return;
                    }
                    if (iObtainResponseCode != 200) {
                        this.errorResult = obtainError(uRLConnectionOpenConnection, iObtainResponseCode);
                        inputStreamUrlConnectionGetInputStream = null;
                        byteArrayOutputStream2 = null;
                    } else {
                        inputStreamUrlConnectionGetInputStream = BidMachineNetworkBridge.urlConnectionGetInputStream(uRLConnectionOpenConnection);
                        try {
                            byteArrayOutputStream2 = new ByteArrayOutputStream();
                            try {
                                byte[] bArr = new byte[1024];
                                while (true) {
                                    int i = inputStreamUrlConnectionGetInputStream.read(bArr);
                                    if (i == -1) {
                                        break;
                                    } else {
                                        byteArrayOutputStream2.write(bArr, 0, i);
                                    }
                                }
                                byte[] byteArray = byteArrayOutputStream2.toByteArray();
                                if (byteArray != null) {
                                    byteArray = decodeResponseData(uRLConnectionOpenConnection, byteArray);
                                }
                                if (byteArray != null && byteArray.length > 0 && (requestDataBinder = this.dataBinder) != null) {
                                    RequestResultType requestresulttype = (RequestResultType) requestDataBinder.createSuccessResult(this, uRLConnectionOpenConnection, byteArray);
                                    this.requestResult = requestresulttype;
                                    if (requestresulttype == null) {
                                        this.errorResult = (ErrorResultType) this.dataBinder.createFailResult(this, uRLConnectionOpenConnection, byteArray);
                                    }
                                }
                            } catch (Throwable th3) {
                                inputStream = inputStreamUrlConnectionGetInputStream;
                                th = th3;
                                byteArrayOutputStream = byteArrayOutputStream2;
                                Utils.flush(byteArrayOutputStream);
                                Utils.close(byteArrayOutputStream);
                                Utils.close(inputStream);
                                throw th;
                            }
                        } catch (Throwable th4) {
                            byteArrayOutputStream = null;
                            inputStream = inputStreamUrlConnectionGetInputStream;
                            th = th4;
                        }
                    }
                    Utils.flush(byteArrayOutputStream2);
                    Utils.close(byteArrayOutputStream2);
                    Utils.close(inputStreamUrlConnectionGetInputStream);
                    if (uRLConnectionOpenConnection instanceof HttpURLConnection) {
                        BidMachineNetworkBridge.httpUrlConnectionDisconnect((HttpURLConnection) uRLConnectionOpenConnection);
                    }
                    this.currentConnection = null;
                    if (isCanceled()) {
                        return;
                    }
                    if (this.errorResult == null) {
                        state = State.Success;
                    } else {
                        state = State.Fail;
                    }
                    this.currentState = state;
                } catch (Throwable th5) {
                    th = th5;
                    inputStream = null;
                    byteArrayOutputStream = null;
                }
            } catch (Throwable th6) {
                uRLConnection = uRLConnectionOpenConnection;
                th = th6;
                try {
                    Logger.w(th);
                    this.errorResult = obtainError(uRLConnection, th);
                    if (uRLConnection instanceof HttpURLConnection) {
                        BidMachineNetworkBridge.httpUrlConnectionDisconnect((HttpURLConnection) uRLConnection);
                    }
                    this.currentConnection = null;
                    if (isCanceled()) {
                        return;
                    }
                    if (this.errorResult == null) {
                        state = State.Success;
                    }
                    this.currentState = state;
                } catch (Throwable th7) {
                    if (uRLConnection instanceof HttpURLConnection) {
                        BidMachineNetworkBridge.httpUrlConnectionDisconnect((HttpURLConnection) uRLConnection);
                    }
                    this.currentConnection = null;
                    if (!isCanceled()) {
                        this.currentState = this.errorResult == null ? State.Success : State.Fail;
                    }
                    throw th7;
                }
            }
        } catch (Throwable th8) {
            th = th8;
            uRLConnection = null;
        }
    }

    protected void prepareRequestParams(URLConnection connection) {
        connection.setConnectTimeout(MpegAudioUtil.MAX_RATE_BYTES_PER_SECOND);
        connection.setReadTimeout(MpegAudioUtil.MAX_RATE_BYTES_PER_SECOND);
    }

    protected byte[] obtainRequestData(URLConnection connection) throws Exception {
        RequestDataBinder<RequestDataType, RequestResultType, ErrorResultType> requestDataBinder = this.dataBinder;
        if (requestDataBinder == null) {
            return null;
        }
        requestDataBinder.prepareRequest(this, connection);
        this.dataBinder.prepareHeaders(this, connection);
        return this.dataBinder.obtainData(this, connection, this.requestData);
    }

    protected byte[] encodeRequestData(URLConnection connection, byte[] requestData) throws Exception {
        ArrayList<RequestDataEncoder<RequestDataType, RequestResultType, ErrorResultType>> arrayList = this.dataEncoders;
        if (arrayList != null) {
            for (RequestDataEncoder<RequestDataType, RequestResultType, ErrorResultType> requestDataEncoder : arrayList) {
                requestDataEncoder.prepareHeaders(this, connection);
                requestData = requestDataEncoder.encode(this, connection, requestData);
            }
        }
        ArrayList<RequestDataEncoder<RequestDataType, RequestResultType, ErrorResultType>> arrayList2 = this.contentEncoders;
        if (arrayList2 != null) {
            for (RequestDataEncoder<RequestDataType, RequestResultType, ErrorResultType> requestDataEncoder2 : arrayList2) {
                requestDataEncoder2.prepareHeaders(this, connection);
                requestData = requestDataEncoder2.encode(this, connection, requestData);
            }
        }
        return requestData;
    }

    protected byte[] decodeResponseData(URLConnection connection, byte[] responseData) throws Exception {
        ArrayList<RequestDataEncoder<RequestDataType, RequestResultType, ErrorResultType>> arrayList = this.contentEncoders;
        if (arrayList != null) {
            Iterator<RequestDataEncoder<RequestDataType, RequestResultType, ErrorResultType>> it = arrayList.iterator();
            while (it.hasNext()) {
                responseData = it.next().decode(this, connection, responseData);
            }
        }
        ArrayList<RequestDataEncoder<RequestDataType, RequestResultType, ErrorResultType>> arrayList2 = this.dataEncoders;
        if (arrayList2 != null) {
            Iterator<RequestDataEncoder<RequestDataType, RequestResultType, ErrorResultType>> it2 = arrayList2.iterator();
            while (it2.hasNext()) {
                responseData = it2.next().decode(this, connection, responseData);
            }
        }
        return responseData;
    }

    private int obtainResponseCode(URLConnection connection) throws IOException {
        if (connection instanceof HttpURLConnection) {
            return BidMachineNetworkBridge.httpUrlConnectionGetResponseCode((HttpURLConnection) connection);
        }
        return -1;
    }

    private InputStream obtainErrorStream(URLConnection connection) {
        if (connection instanceof HttpURLConnection) {
            return ((HttpURLConnection) connection).getErrorStream();
        }
        return null;
    }

    public void cancel() {
        this.currentState = State.Canceled;
        CancelCallback cancelCallback = this.cancelCallback;
        if (cancelCallback != null) {
            cancelCallback.onCanceled();
        }
    }

    public boolean isCanceled() {
        return this.currentState == State.Canceled;
    }

    static abstract class ProtobufDataBinder<RequestDataType extends AbstractMessage, RequestResultType, ErrorResultType> extends RequestDataBinder<RequestDataType, RequestResultType, ErrorResultType> {
        ProtobufDataBinder() {
        }

        @Nullable
        protected /* bridge */ /* synthetic */ byte[] obtainData(NetworkRequest request, URLConnection connection, Object requestData) throws Exception {
            return obtainData((NetworkRequest<AbstractMessage, RequestResultType, ErrorResultType>) request, connection, (AbstractMessage) requestData);
        }

        protected void prepareHeaders(NetworkRequest<RequestDataType, RequestResultType, ErrorResultType> request, URLConnection connection) {
            connection.setRequestProperty(NetworkUtils.HEADER_CONTENT_TYPE, "application/x-protobuf");
        }

        @Nullable
        protected byte[] obtainData(NetworkRequest<RequestDataType, RequestResultType, ErrorResultType> request, URLConnection connection, RequestDataType requestData) {
            if (requestData != null) {
                return requestData.toByteArray();
            }
            return null;
        }
    }

    public static class SimpleJsonArrayDataBinder<ErrorResultType> extends JsonDataBinder<JSONArray, ErrorResultType> {
        /* JADX INFO: Access modifiers changed from: protected */
        public JSONArray createSuccessResult(NetworkRequest<JSONObject, JSONArray, ErrorResultType> request, URLConnection connection, byte[] resultData) throws Exception {
            return new JSONArray(new String(resultData));
        }
    }
}
