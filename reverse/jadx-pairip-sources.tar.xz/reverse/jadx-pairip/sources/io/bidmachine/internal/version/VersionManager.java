package io.bidmachine.internal.version;

import android.content.Context;
import io.bidmachine.BidMachineSharedPreferenceKt;
import io.bidmachine.SessionManagerKtWrapper;
import io.bidmachine.core.Logger;
import io.bidmachine.util.version.Version;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: VersionManager.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0006\b\u0000\u0018\u0000 \u00172\u00020\u0001:\u0001\u0017B\u0015\u0012\u000e\b\u0002\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\u0002\u0010\u0005J\u001a\u0010\u0006\u001a\u0004\u0018\u00010\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0002J\u0018\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\u0004H\u0002J\u0018\u0010\u0010\u001a\u00020\r2\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\u0011\u001a\u00020\u0012H\u0002J\u0016\u0010\u0013\u001a\u00020\r2\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bJ\u0016\u0010\u0014\u001a\u00020\r2\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bJ\"\u0010\u0015\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\u00042\b\u0010\u0016\u001a\u0004\u0018\u00010\u0004H\u0002R\u0014\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0018"}, d2 = {"Lio/bidmachine/internal/version/VersionManager;", "", "currentVersionProvider", "Lkotlin/Function0;", "Lio/bidmachine/util/version/Version;", "(Lkotlin/jvm/functions/Function0;)V", "checkAndGetCurrentVersionMilestone", "Lio/bidmachine/internal/version/VersionMilestone;", "context", "Landroid/content/Context;", "sessionManager", "Lio/bidmachine/SessionManagerKtWrapper;", "onDowngrade", "", "from", "to", "onInstall", "installTime", "", "onSessionPaused", "onSessionStarted", "onUpgrade", "lastMaxVersion", "Companion", "bidmachine-android-sdk_bh_3_5_1"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class VersionManager {

    @NotNull
    public static final Companion Companion = new Companion((DefaultConstructorMarker) null);

    @NotNull
    private static final String TAG = "VersionManager";

    @NotNull
    private final Function0<Version> currentVersionProvider;

    /* JADX WARN: Illegal instructions before constructor call */
    public VersionManager() {
        Function0 function0 = null;
        this(function0, 1, function0);
    }

    public VersionManager(@NotNull Function0<Version> function0) {
        Intrinsics.checkNotNullParameter(function0, "currentVersionProvider");
        this.currentVersionProvider = function0;
    }

    public /* synthetic */ VersionManager(Function0 function0, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? 1.INSTANCE : function0);
    }

    private final VersionMilestone checkAndGetCurrentVersionMilestone(Context context, SessionManagerKtWrapper sessionManager) {
        Version version;
        Version version2 = (Version) this.currentVersionProvider.invoke();
        BidMachineSharedPreferenceKt bidMachineSharedPreferenceKt = BidMachineSharedPreferenceKt.INSTANCE;
        List historyVersionMilestoneList = bidMachineSharedPreferenceKt.getHistoryVersionMilestoneList(context);
        VersionMilestone currentVersionMilestone = bidMachineSharedPreferenceKt.getCurrentVersionMilestone(context);
        Object next = null;
        Version version3 = currentVersionMilestone != null ? currentVersionMilestone.getVersion() : null;
        if (Intrinsics.areEqual(version2, version3)) {
            return currentVersionMilestone;
        }
        long sessionStartTime = sessionManager.getSessionStartTime();
        Version version4 = version3;
        VersionMilestone versionMilestone = new VersionMilestone(version2, 0, sessionStartTime, sessionStartTime, 0L, 0L);
        List mutableList = CollectionsKt.toMutableList(historyVersionMilestoneList);
        if (currentVersionMilestone != null) {
            mutableList.add(VersionMilestone.copy$default(currentVersionMilestone, (Version) null, 0, 0L, 0L, 0L, currentVersionMilestone.getCurrentSessionDuration(), 15, (Object) null));
        }
        bidMachineSharedPreferenceKt.setHistoryVersionMilestoneList(context, mutableList);
        if (version4 == null) {
            onInstall(context, sessionStartTime);
        } else if (version2.compareTo(version4) < 0) {
            onDowngrade(version4, version2);
        } else {
            Iterator it = historyVersionMilestoneList.iterator();
            if (it.hasNext()) {
                next = it.next();
                if (it.hasNext()) {
                    Comparable version5 = ((VersionMilestone) next).getVersion();
                    do {
                        Object next2 = it.next();
                        Comparable version6 = ((VersionMilestone) next2).getVersion();
                        if (version5.compareTo(version6) < 0) {
                            next = next2;
                            version5 = version6;
                        }
                    } while (it.hasNext());
                }
            }
            VersionMilestone versionMilestone2 = (VersionMilestone) next;
            if (versionMilestone2 == null || (version = versionMilestone2.getVersion()) == null) {
                version = version4;
            }
            onUpgrade(version4, version2, version);
        }
        return versionMilestone;
    }

    public final void onSessionStarted(@NotNull Context context, @NotNull SessionManagerKtWrapper sessionManager) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(sessionManager, "sessionManager");
        VersionMilestone versionMilestoneCheckAndGetCurrentVersionMilestone = checkAndGetCurrentVersionMilestone(context, sessionManager);
        VersionMilestone versionMilestoneCopy$default = versionMilestoneCheckAndGetCurrentVersionMilestone != null ? VersionMilestone.copy$default(versionMilestoneCheckAndGetCurrentVersionMilestone, (Version) null, versionMilestoneCheckAndGetCurrentVersionMilestone.getSessionCount() + 1, 0L, sessionManager.getSessionStartTime(), sessionManager.getSessionDurationMs(), versionMilestoneCheckAndGetCurrentVersionMilestone.getCurrentSessionDuration(), 5, (Object) null) : null;
        BidMachineSharedPreferenceKt.INSTANCE.setCurrentVersionMilestone(context, versionMilestoneCopy$default);
        Logger.d(TAG, new VersionManager$.ExternalSyntheticLambda1(versionMilestoneCopy$default));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String onSessionStarted$lambda$3(VersionMilestone versionMilestone) {
        return "New session, milestone updated:\n" + versionMilestone;
    }

    public final void onSessionPaused(@NotNull Context context, @NotNull SessionManagerKtWrapper sessionManager) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(sessionManager, "sessionManager");
        BidMachineSharedPreferenceKt bidMachineSharedPreferenceKt = BidMachineSharedPreferenceKt.INSTANCE;
        VersionMilestone currentVersionMilestone = bidMachineSharedPreferenceKt.getCurrentVersionMilestone(context);
        VersionMilestone versionMilestoneCopy$default = currentVersionMilestone != null ? VersionMilestone.copy$default(currentVersionMilestone, (Version) null, 0, 0L, 0L, sessionManager.getSessionDurationMs(), 0L, 47, (Object) null) : null;
        bidMachineSharedPreferenceKt.setCurrentVersionMilestone(context, versionMilestoneCopy$default);
        Logger.d(TAG, new VersionManager$.ExternalSyntheticLambda2(versionMilestoneCopy$default));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String onSessionPaused$lambda$4(VersionMilestone versionMilestone) {
        return "Pause session, milestone updated:\n" + versionMilestone;
    }

    private final void onInstall(Context context, long installTime) {
        BidMachineSharedPreferenceKt bidMachineSharedPreferenceKt = BidMachineSharedPreferenceKt.INSTANCE;
        if (bidMachineSharedPreferenceKt.hasBMIFV(context)) {
            Logger.d(TAG, "Migration from old version detected");
        } else {
            Logger.d(TAG, "Install detected");
            bidMachineSharedPreferenceKt.setSdkInstallTime(context, installTime);
        }
    }

    private final void onUpgrade(Version from, Version to, Version lastMaxVersion) {
        Logger.d(TAG, new VersionManager$.ExternalSyntheticLambda0(from, to, lastMaxVersion));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String onUpgrade$lambda$5(Version version, Version version2, Version version3) {
        Intrinsics.checkNotNullParameter(version, "$from");
        Intrinsics.checkNotNullParameter(version2, "$to");
        return "Upgrade detected: " + version + " -> " + version2 + ", last max version: " + version3;
    }

    private final void onDowngrade(Version from, Version to) {
        Logger.w(TAG, new VersionManager$.ExternalSyntheticLambda3(from, to));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String onDowngrade$lambda$6(Version version, Version version2) {
        Intrinsics.checkNotNullParameter(version, "$from");
        Intrinsics.checkNotNullParameter(version2, "$to");
        return "Downgrade detected: " + version + " -> " + version2;
    }
}
