package io.bidmachine.internal.utils.visibility;

import io.bidmachine.internal.utils.LogSafeRunnable;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class VisibilityTrackerImpl$FinishRunnable implements LogSafeRunnable {
    final /* synthetic */ VisibilityTrackerImpl this$0;

    private VisibilityTrackerImpl$FinishRunnable(final VisibilityTrackerImpl this$0) {
        this.this$0 = this$0;
    }

    public void onRun() throws Throwable {
        this.this$0.stop();
    }
}
