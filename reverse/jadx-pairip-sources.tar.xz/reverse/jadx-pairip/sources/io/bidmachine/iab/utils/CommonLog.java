package io.bidmachine.iab.utils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class CommonLog {
    private static final Logger a = new Logger("CommonLog");

    public static boolean canSendDLog() {
        return a.canSendDLog();
    }

    public static boolean canSendELog() {
        return a.canSendELog();
    }

    public static boolean canSendWLog() {
        return a.canSendWLog();
    }

    public static void d(@NonNull String subTag, @Nullable String message, @Nullable Object... args) {
        a.d(subTag, message, args);
    }

    public static void e(@NonNull String subTag, @Nullable String message, @Nullable Object... args) {
        a.e(subTag, message, args);
    }

    public static void setLoggingLevel(@Nullable Logger.LogLevel logLevel) {
        a.setLoggingLevel(logLevel);
    }

    public static void e(@NonNull String subTag, @NonNull Throwable throwable) {
        a.e(subTag, throwable);
    }
}
