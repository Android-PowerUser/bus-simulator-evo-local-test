package io.bidmachine.iab.mraid;

import io.bidmachine.iab.IabError;
import io.bidmachine.iab.utils.IabClickCallback;
import io.bidmachine.rendering.model.PrivacySheetParams;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class MraidInterstitial$b implements MraidViewListener {
    final /* synthetic */ MraidInterstitial a;

    private MraidInterstitial$b(final MraidInterstitial this$0) {
        this.a = this$0;
    }

    public void onCalendarEvent(MraidView mraidView, String str, IabClickCallback iabClickCallback) {
        MraidLog.d("MraidInterstitial", "ViewListener - onCalendarEvent (%s)", new Object[]{str});
        if (MraidInterstitial.a(this.a) != null) {
            MraidInterstitial.a(this.a).onCalendarEvent(this.a, str, iabClickCallback);
        }
    }

    public void onClose(MraidView mraidView) {
        MraidLog.d("MraidInterstitial", "ViewListener - onClose", new Object[0]);
        MraidInterstitial.b(this.a);
        this.a.b();
    }

    public void onExpand(MraidView mraidView) {
    }

    public void onExpired(MraidView mraidView, IabError iabError) {
        MraidLog.d("MraidInterstitial", "ViewListener - onExpired (%s)", new Object[]{iabError});
        if (MraidInterstitial.a(this.a) != null) {
            MraidInterstitial.a(this.a).onExpired(this.a, iabError);
        }
    }

    public void onLoadFailed(MraidView mraidView, IabError iabError) {
        MraidLog.d("MraidInterstitial", "ViewListener - onLoadFailed (%s)", new Object[]{iabError});
        MraidInterstitial.b(this.a);
        this.a.a(iabError);
    }

    public void onLoaded(MraidView mraidView) {
        MraidLog.d("MraidInterstitial", "ViewListener - onLoaded", new Object[0]);
        this.a.c();
    }

    public void onOpenPrivacySheet(MraidView mraidView, PrivacySheetParams privacySheetParams) {
        MraidLog.d("MraidInterstitial", "ViewListener - onOpenPrivacySheet (%s)", new Object[]{privacySheetParams.toString()});
        if (MraidInterstitial.a(this.a) != null) {
            MraidInterstitial.a(this.a).onOpenPrivacySheet(this.a, privacySheetParams);
        }
    }

    public void onOpenUrl(MraidView mraidView, String str, IabClickCallback iabClickCallback) {
        MraidLog.d("MraidInterstitial", "ViewListener - onOpenBrowser (%s)", new Object[]{str});
        if (MraidInterstitial.a(this.a) != null) {
            MraidInterstitial.a(this.a).onOpenUrl(this.a, str, iabClickCallback);
        }
    }

    public void onPlayVideo(MraidView mraidView, String str) {
        MraidLog.d("MraidInterstitial", "ViewListener - onPlayVideo (%s)", new Object[]{str});
        if (MraidInterstitial.a(this.a) != null) {
            MraidInterstitial.a(this.a).onPlayVideo(this.a, str);
        }
    }

    public void onShowFailed(MraidView mraidView, IabError iabError) {
        MraidLog.d("MraidInterstitial", "ViewListener - onShowFailed (%s)", new Object[]{iabError});
        MraidInterstitial.b(this.a);
        this.a.b(iabError);
    }

    public void onShown(MraidView mraidView) {
        MraidLog.d("MraidInterstitial", "ViewListener - onShown", new Object[0]);
        this.a.d();
    }

    public void onStorePicture(MraidView mraidView, String str, IabClickCallback iabClickCallback) {
        MraidLog.d("MraidInterstitial", "ViewListener - onCalendarEvent (%s)", new Object[]{str});
        if (MraidInterstitial.a(this.a) != null) {
            MraidInterstitial.a(this.a).onStorePicture(this.a, str, iabClickCallback);
        }
    }
}
