package io.bidmachine.iab.vast;

import io.bidmachine.iab.vast.processor.VastAd;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class VastRequest$i implements Runnable {
    final /* synthetic */ VastAd a;
    final /* synthetic */ VastRequest b;

    VastRequest$i(VastRequest vastRequest, VastAd vastAd) {
        this.b = vastRequest;
        this.a = vastAd;
    }

    @Override // java.lang.Runnable
    public void run() {
        if (VastRequest.f(this.b) != null) {
            VastRequest.f(this.b).onSuccess(this.b, this.a);
        }
    }
}
