package io.bidmachine.iab.utils;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import androidx.media3.extractor.ogg.OggPageHeader;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class CircularProgressDrawable$d {
    final Paint b;
    final Paint c;
    final Paint d;
    final Paint e;
    int[] j;
    int k;
    float l;
    float m;
    float n;
    float o;
    int q;
    float f = 0.0f;
    float g = 0.0f;
    float h = 0.0f;
    float i = 5.0f;
    int p = OggPageHeader.MAX_SEGMENT_COUNT;
    final RectF a = new RectF();

    CircularProgressDrawable$d() {
        Paint paint = new Paint();
        this.b = paint;
        paint.setStrokeCap(Paint.Cap.SQUARE);
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);
        Paint paint2 = new Paint();
        this.c = paint2;
        paint2.setStyle(Paint.Style.FILL);
        paint2.setAntiAlias(true);
        Paint paint3 = new Paint();
        this.d = paint3;
        paint3.setColor(0);
        Paint paint4 = new Paint();
        this.e = paint4;
        paint4.setColor(0);
    }

    void a(Paint.Cap cap) {
        this.b.setStrokeCap(cap);
    }

    void b(int i) {
        this.d.setColor(i);
    }

    void c(int i) {
        this.q = i;
    }

    void d(int i) {
        this.k = i;
        this.q = this.j[i];
    }

    int e() {
        return (this.k + 1) % this.j.length;
    }

    float f() {
        return this.f;
    }

    int g() {
        return this.j[this.k];
    }

    float h() {
        return this.m;
    }

    float i() {
        return this.n;
    }

    float j() {
        return this.l;
    }

    void k() {
        d(e());
    }

    void l() {
        this.l = 0.0f;
        this.m = 0.0f;
        this.n = 0.0f;
        d(0.0f);
        b(0.0f);
        c(0.0f);
    }

    void m() {
        this.l = this.f;
        this.m = this.g;
        this.n = this.h;
    }

    void a(Canvas canvas, Rect rect) {
        RectF rectF = this.a;
        float f = this.o;
        float fMin = (this.i / 2.0f) + f;
        if (f <= 0.0f) {
            fMin = (Math.min(rect.width(), rect.height()) / 2.0f) - (this.i / 2.0f);
        }
        rectF.set(rect.centerX() - fMin, rect.centerY() - fMin, rect.centerX() + fMin, rect.centerY() + fMin);
        float f2 = this.f;
        float f3 = this.h;
        float f4 = (f2 + f3) * 360.0f;
        float f5 = ((this.g + f3) * 360.0f) - f4;
        this.b.setColor(this.q);
        this.b.setAlpha(this.p);
        float f6 = this.i / 2.0f;
        rectF.inset(f6, f6);
        canvas.drawCircle(rectF.centerX(), rectF.centerY(), rectF.width() / 2.0f, this.d);
        float f7 = -f6;
        rectF.inset(f7, f7);
        canvas.drawArc(rectF, f4, f5, false, this.b);
    }

    int b() {
        return this.d.getColor();
    }

    float c() {
        return this.g;
    }

    void e(float f) {
        this.i = f;
        this.b.setStrokeWidth(f);
    }

    void b(float f) {
        this.g = f;
    }

    void c(float f) {
        this.h = f;
    }

    int d() {
        return this.j[e()];
    }

    void d(float f) {
        this.f = f;
    }

    void a(int[] iArr) {
        this.j = iArr;
        d(0);
    }

    void a(ColorFilter colorFilter) {
        this.b.setColorFilter(colorFilter);
    }

    void a(int i) {
        this.p = i;
    }

    int a() {
        return this.p;
    }

    void a(float f) {
        this.o = f;
    }
}
