package io.bidmachine.iab.mraid;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import io.bidmachine.iab.CacheControl;
import io.bidmachine.iab.measurer.MraidAdMeasurer;
import io.bidmachine.iab.utils.IabElementStyle;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class MraidView$Builder {
    private final MraidPlacementType a;
    private CacheControl b;
    private String c;
    private String d;
    private String e;
    private String[] f;
    private IabElementStyle g;
    private IabElementStyle h;
    private IabElementStyle i;
    private IabElementStyle j;
    private float k;
    private float l;

    @VisibleForTesting
    public MraidViewListener listener;
    private float m;
    public MraidAdMeasurer mraidAdMeasurer;
    private boolean n;
    private boolean o;
    private boolean p;
    private boolean q;

    public MraidView$Builder() {
        this(MraidPlacementType.INLINE);
    }

    public MraidView build(@NonNull Context context) {
        return new MraidView(context, this, (MraidView.a) null);
    }

    public MraidView$Builder forceUseNativeCloseButton(boolean forceUseNativeCloseButton) {
        this.o = forceUseNativeCloseButton;
        return this;
    }

    public MraidView$Builder setAdMeasurer(@Nullable MraidAdMeasurer mraidAdMeasurer) {
        this.mraidAdMeasurer = mraidAdMeasurer;
        return this;
    }

    public MraidView$Builder setAllowedNativeFeatures(@Nullable String[] allowedNativeFeatures) {
        this.f = allowedNativeFeatures;
        return this;
    }

    public MraidView$Builder setBaseUrl(String baseUrl) {
        this.c = baseUrl;
        return this;
    }

    public MraidView$Builder setCacheControl(@NonNull CacheControl cacheControl) {
        this.b = cacheControl;
        return this;
    }

    public MraidView$Builder setCloseStyle(IabElementStyle closeStyle) {
        this.g = closeStyle;
        return this;
    }

    public MraidView$Builder setCloseTimeSec(float closeTimeSec) {
        this.l = closeTimeSec;
        return this;
    }

    public MraidView$Builder setCountDownStyle(IabElementStyle countDownStyle) {
        this.h = countDownStyle;
        return this;
    }

    public MraidView$Builder setDurationSec(float durationSec) {
        this.m = durationSec;
        return this;
    }

    public MraidView$Builder setIsTag(boolean isTag) {
        this.n = isTag;
        return this;
    }

    public MraidView$Builder setListener(MraidViewListener listener) {
        this.listener = listener;
        return this;
    }

    public MraidView$Builder setLoadingStyle(IabElementStyle loadingStyle) {
        this.i = loadingStyle;
        return this;
    }

    public MraidView$Builder setPageFinishedScript(String pageFinishedScript) {
        this.e = pageFinishedScript;
        return this;
    }

    public MraidView$Builder setPlaceholderTimeoutSec(float placeholderTimeoutSec) {
        this.k = placeholderTimeoutSec;
        return this;
    }

    public MraidView$Builder setProductLink(String productLink) {
        this.d = productLink;
        return this;
    }

    public MraidView$Builder setProgressStyle(IabElementStyle progressStyle) {
        this.j = progressStyle;
        return this;
    }

    public MraidView$Builder setR1(boolean r1) {
        this.p = r1;
        return this;
    }

    public MraidView$Builder setR2(boolean r2) {
        this.q = r2;
        return this;
    }

    MraidView$Builder(MraidPlacementType mraidPlacementType) {
        this.f = null;
        this.k = 3.0f;
        this.l = 0.0f;
        this.m = 0.0f;
        this.a = mraidPlacementType;
        this.b = CacheControl.FullLoad;
        this.c = "https://localhost";
    }
}
