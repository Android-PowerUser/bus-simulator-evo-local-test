package io.bidmachine.iab.vast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import io.bidmachine.iab.CacheControl;
import io.bidmachine.iab.measurer.VastAdMeasurer;
import io.bidmachine.iab.vast.processor.VastMediaPicker;
import io.bidmachine.iab.vast.tags.MediaFileTag;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class VastRequest$Builder {
    final /* synthetic */ VastRequest a;

    public VastRequest$Builder(final VastRequest this$0) {
        this.a = this$0;
    }

    public VastRequest$Builder addExtra(@NonNull String key, @Nullable String value) {
        this.a.addExtra(key, value);
        return this;
    }

    @NonNull
    public VastRequest build() {
        return this.a;
    }

    public VastRequest$Builder forceUseNativeCloseTime(boolean forceUseNativeCloseTime) {
        VastRequest.a(this.a, forceUseNativeCloseTime);
        return this;
    }

    public VastRequest$Builder setAdMeasurer(@Nullable VastAdMeasurer vastAdMeasurer) {
        VastRequest.a(this.a, vastAdMeasurer);
        return this;
    }

    public VastRequest$Builder setAutoClose(boolean autoClose) {
        VastRequest.b(this.a, autoClose);
        return this;
    }

    public VastRequest$Builder setCacheControl(@NonNull CacheControl cacheControl) {
        VastRequest.a(this.a, cacheControl);
        return this;
    }

    public VastRequest$Builder setCompanionCloseTime(int closeTime) {
        VastRequest.a(this.a, closeTime);
        return this;
    }

    public VastRequest$Builder setMaxDuration(int maxDurationMillis) {
        VastRequest.a(this.a, maxDurationMillis);
        return this;
    }

    public VastRequest$Builder setMediaFilePicker(@Nullable VastMediaPicker<MediaFileTag> mediaFilePicker) {
        VastRequest.a(this.a, mediaFilePicker);
        return this;
    }

    public VastRequest$Builder setPlaceholderTimeoutSec(float placeholderTimeoutSec) {
        VastRequest.b(this.a, placeholderTimeoutSec);
        return this;
    }

    public VastRequest$Builder setPreloadCompanion(boolean preload) {
        VastRequest.e(this.a, preload);
        return this;
    }

    public VastRequest$Builder setUseScreenSizeForCompanionOrientation(boolean use) {
        VastRequest.d(this.a, use);
        return this;
    }

    public VastRequest$Builder setUseScreenSizeForVideoOrientation(boolean use) {
        VastRequest.c(this.a, use);
        return this;
    }

    public VastRequest$Builder setVideoCloseTime(int closeTimeSec) {
        VastRequest.a(this.a, Float.valueOf(closeTimeSec));
        return this;
    }
}
