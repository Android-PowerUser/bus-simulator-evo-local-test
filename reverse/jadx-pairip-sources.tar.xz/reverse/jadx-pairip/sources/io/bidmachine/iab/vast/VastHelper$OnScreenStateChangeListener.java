package io.bidmachine.iab.vast;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface VastHelper$OnScreenStateChangeListener {
    void onScreenStateChange(boolean isScreenOn);
}
