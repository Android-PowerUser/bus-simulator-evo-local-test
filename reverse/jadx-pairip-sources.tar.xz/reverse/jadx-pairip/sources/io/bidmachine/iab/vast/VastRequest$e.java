package io.bidmachine.iab.vast;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class VastRequest$e implements Runnable {
    final /* synthetic */ VastRequestListener a;
    final /* synthetic */ VastRequest b;

    VastRequest$e(VastRequest vastRequest, VastRequestListener vastRequestListener) {
        this.b = vastRequest;
        this.a = vastRequestListener;
    }

    @Override // java.lang.Runnable
    public void run() {
        this.a.onVastLoaded(this.b);
    }
}
