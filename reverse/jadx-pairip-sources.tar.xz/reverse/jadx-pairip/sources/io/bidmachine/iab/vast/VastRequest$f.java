package io.bidmachine.iab.vast;

import io.bidmachine.iab.CacheControl;
import io.bidmachine.iab.IabError;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class VastRequest$f implements Runnable {
    final /* synthetic */ IabError a;
    final /* synthetic */ VastRequestListener b;
    final /* synthetic */ VastRequest c;

    VastRequest$f(VastRequest vastRequest, IabError iabError, VastRequestListener vastRequestListener) {
        this.c = vastRequest;
        this.a = iabError;
        this.b = vastRequestListener;
    }

    @Override // java.lang.Runnable
    public void run() {
        if (VastRequest.b(this.c) != null) {
            VastRequest.b(this.c).onError(this.a);
        }
        if (this.b != null) {
            if (VastRequest.c(this.c) != CacheControl.PartialLoad || !VastRequest.d(this.c).get() || VastRequest.e(this.c).get()) {
                this.b.onVastLoadFailed(this.c, this.a);
                return;
            }
            VastRequestListener vastRequestListener = this.b;
            VastRequest vastRequest = this.c;
            vastRequestListener.onVastLoadFailed(vastRequest, IabError.expired(String.format("%s load failed after display - %s", VastRequest.c(vastRequest), this.a)));
        }
    }
}
