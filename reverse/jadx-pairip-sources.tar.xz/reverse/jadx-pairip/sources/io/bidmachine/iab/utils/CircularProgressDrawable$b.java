package io.bidmachine.iab.utils;

import android.animation.ValueAnimator;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class CircularProgressDrawable$b implements ValueAnimator.AnimatorUpdateListener {
    final /* synthetic */ CircularProgressDrawable$d a;
    final /* synthetic */ CircularProgressDrawable b;

    CircularProgressDrawable$b(CircularProgressDrawable circularProgressDrawable, CircularProgressDrawable$d circularProgressDrawable$d) {
        this.b = circularProgressDrawable;
        this.a = circularProgressDrawable$d;
    }

    @Override // android.animation.ValueAnimator.AnimatorUpdateListener
    public void onAnimationUpdate(ValueAnimator valueAnimator) {
        float fFloatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
        CircularProgressDrawable.a(this.b, fFloatValue, this.a);
        CircularProgressDrawable.a(this.b, fFloatValue, this.a, false);
        this.b.invalidateSelf();
    }
}
