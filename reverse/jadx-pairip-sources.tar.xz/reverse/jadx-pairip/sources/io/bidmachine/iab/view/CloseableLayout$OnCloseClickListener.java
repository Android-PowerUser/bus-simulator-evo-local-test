package io.bidmachine.iab.view;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface CloseableLayout$OnCloseClickListener {
    void onCloseClick();

    void onCountDownFinish();
}
