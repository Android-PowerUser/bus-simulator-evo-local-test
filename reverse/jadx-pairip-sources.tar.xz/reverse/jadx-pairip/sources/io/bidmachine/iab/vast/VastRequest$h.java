package io.bidmachine.iab.vast;

import io.bidmachine.iab.IabError;
import io.bidmachine.iab.vast.activity.VastView;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class VastRequest$h implements Runnable {
    final /* synthetic */ VastViewListener a;
    final /* synthetic */ VastView b;
    final /* synthetic */ IabError c;
    final /* synthetic */ VastRequest d;

    VastRequest$h(VastRequest vastRequest, VastViewListener vastViewListener, VastView vastView, IabError iabError) {
        this.d = vastRequest;
        this.a = vastViewListener;
        this.b = vastView;
        this.c = iabError;
    }

    @Override // java.lang.Runnable
    public void run() {
        VastViewListener vastViewListener = this.a;
        if (vastViewListener != null) {
            vastViewListener.onShowFailed(this.b, this.d, this.c);
        }
    }
}
