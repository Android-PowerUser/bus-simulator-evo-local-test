package io.bidmachine.iab.utils;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class IabTimerHelper$b implements Runnable {
    final /* synthetic */ IabTimerHelper a;

    IabTimerHelper$b(IabTimerHelper iabTimerHelper) {
        this.a = iabTimerHelper;
    }

    @Override // java.lang.Runnable
    public void run() {
        long jB = IabTimerHelper.b(this.a);
        if (IabTimerHelper.c(this.a).isShown()) {
            jB = Math.min(IabTimerHelper.d(this.a), jB + 16);
            IabTimerHelper.a(this.a, jB);
            IabTimerHelper.e(this.a).onTimerTick((IabTimerHelper.b(this.a) * 100.0f) / IabTimerHelper.d(this.a), IabTimerHelper.b(this.a), IabTimerHelper.d(this.a));
        }
        if (jB >= IabTimerHelper.d(this.a)) {
            IabTimerHelper.e(this.a).onTimerFinish();
        } else {
            IabTimerHelper.c(this.a).postDelayed(this, 16L);
        }
    }
}
