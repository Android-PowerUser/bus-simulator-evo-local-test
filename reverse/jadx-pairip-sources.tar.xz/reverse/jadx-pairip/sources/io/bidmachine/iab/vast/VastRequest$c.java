package io.bidmachine.iab.vast;

import android.content.Context;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class VastRequest$c extends Thread {
    final /* synthetic */ Context a;
    final /* synthetic */ String b;
    final /* synthetic */ VastRequestListener c;
    final /* synthetic */ VastRequest d;

    VastRequest$c(VastRequest vastRequest, Context context, String str, VastRequestListener vastRequestListener) {
        this.d = vastRequest;
        this.a = context;
        this.b = str;
        this.c = vastRequestListener;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        this.d.loadVideoWithDataSync(this.a, this.b, this.c);
    }
}
