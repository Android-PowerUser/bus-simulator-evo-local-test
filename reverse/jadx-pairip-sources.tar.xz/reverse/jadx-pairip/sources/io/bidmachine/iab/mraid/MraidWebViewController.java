package io.bidmachine.iab.mraid;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Base64;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.gms.common.internal.ImagesContract;
import com.safedk.android.analytics.brandsafety.BrandSafetyUtils;
import com.safedk.android.analytics.brandsafety.creatives.CreativeInfoManager;
import com.safedk.android.internal.partials.BidMachineNetworkBridge;
import io.bidmachine.iab.IabError;
import io.bidmachine.iab.bridge.JsBridgeHandler;
import io.bidmachine.iab.utils.Logger;
import io.bidmachine.iab.utils.Utils;
import java.io.ByteArrayInputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class MraidWebViewController {

    @NonNull
    public static final String TAG = "MraidWebViewController";
    private final Callback a;
    private final long b;
    private final MraidWebView c;
    private final AtomicBoolean d;
    private boolean e;
    private boolean f;
    private MraidViewState g;
    private MraidOrientationProperties h;

    private class c implements MraidWebViewListener {
        private c() {
        }

        @Override // io.bidmachine.iab.mraid.MraidWebViewListener
        public void onMraidScreenMetricsChanged(MraidScreenMetrics mraidScreenMetrics) {
            if (!MraidWebViewController.this.d.get() || MraidWebViewController.this.g == MraidViewState.HIDDEN) {
                return;
            }
            MraidWebViewController.this.applyScreenMetrics(mraidScreenMetrics);
        }

        @Override // io.bidmachine.iab.mraid.MraidWebViewListener
        public void onViewableChanged(boolean z) {
            if (MraidWebViewController.this.d.get()) {
                MraidWebViewController.this.applyViewable(z);
            }
            MraidWebViewController.this.a.onViewableChanged(z);
        }
    }

    public MraidWebViewController(@NonNull Context context, @NonNull Callback callback, long expandTimeWindowMs) {
        this.a = callback;
        this.b = expandTimeWindowMs;
        MraidWebView mraidWebView = new MraidWebView(context);
        this.c = mraidWebView;
        mraidWebView.setWebViewClient(new b());
        mraidWebView.setMraidWebViewListener(new c());
        this.e = false;
        this.f = false;
        this.g = MraidViewState.LOADING;
        this.d = new AtomicBoolean(false);
    }

    public void applyClick(int x, int y) {
        b(String.format("(function click(x, y) {var ev = new MouseEvent('click', {    'view': window,    'bubbles': true,    'cancelable': true,    'screenX': x,    'screenY': y});var el = document.elementFromPoint(x, y);if (el !== null) {      el.dispatchEvent(ev); }})(%s, %s)", Integer.valueOf(x), Integer.valueOf(y)));
    }

    public void applyLogLevel(@Nullable Logger.LogLevel level) {
        if (level == Logger.LogLevel.debug) {
            b("mraid.logLevel = mraid.LogLevelEnum.DEBUG;");
            return;
        }
        if (level == Logger.LogLevel.info) {
            b("mraid.logLevel = mraid.LogLevelEnum.INFO;");
            return;
        }
        if (level == Logger.LogLevel.warning) {
            b("mraid.logLevel = mraid.LogLevelEnum.WARNING;");
        } else if (level == Logger.LogLevel.error) {
            b("mraid.logLevel = mraid.LogLevelEnum.ERROR;");
        } else if (level == Logger.LogLevel.none) {
            b("mraid.logLevel = mraid.LogLevelEnum.NONE;");
        }
    }

    public void applyPlacement(@Nullable MraidPlacementType mraidPlacementType) {
        if (mraidPlacementType == null) {
            return;
        }
        b("mraid.setPlacementType('" + mraidPlacementType.b() + "');");
    }

    public void applyScreenMetrics(@NonNull MraidScreenMetrics mraidScreenMetrics) {
        Rect screenRectDp = mraidScreenMetrics.getScreenRectDp();
        Rect rootViewRectDp = mraidScreenMetrics.getRootViewRectDp();
        b("mraid.setScreenSize(" + screenRectDp.width() + "," + screenRectDp.height() + ");mraid.setMaxSize(" + rootViewRectDp.width() + "," + rootViewRectDp.height() + ");mraid.setCurrentPosition(" + Utils.stringifyRect(mraidScreenMetrics.getCurrentAdRectDp()) + ");mraid.setDefaultPosition(" + Utils.stringifyRect(mraidScreenMetrics.getDefaultAdRectDp()) + ");mraid.fireSizeChangeEvent(" + Utils.stringifySize(mraidScreenMetrics.getCurrentAdRectDp()) + ");");
    }

    public void applyState(@NonNull MraidViewState mraidViewState) {
        this.g = mraidViewState;
        b("mraid.fireStateChangeEvent('" + mraidViewState.toJsString() + "');");
    }

    public void applySupportedServices(@NonNull MraidNativeFeatureManager mraidNativeFeatureManager) {
        b("mraid.setSupports(mraid.SUPPORTED_FEATURES.CALENDAR, " + mraidNativeFeatureManager.isCalendarFeatureAvailable() + ");mraid.setSupports(mraid.SUPPORTED_FEATURES.INLINEVIDEO, " + mraidNativeFeatureManager.isInlineVideoFeatureAvailable() + ");mraid.setSupports(mraid.SUPPORTED_FEATURES.SMS, " + mraidNativeFeatureManager.isSmsFeatureAvailable() + ");mraid.setSupports(mraid.SUPPORTED_FEATURES.STOREPICTURE, " + mraidNativeFeatureManager.isStorePictureFeatureAvailable() + ");mraid.setSupports(mraid.SUPPORTED_FEATURES.TEL, " + mraidNativeFeatureManager.isTelFeatureAvailable() + ");");
    }

    public void applyViewable(boolean viewable) {
        b("mraid.fireViewableChangeEvent(" + viewable + ");");
    }

    public void destroy() {
        MraidWebView mraidWebView = this.c;
        Utils.removeFromParent(mraidWebView);
        mraidWebView.destroy();
    }

    @Nullable
    public MraidOrientationProperties getLastOrientationProperties() {
        return this.h;
    }

    @NonNull
    public MraidScreenMetrics getMraidScreenMetrics() {
        return this.c.getMraidScreenMetrics();
    }

    @NonNull
    public MraidWebView getMraidWebView() {
        return this.c;
    }

    public boolean isReceivedJsError() {
        return this.f;
    }

    public boolean isUseCustomClose() {
        return this.e;
    }

    public boolean isViewable() {
        return this.c.isViewable();
    }

    public void load(@NonNull String url) {
        this.d.set(false);
        BidMachineNetworkBridge.webviewLoadUrl(this.c, url);
    }

    public void notifyReady() {
        b("mraid.fireReadyEvent();");
    }

    public void reset() {
        this.c.reset();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void c(String str) {
        if (!this.c.wasClicked()) {
            MraidLog.d(TAG, "Can't open url because webView wasn't clicked", new Object[0]);
        } else {
            this.a.onOpen(str);
            this.c.resetClicked();
        }
    }

    private void d(String str) {
        if (this.b == 0 || System.currentTimeMillis() - this.c.getClickTimeMs() > this.b) {
            return;
        }
        this.a.onExpand(str);
    }

    void b(String str) {
        this.c.injectJs(str);
    }

    public void load(@Nullable String baseUrl, @NonNull String data, @Nullable String mimeType, @Nullable String encoding) {
        this.d.set(false);
        BidMachineNetworkBridge.webviewLoadDataWithBaseURL(this.c, baseUrl, data, mimeType, encoding, (String) null);
    }

    private class b extends WebViewClient {
        private b() {
        }

        private void a(String str, String str2, int i) {
            MraidLog.d(MraidWebViewController.TAG, "onError: %s / %s / %d", new Object[]{str, str2, Integer.valueOf(i)});
            if (str2 == null || !str2.contains("ERR_INTERNET_DISCONNECTED")) {
                return;
            }
            MraidWebViewController.this.f = true;
        }

        @Override // android.webkit.WebViewClient
        public void onLoadResource(WebView view, String url) {
            super.onLoadResource(view, url);
            CreativeInfoManager.onResourceLoaded("io.bidmachine", view, url);
        }

        @Override // android.webkit.WebViewClient
        public void onPageFinished(WebView webView, String str) {
            super.onPageFinished(webView, str);
            MraidLog.d(MraidWebViewController.TAG, "onPageFinished", new Object[0]);
            if (MraidWebViewController.this.d.compareAndSet(false, true)) {
                MraidWebViewController.this.a.onPageFinished(str);
                MraidWebViewController.this.c.onPageFinished();
            }
        }

        @Override // android.webkit.WebViewClient
        public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
            com.safedk.android.utils.Logger.d("BidMachine|SafeDK: Execution> Lio/bidmachine/iab/mraid/MraidWebViewController$b;->onPageStarted(Landroid/webkit/WebView;Ljava/lang/String;Landroid/graphics/Bitmap;)V");
            BrandSafetyUtils.onWebViewPageStarted("io.bidmachine", webView, str);
            safedk_MraidWebViewController$b_onPageStarted_30055bcb5b79239473faf332dfb0f4dd(webView, str, bitmap);
        }

        @Override // android.webkit.WebViewClient
        public void onReceivedError(WebView webView, int i, String str, String str2) {
            com.safedk.android.utils.Logger.d("BidMachine|SafeDK: Execution> Lio/bidmachine/iab/mraid/MraidWebViewController$b;->onReceivedError(Landroid/webkit/WebView;ILjava/lang/String;Ljava/lang/String;)V");
            BrandSafetyUtils.onWebViewReceivedError("io.bidmachine", webView, i, str, str2);
            safedk_MraidWebViewController$b_onReceivedError_f9d73168955d6bdc42cadf42f414e25f(webView, i, str, str2);
        }

        @Override // android.webkit.WebViewClient
        public void onReceivedError(WebView webView, WebResourceRequest webResourceRequest, WebResourceError webResourceError) {
            com.safedk.android.utils.Logger.d("BidMachine|SafeDK: Execution> Lio/bidmachine/iab/mraid/MraidWebViewController$b;->onReceivedError(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;Landroid/webkit/WebResourceError;)V");
            BrandSafetyUtils.onWebViewReceivedError("io.bidmachine", webView, webResourceRequest, webResourceError);
            safedk_MraidWebViewController$b_onReceivedError_ba7fb2e7d7514c5d835c60190d597943(webView, webResourceRequest, webResourceError);
        }

        @Override // android.webkit.WebViewClient
        public boolean onRenderProcessGone(WebView webView, RenderProcessGoneDetail renderProcessGoneDetail) {
            MraidLog.d(MraidWebViewController.TAG, "onRenderProcessGone", new Object[0]);
            MraidWebViewController.this.destroy();
            MraidWebViewController.this.a.onError(IabError.internal("WebViewClient - onRenderProcessGone"));
            return true;
        }

        public void safedk_MraidWebViewController$b_onPageStarted_30055bcb5b79239473faf332dfb0f4dd(WebView p0, String p1, Bitmap p2) {
            super.onPageStarted(p0, p1, p2);
            MraidLog.d(MraidWebViewController.TAG, "onPageStarted", new Object[0]);
        }

        public void safedk_MraidWebViewController$b_onReceivedError_ba7fb2e7d7514c5d835c60190d597943(WebView p0, WebResourceRequest p1, WebResourceError p2) {
            Uri url = p1.getUrl();
            a(url != null ? url.toString() : null, p2.getDescription().toString(), p2.getErrorCode());
            super.onReceivedError(p0, p1, p2);
        }

        public WebResourceResponse safedk_MraidWebViewController$b_shouldInterceptRequest_70371e720b5f85f4d885541ae7b04fd8(WebView p0, WebResourceRequest p1) {
            return a(p1.getUrl()) ? a() : super.shouldInterceptRequest(p0, p1);
        }

        public boolean safedk_MraidWebViewController$b_shouldOverrideUrlLoading_b4596206bcc70fc15c09a1adb02f299f(WebView p0, String p1) {
            if (p1.startsWith("mraid://")) {
                MraidWebViewController.this.a(p1);
                return true;
            }
            if (JsBridgeHandler.isHandled(p1)) {
                JsBridgeHandler.handleJsCommand(MraidWebViewController.this.c, p1);
                return true;
            }
            MraidWebViewController.this.c(p1);
            return true;
        }

        /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
        @Override // android.webkit.WebViewClient
        public WebResourceResponse shouldInterceptRequest(WebView webView, WebResourceRequest webResourceRequest) {
            com.safedk.android.utils.Logger.d("BidMachine|SafeDK: Execution> Lio/bidmachine/iab/mraid/MraidWebViewController$b;->shouldInterceptRequest(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;)Landroid/webkit/WebResourceResponse;");
            return CreativeInfoManager.onWebViewResponseWithHeaders("io.bidmachine", webView, webResourceRequest, safedk_MraidWebViewController$b_shouldInterceptRequest_70371e720b5f85f4d885541ae7b04fd8(webView, webResourceRequest));
        }

        @Override // android.webkit.WebViewClient
        public WebResourceResponse shouldInterceptRequest(WebView webView, String str) {
            com.safedk.android.utils.Logger.d("BidMachine|SafeDK: Execution> Lio/bidmachine/iab/mraid/MraidWebViewController$b;->shouldInterceptRequest(Landroid/webkit/WebView;Ljava/lang/String;)Landroid/webkit/WebResourceResponse;");
            return CreativeInfoManager.onWebViewResponse("io.bidmachine", webView, str, safedk_MraidWebViewController$b_shouldInterceptRequest_f9a37b326fb6782bea01bbc53ca95772(webView, str));
        }

        @Override // android.webkit.WebViewClient
        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            com.safedk.android.utils.Logger.d("BidMachine|SafeDK: Execution> Lio/bidmachine/iab/mraid/MraidWebViewController$b;->shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z");
            boolean zSafedk_MraidWebViewController$b_shouldOverrideUrlLoading_b4596206bcc70fc15c09a1adb02f299f = safedk_MraidWebViewController$b_shouldOverrideUrlLoading_b4596206bcc70fc15c09a1adb02f299f(webView, str);
            BrandSafetyUtils.onShouldOverrideUrlLoading("io.bidmachine", webView, str, zSafedk_MraidWebViewController$b_shouldOverrideUrlLoading_b4596206bcc70fc15c09a1adb02f299f);
            return zSafedk_MraidWebViewController$b_shouldOverrideUrlLoading_b4596206bcc70fc15c09a1adb02f299f;
        }

        boolean a(String str) {
            return a(Uri.parse(str.toLowerCase(Locale.US)));
        }

        public WebResourceResponse safedk_MraidWebViewController$b_shouldInterceptRequest_f9a37b326fb6782bea01bbc53ca95772(WebView p0, String p1) {
            if (a(p1)) {
                return a();
            }
            return super.shouldInterceptRequest(p0, p1);
        }

        boolean a(Uri uri) {
            return "mraid.js".equals(uri.getLastPathSegment());
        }

        private WebResourceResponse a() {
            String strB = MraidUtils.b();
            Charset charset = StandardCharsets.UTF_8;
            return new WebResourceResponse("text/javascript", charset.name(), new ByteArrayInputStream(strB.getBytes(charset)));
        }

        public void safedk_MraidWebViewController$b_onReceivedError_f9d73168955d6bdc42cadf42f414e25f(WebView p0, int p1, String p2, String p3) {
            a(p3, p2, p1);
            super.onReceivedError(p0, p1, p2, p3);
        }
    }

    private void a() {
        b("mraid.nativeCallComplete();");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(String str) {
        MraidLog.d(TAG, "handleJsCommand - %s", new Object[]{str});
        try {
            Map commandUrl = MraidUtils.parseCommandUrl(str);
            if (commandUrl == null) {
                return;
            }
            String str2 = (String) commandUrl.get("command");
            if (str2 == null) {
                MraidLog.w(TAG, "handleJsCommand not found", new Object[0]);
            } else {
                a(str2, commandUrl);
                a();
            }
        } catch (Throwable th) {
            MraidLog.e(TAG, th);
        }
    }

    private void a(String str, Map map) {
        str.hashCode();
        switch (str) {
            case "playVideo":
                this.a.onPlayVideo((String) map.get(ImagesContract.URL));
                break;
            case "openPrivacySheet":
                String str2 = (String) map.get("data");
                if (TextUtils.isEmpty(str2)) {
                    MraidLog.e(TAG, "data is null or empty", new Object[0]);
                    break;
                } else {
                    try {
                        this.a.onOpenPrivacySheet(new String(Base64.decode(str2, 2)));
                    } catch (Throwable unused) {
                        MraidLog.e(TAG, "data must be base64 encoded json", new Object[0]);
                        return;
                    }
                    break;
                }
                break;
            case "expand":
                d((String) map.get(ImagesContract.URL));
                break;
            case "loaded":
                this.a.onLoaded();
                break;
            case "noFill":
                this.a.onError(IabError.noFIll("Fired noFill event from mraid.js"));
                break;
            case "resize":
                MraidLog.d(TAG, "mraid.resize is not supported", new Object[0]);
                break;
            case "createCalendarEvent":
                this.a.onCalendarEvent((String) map.get("eventJSON"));
                break;
            case "open":
                String str3 = (String) map.get(ImagesContract.URL);
                if (TextUtils.isEmpty(str3)) {
                    MraidLog.e(TAG, "url is null or empty", new Object[0]);
                    break;
                } else {
                    c(str3);
                    break;
                }
                break;
            case "close":
                this.a.onClose();
                break;
            case "setOrientationProperties":
                MraidOrientationProperties mraidOrientationProperties = new MraidOrientationProperties(Boolean.parseBoolean((String) map.get("allowOrientationChange")), MraidOrientationProperties.forceOrientationFromString((String) map.get("forceOrientation")));
                this.h = mraidOrientationProperties;
                this.a.onOrientation(mraidOrientationProperties);
                break;
            case "storePicture":
                this.a.onStorePicture((String) map.get(ImagesContract.URL));
                break;
            case "useCustomClose":
                boolean z = Boolean.parseBoolean((String) map.get("useCustomClose"));
                if (this.e != z) {
                    this.e = z;
                    this.a.onUseCustomClose(z);
                    break;
                }
                break;
        }
    }
}
