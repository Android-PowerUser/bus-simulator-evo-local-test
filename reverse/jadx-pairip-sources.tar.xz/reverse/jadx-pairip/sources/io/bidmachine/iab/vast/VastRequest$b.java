package io.bidmachine.iab.vast;

import android.content.Context;
import io.bidmachine.iab.IabError;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class VastRequest$b extends Thread {
    final /* synthetic */ String a;
    final /* synthetic */ VastRequestListener b;
    final /* synthetic */ Context c;
    final /* synthetic */ VastRequest d;

    VastRequest$b(VastRequest vastRequest, String str, VastRequestListener vastRequestListener, Context context) {
        this.d = vastRequest;
        this.a = str;
        this.b = vastRequestListener;
        this.c = context;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() throws Throwable {
        BufferedReader bufferedReader = null;
        try {
            try {
                BufferedReader bufferedReader2 = new BufferedReader(new InputStreamReader(new URL(this.a).openStream()));
                try {
                    StringBuffer stringBuffer = new StringBuffer();
                    while (true) {
                        String line = bufferedReader2.readLine();
                        if (line != null) {
                            stringBuffer.append(line);
                            stringBuffer.append(System.getProperty("line.separator"));
                        } else {
                            try {
                                break;
                            } catch (IOException unused) {
                            }
                        }
                    }
                    bufferedReader2.close();
                    this.d.loadVideoWithData(this.c, stringBuffer.toString(), this.b);
                } catch (Exception e) {
                    e = e;
                    bufferedReader = bufferedReader2;
                    VastLog.e("VastRequest", e);
                    this.d.sendVastSpecError(VastSpecError.XML_PARSING);
                    VastRequest.a(this.d, IabError.throwable("Exception during loading xml by url", e), this.b);
                    if (bufferedReader != null) {
                        try {
                            bufferedReader.close();
                        } catch (IOException unused2) {
                        }
                    }
                } catch (Throwable th) {
                    th = th;
                    bufferedReader = bufferedReader2;
                    if (bufferedReader != null) {
                        try {
                            bufferedReader.close();
                        } catch (IOException unused3) {
                        }
                    }
                    throw th;
                }
            } catch (Exception e2) {
                e = e2;
            }
        } catch (Throwable th2) {
            th = th2;
        }
    }
}
