package io.bidmachine.iab.vast;

import io.bidmachine.iab.IabError;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class VastRequest$g implements Runnable {
    final /* synthetic */ VastActivityListener a;
    final /* synthetic */ IabError b;
    final /* synthetic */ VastRequest c;

    VastRequest$g(VastRequest vastRequest, VastActivityListener vastActivityListener, IabError iabError) {
        this.c = vastRequest;
        this.a = vastActivityListener;
        this.b = iabError;
    }

    @Override // java.lang.Runnable
    public void run() {
        VastActivityListener vastActivityListener = this.a;
        if (vastActivityListener != null) {
            vastActivityListener.onVastShowFailed(this.c, this.b);
        }
    }
}
