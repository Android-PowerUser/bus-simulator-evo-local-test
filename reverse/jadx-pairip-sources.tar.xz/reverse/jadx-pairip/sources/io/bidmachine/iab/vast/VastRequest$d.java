package io.bidmachine.iab.vast;

import android.content.Context;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class VastRequest$d extends Thread {
    final /* synthetic */ Context a;
    final /* synthetic */ VastRequestListener b;
    final /* synthetic */ VastRequest c;

    VastRequest$d(VastRequest vastRequest, Context context, VastRequestListener vastRequestListener) {
        this.c = vastRequest;
        this.a = context;
        this.b = vastRequestListener;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        VastRequest vastRequest = this.c;
        VastRequest.a(vastRequest, this.a, VastRequest.a(vastRequest), this.b);
    }
}
