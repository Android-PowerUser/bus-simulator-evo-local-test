package io.bidmachine.iab.vast;

import io.bidmachine.iab.utils.Utils;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class VastRequest$k implements VastUrlProcessorRegistry.OnUrlReadyCallback {
    VastRequest$k() {
    }

    public void onUrlReady(String str) {
        VastLog.d("VastRequest", "Fire url: %s", new Object[]{str});
        Utils.simpleTrackUrl(str);
    }
}
