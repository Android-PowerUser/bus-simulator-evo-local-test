package io.bidmachine.iab.vast;

import io.bidmachine.iab.IabError;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class VastRequest$j implements Runnable {
    final /* synthetic */ IabError a;
    final /* synthetic */ VastRequest b;

    VastRequest$j(VastRequest vastRequest, IabError iabError) {
        this.b = vastRequest;
        this.a = iabError;
    }

    @Override // java.lang.Runnable
    public void run() {
        if (VastRequest.f(this.b) != null) {
            VastRequest.f(this.b).onError(this.b, this.a);
        }
    }
}
