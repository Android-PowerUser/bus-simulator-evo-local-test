package io.bidmachine.iab.mraid;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import io.bidmachine.iab.IabError;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public abstract class MraidAdView$MraidWebViewControllerCallback implements MraidWebViewController.Callback {
    final /* synthetic */ MraidAdView a;

    private MraidAdView$MraidWebViewControllerCallback(final MraidAdView this$0) {
        this.a = this$0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(String str) {
        MraidAdView.c(this.a).onCalendarEventIntention(this.a, str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void b(String str) {
        MraidAdView.c(this.a).onStorePictureIntention(this.a, str);
    }

    public void onCalendarEvent(@Nullable String eventJson) {
        MraidLog.d("MraidAdView", "Callback - onCalendarEvent: %s", new Object[]{eventJson});
        String strA = MraidAdView.d(this.a).a(eventJson);
        if (TextUtils.isEmpty(strA)) {
            return;
        }
        MraidAdView.a(this.a, strA, new MraidAdView$MraidWebViewControllerCallback$.ExternalSyntheticLambda0(this));
    }

    public void onClose() {
        MraidLog.d("MraidAdView", "Callback - onClose", new Object[0]);
        MraidAdView.a(this.a);
    }

    public void onError(@NonNull IabError iabError) {
        MraidLog.d("MraidAdView", "Callback - onError: %s", new Object[]{iabError});
        MraidAdView.a(this.a, iabError);
    }

    public void onExpand(@Nullable String url) {
        MraidLog.d("MraidAdView", "Callback - onExpand: %s", new Object[]{url});
        MraidAdView.a(this.a, url);
    }

    public void onLoaded() {
        MraidLog.d("MraidAdView", "Callback - onLoaded", new Object[0]);
        MraidAdView.j(this.a);
    }

    public void onOpen(@NonNull String url) {
        MraidLog.d("MraidAdView", "Callback - onOpen: %s", new Object[]{url});
        MraidAdView.c(this.a, url);
    }

    public void onOpenPrivacySheet(@NonNull String json) {
        MraidLog.d("MraidAdView", "Callback - onOpenPrivacySheet: %s", new Object[]{json});
        MraidAdView.d(this.a, json);
    }

    public void onOrientation(@NonNull MraidOrientationProperties mraidOrientationProperties) {
        MraidLog.d("MraidAdView", "Callback - onOrientation: %s", new Object[]{mraidOrientationProperties});
        if (this.a.isInterstitial() || MraidAdView.b(this.a) == MraidViewState.EXPANDED) {
            MraidAdView.c(this.a).onChangeOrientationIntention(this.a, mraidOrientationProperties);
        }
    }

    public void onPlayVideo(@Nullable String url) {
        MraidLog.d("MraidAdView", "Callback - onPlayVideo: %s", new Object[]{url});
        if (TextUtils.isEmpty(url)) {
            return;
        }
        try {
            MraidAdView.c(this.a).onPlayVideoIntention(this.a, URLDecoder.decode(url, "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            MraidLog.e("MraidAdView", e);
        }
    }

    public void onResize(@NonNull MraidResizeProperties resizeProperties) {
        MraidLog.d("MraidAdView", "Callback - onResize: %s", new Object[]{resizeProperties});
        MraidAdView.a(this.a, resizeProperties);
    }

    public void onStorePicture(@Nullable String url) {
        MraidLog.d("MraidAdView", "Callback - onStorePicture: %s", new Object[]{url});
        String strB = MraidAdView.d(this.a).b(url);
        if (TextUtils.isEmpty(strB)) {
            return;
        }
        MraidAdView.a(this.a, strB, new MraidAdView$MraidWebViewControllerCallback$.ExternalSyntheticLambda1(this));
    }
}
