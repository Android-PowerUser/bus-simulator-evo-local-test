package io.bidmachine.iab.bridge;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import io.bidmachine.iab.mraid.MraidLog;
import io.bidmachine.iab.mraid.MraidUtils;
import io.bidmachine.iab.mraid.MraidWebView;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class JsBridgeHandler {
    private static final List a = new CopyOnWriteArrayList();

    private static JsBridge a(String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        for (JsBridge jsBridge : a) {
            if (jsBridge.isHandled(str)) {
                return jsBridge;
            }
        }
        return null;
    }

    public static boolean addBridge(@NonNull JsBridge bridge) {
        List list = a;
        return !list.contains(bridge) && list.add(bridge);
    }

    public static void handleJsCommand(@Nullable MraidWebView webView, @NonNull String commandUrl) {
        Map commandUrl2;
        MraidLog.d("JsBridgeHandler", "handleJsCommand - %s", new Object[]{commandUrl});
        try {
            JsBridge jsBridgeA = a(commandUrl);
            if (jsBridgeA == null || (commandUrl2 = MraidUtils.parseCommandUrl(commandUrl, jsBridgeA.getJsValidator())) == null) {
                return;
            }
            String str = (String) commandUrl2.get("command");
            if (str == null) {
                MraidLog.w("JsBridgeHandler", "handleJsCommand not found", new Object[0]);
            } else {
                jsBridgeA.runJsCommand(webView, str, commandUrl2);
            }
        } catch (Throwable th) {
            MraidLog.e("JsBridgeHandler", th);
        }
    }

    public static boolean isHandled(@Nullable String commandUrl) {
        return a(commandUrl) != null;
    }

    @NonNull
    public static String obtainJs() {
        StringBuilder sb = new StringBuilder();
        for (JsBridge jsBridge : a) {
            sb.append("<script type='application/javascript'>");
            sb.append(jsBridge.getJs());
            sb.append("</script>");
        }
        return sb.toString();
    }

    public static boolean removeBridge(@NonNull JsBridge bridge) {
        List list = a;
        return list.contains(bridge) && list.remove(bridge);
    }
}
