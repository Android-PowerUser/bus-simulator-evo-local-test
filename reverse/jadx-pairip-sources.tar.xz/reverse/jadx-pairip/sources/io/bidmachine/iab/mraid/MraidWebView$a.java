package io.bidmachine.iab.mraid;

import android.view.MotionEvent;
import android.view.View;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class MraidWebView$a implements View.OnTouchListener {
    final /* synthetic */ MraidWebView a;

    public MraidWebView$a(MraidWebView mraidWebView) {
        this.a = mraidWebView;
    }

    @Override // android.view.View.OnTouchListener
    public boolean onTouch(View view, MotionEvent motionEvent) {
        Intrinsics.checkNotNullParameter(view, "view");
        Intrinsics.checkNotNullParameter(motionEvent, "motionEvent");
        MraidWebView.access$getWebViewGestureDetector$p(this.a).onTouchEvent(motionEvent);
        int action = motionEvent.getAction();
        if ((action != 0 && action != 1) || view.hasFocus()) {
            return false;
        }
        view.requestFocus();
        return false;
    }
}
