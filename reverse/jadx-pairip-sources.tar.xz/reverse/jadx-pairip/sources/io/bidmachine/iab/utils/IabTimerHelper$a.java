package io.bidmachine.iab.utils;

import android.view.ViewTreeObserver;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class IabTimerHelper$a implements ViewTreeObserver.OnGlobalLayoutListener {
    final /* synthetic */ IabTimerHelper a;

    IabTimerHelper$a(IabTimerHelper iabTimerHelper) {
        this.a = iabTimerHelper;
    }

    @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
    public void onGlobalLayout() {
        IabTimerHelper.a(this.a);
    }
}
