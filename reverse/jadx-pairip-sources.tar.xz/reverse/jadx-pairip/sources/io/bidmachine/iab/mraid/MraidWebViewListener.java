package io.bidmachine.iab.mraid;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\bf\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&J\u0010\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0007\u001a\u00020\bH&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\tÀ\u0006\u0001"}, d2 = {"Lio/bidmachine/iab/mraid/MraidWebViewListener;", "", "onMraidScreenMetricsChanged", "", "mraidScreenMetrics", "Lio/bidmachine/iab/mraid/MraidScreenMetrics;", "onViewableChanged", "viewable", "", "bidmachine-android-sdk_bi_3_5_1"}, k = 1, mv = {1, 7, 1}, xi = 48)
public interface MraidWebViewListener {
    void onMraidScreenMetricsChanged(@NotNull MraidScreenMetrics mraidScreenMetrics);

    void onViewableChanged(boolean viewable);
}
