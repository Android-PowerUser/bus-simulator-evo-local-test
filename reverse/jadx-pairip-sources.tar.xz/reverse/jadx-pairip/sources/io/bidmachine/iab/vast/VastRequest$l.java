package io.bidmachine.iab.vast;

import java.io.File;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class VastRequest$l implements Comparable {
    public long a;
    public File b;

    public VastRequest$l(File file) {
        this.b = file;
        this.a = file.lastModified();
    }

    @Override // java.lang.Comparable
    public int compareTo(Object obj) {
        long j = this.a;
        long j2 = ((VastRequest$l) obj).a;
        if (j > j2) {
            return -1;
        }
        return j == j2 ? 0 : 1;
    }
}
