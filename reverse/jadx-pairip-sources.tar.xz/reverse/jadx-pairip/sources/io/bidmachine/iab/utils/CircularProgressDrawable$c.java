package io.bidmachine.iab.utils;

import android.animation.Animator;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class CircularProgressDrawable$c implements Animator.AnimatorListener {
    final /* synthetic */ CircularProgressDrawable$d a;
    final /* synthetic */ CircularProgressDrawable b;

    CircularProgressDrawable$c(CircularProgressDrawable circularProgressDrawable, CircularProgressDrawable$d circularProgressDrawable$d) {
        this.b = circularProgressDrawable;
        this.a = circularProgressDrawable$d;
    }

    @Override // android.animation.Animator.AnimatorListener
    public void onAnimationCancel(Animator animator) {
    }

    @Override // android.animation.Animator.AnimatorListener
    public void onAnimationEnd(Animator animator) {
    }

    @Override // android.animation.Animator.AnimatorListener
    public void onAnimationRepeat(Animator animator) {
        CircularProgressDrawable.a(this.b, 1.0f, this.a, true);
        this.a.m();
        this.a.k();
        if (!CircularProgressDrawable.b(this.b)) {
            CircularProgressDrawable circularProgressDrawable = this.b;
            CircularProgressDrawable.a(circularProgressDrawable, CircularProgressDrawable.a(circularProgressDrawable) + 1.0f);
        } else {
            CircularProgressDrawable.a(this.b, false);
            animator.cancel();
            animator.setDuration(1332L);
            animator.start();
        }
    }

    @Override // android.animation.Animator.AnimatorListener
    public void onAnimationStart(Animator animator) {
        CircularProgressDrawable.a(this.b, 0.0f);
    }
}
