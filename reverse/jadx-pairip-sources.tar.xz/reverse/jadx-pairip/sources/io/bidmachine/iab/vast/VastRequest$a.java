package io.bidmachine.iab.vast;

import io.bidmachine.iab.CacheControl;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
/* synthetic */ class VastRequest$a {
    static final /* synthetic */ int[] a;

    static {
        int[] iArr = new int[CacheControl.values().length];
        a = iArr;
        try {
            iArr[CacheControl.FullLoad.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            a[CacheControl.Stream.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            a[CacheControl.PartialLoad.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
    }
}
