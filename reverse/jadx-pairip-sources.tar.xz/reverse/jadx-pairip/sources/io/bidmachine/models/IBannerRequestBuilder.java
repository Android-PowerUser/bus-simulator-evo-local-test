package io.bidmachine.models;

import androidx.annotation.NonNull;
import io.bidmachine.banner.BannerSize;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface IBannerRequestBuilder<SelfType> {
    @Deprecated(since = "3.5.0")
    SelfType setSize(@NonNull BannerSize bannerSize);
}
