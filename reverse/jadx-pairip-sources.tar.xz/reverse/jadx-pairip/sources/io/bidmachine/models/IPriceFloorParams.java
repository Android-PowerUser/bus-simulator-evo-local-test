package io.bidmachine.models;

import androidx.annotation.NonNull;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface IPriceFloorParams<SelfType> {
    SelfType addPriceFloor(double value);

    SelfType addPriceFloor(@NonNull String id, double value);
}
