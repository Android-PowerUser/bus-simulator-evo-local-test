package io.bidmachine.unified;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public abstract class UnifiedNativeAd extends UnifiedAd<UnifiedNativeAdCallback, UnifiedNativeAdRequestParams> {
}
