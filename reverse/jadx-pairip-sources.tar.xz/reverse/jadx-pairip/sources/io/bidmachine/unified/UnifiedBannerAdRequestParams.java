package io.bidmachine.unified;

import androidx.annotation.NonNull;
import io.bidmachine.banner.BannerAdRequestParameters;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface UnifiedBannerAdRequestParams extends UnifiedAdRequestParams {
    @Override // io.bidmachine.unified.UnifiedAdRequestParams
    @NonNull
    BannerAdRequestParameters getAdRequestParameters();
}
