package io.bidmachine.unified;

import androidx.annotation.NonNull;
import io.bidmachine.AdRequestParameters;
import io.bidmachine.GeneralParams;
import io.bidmachine.models.DeviceInfo;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface UnifiedAdRequestParams extends GeneralParams {
    @NonNull
    AdRequestParameters getAdRequestParameters();

    @NonNull
    DeviceInfo getDeviceInfo();
}
