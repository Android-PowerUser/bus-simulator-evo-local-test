package io.bidmachine.rewarded;

import io.bidmachine.AdRequest;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface RewardedRequest$AdRequestListener extends AdRequest.AdRequestListener<RewardedRequest> {
}
