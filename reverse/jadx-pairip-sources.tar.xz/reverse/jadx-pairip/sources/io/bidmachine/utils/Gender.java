package io.bidmachine.utils;

import androidx.annotation.Nullable;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public enum Gender {
    Female("F", 1),
    Male("M", 2),
    Omitted("O", 0);

    private final String ortbValue;
    private final int serverValue;

    Gender(String ortbValue, int serverValue) {
        this.ortbValue = ortbValue;
        this.serverValue = serverValue;
    }

    public String getOrtbValue() {
        return this.ortbValue;
    }

    public int getServerValue() {
        return this.serverValue;
    }

    @Nullable
    public static Gender fromInt(Integer genderInt) {
        if (genderInt == null) {
            return null;
        }
        int iIntValue = genderInt.intValue();
        if (iIntValue == 0) {
            return Omitted;
        }
        if (iIntValue == 1) {
            return Female;
        }
        if (iIntValue != 2) {
            return null;
        }
        return Male;
    }
}
