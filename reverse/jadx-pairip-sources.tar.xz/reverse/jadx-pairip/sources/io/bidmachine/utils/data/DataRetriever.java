package io.bidmachine.utils.data;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import io.bidmachine.Function;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface DataRetriever<K> {
    boolean contains(@NonNull K key);

    boolean getBoolean(@NonNull K key, boolean fallback);

    @Nullable
    Boolean getBooleanOrNull(@NonNull K key, @Nullable Boolean fallback);

    double getDouble(@NonNull K key, double fallback);

    @Nullable
    Double getDoubleOrNull(@NonNull K key, @Nullable Double fallback);

    float getFloat(@NonNull K key, float fallback);

    @Nullable
    Float getFloatOrNull(@NonNull K key, @Nullable Float fallback);

    int getInteger(@NonNull K key, int fallback);

    @Nullable
    Integer getIntegerOrNull(@NonNull K key, @Nullable Integer fallback);

    @Nullable
    List<Object> getListOrNull(@NonNull K key);

    @Nullable
    Map<Object, Object> getMapOrNull(@NonNull K key);

    @Nullable
    Object getObjectOrNull(@NonNull K key, @Nullable Object fallback);

    @Nullable
    <T> T getOrNull(@NonNull K key, @Nullable T fallback) throws Exception;

    @Nullable
    String getStringOrNull(@NonNull K key, @Nullable String fallback);

    @Nullable
    default String getStringOrNull(@NonNull K key) {
        return getStringOrNull(key, null);
    }

    default boolean getBoolean(@NonNull K key) {
        return getBoolean(key, false);
    }

    @Nullable
    default Boolean getBooleanOrNull(@NonNull K key) {
        return getBooleanOrNull(key, Boolean.FALSE);
    }

    default int getInteger(@NonNull K key) {
        return getInteger(key, 0);
    }

    @Nullable
    default Integer getIntegerOrNull(@NonNull K key) {
        return getIntegerOrNull(key, null);
    }

    default float getFloat(@NonNull K key) {
        return getFloat(key, 0.0f);
    }

    @Nullable
    default Float getFloatOrNull(@NonNull K key) {
        return getFloatOrNull(key, null);
    }

    default double getDouble(@NonNull K key) {
        return getDouble(key, 0.0d);
    }

    @Nullable
    default Double getDoubleOrNull(@NonNull K key) {
        return getDoubleOrNull(key, null);
    }

    @Nullable
    default <T> T getOrNull(@NonNull K k) throws Exception {
        return (T) getOrNull(k, null);
    }

    @Nullable
    default <T> T getOrNullSafely(@NonNull K k, @NonNull Function<Object, T> function) {
        return (T) getOrNullSafely(k, null, function);
    }

    @Nullable
    default <T> T getOrNullSafely(@NonNull K k, @Nullable T t, @NonNull Function<Object, T> function) {
        try {
            Object objectOrNull = getObjectOrNull(k, t);
            if (objectOrNull == null) {
                return null;
            }
            return (T) function.apply(objectOrNull);
        } catch (Exception unused) {
            return t;
        }
    }

    @Nullable
    default Object getObjectOrNull(@NonNull K key) {
        return getObjectOrNull(key, null);
    }
}
