package io.bidmachine.utils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import io.bidmachine.iab.CacheControl;
import io.bidmachine.iab.IabError;
import io.bidmachine.iab.utils.IabElementStyle;
import io.bidmachine.protobuf.AdExtension;
import io.bidmachine.protobuf.CreativeLoadingMethod;
import io.bidmachine.util.Utils;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class IabUtils {

    @NonNull
    private static final CacheControl DEFAULT_CACHE_CONTROL = CacheControl.FullLoad;

    @NonNull
    public static CacheControl toCacheControl(@Nullable Object object) {
        CreativeLoadingMethod creativeLoadingMethodValueOf;
        if (object == null) {
            return DEFAULT_CACHE_CONTROL;
        }
        if (object instanceof CacheControl) {
            return (CacheControl) object;
        }
        if (object instanceof CreativeLoadingMethod) {
            creativeLoadingMethodValueOf = (CreativeLoadingMethod) object;
        } else if (object instanceof String) {
            try {
                creativeLoadingMethodValueOf = CreativeLoadingMethod.valueOf((String) object);
            } catch (IllegalArgumentException unused) {
                creativeLoadingMethodValueOf = null;
            }
        } else {
            creativeLoadingMethodValueOf = null;
        }
        if (creativeLoadingMethodValueOf != null) {
            int i = 1.$SwitchMap$io$bidmachine$protobuf$CreativeLoadingMethod[creativeLoadingMethodValueOf.ordinal()];
            if (i == 1) {
                return CacheControl.Stream;
            }
            if (i == 2) {
                return CacheControl.PartialLoad;
            }
            return DEFAULT_CACHE_CONTROL;
        }
        return DEFAULT_CACHE_CONTROL;
    }

    /* JADX WARN: Code duplicated, block: B:15:0x001c  */
    @NonNull
    public static BMError mapError(@NonNull IabError iabError) {
        BMError bMError;
        int code = iabError.getCode();
        if (code == 1) {
            bMError = BMError.NoConnection;
        } else if (code == 3) {
            bMError = BMError.NoFill;
        } else if (code == 5) {
            bMError = BMError.PlaceholderTimeout;
        } else if (code == 6) {
            bMError = BMError.Expired;
        } else if (code == 7) {
            bMError = BMError.NoFill;
        } else {
            bMError = BMError.InternalUnknownError;
        }
        return new BMError(bMError, code, iabError.getMessage());
    }

    @Nullable
    public static IabElementStyle transform(@Nullable AdExtension.ControlAsset extensionControlView) {
        if (extensionControlView == null) {
            return null;
        }
        try {
            IabElementStyle iabElementStyle = new IabElementStyle();
            iabElementStyle.setMargin(extensionControlView.getMargin());
            iabElementStyle.setPadding(extensionControlView.getPadding());
            iabElementStyle.setContent(extensionControlView.getContent());
            iabElementStyle.setFillColor(Utils.parseColorARGBSafely(extensionControlView.getFill()));
            iabElementStyle.setFontStyle(Integer.valueOf(extensionControlView.getFontStyle()));
            iabElementStyle.setWidth(Integer.valueOf(extensionControlView.getWidth()));
            iabElementStyle.setHeight(Integer.valueOf(extensionControlView.getHeight()));
            iabElementStyle.setHideAfter(Float.valueOf(extensionControlView.getHideafter()));
            iabElementStyle.setHorizontalPosition(io.bidmachine.core.Utils.parseHorizontalPosition(extensionControlView.getX()));
            iabElementStyle.setVerticalPosition(io.bidmachine.core.Utils.parseVerticalPosition(extensionControlView.getY()));
            iabElementStyle.setOpacity(Float.valueOf(extensionControlView.getOpacity()));
            iabElementStyle.setOutlined(Boolean.valueOf(extensionControlView.getOutlined()));
            iabElementStyle.setStrokeColor(Utils.parseColorARGBSafely(extensionControlView.getStroke()));
            iabElementStyle.setStrokeWidth(Float.valueOf(extensionControlView.getStrokeWidth()));
            iabElementStyle.setStyle(extensionControlView.getStyle());
            iabElementStyle.setVisible(Boolean.valueOf(extensionControlView.getVisible()));
            return iabElementStyle;
        } catch (Exception unused) {
            return null;
        }
    }
}
