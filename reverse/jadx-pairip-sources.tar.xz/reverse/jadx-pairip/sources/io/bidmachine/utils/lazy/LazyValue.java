package io.bidmachine.utils.lazy;

import androidx.annotation.NonNull;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface LazyValue<T> {
    @NonNull
    T get();
}
