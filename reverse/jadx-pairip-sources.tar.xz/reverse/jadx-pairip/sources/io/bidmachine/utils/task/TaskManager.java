package io.bidmachine.utils.task;

import androidx.annotation.NonNull;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface TaskManager {
    void cancel(@NonNull CancelableTask task);

    void execute(@NonNull Runnable task);

    void schedule(@NonNull CancelableTask task, long delay, @NonNull TimeUnit timeUnit);

    default void schedule(@NonNull CancelableTask task, long delayMs) {
        schedule(task, delayMs, TimeUnit.MILLISECONDS);
    }
}
