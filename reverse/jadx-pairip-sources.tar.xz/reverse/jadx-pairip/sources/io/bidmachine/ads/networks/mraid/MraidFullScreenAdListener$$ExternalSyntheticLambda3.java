package io.bidmachine.ads.networks.mraid;

import io.bidmachine.iab.utils.IabClickCallback;
import io.bidmachine.util.SafeExecutable;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class MraidFullScreenAdListener$$ExternalSyntheticLambda3 implements SafeExecutable {
    public final /* synthetic */ IabClickCallback f$0;

    public final void onExecute(Object obj) {
        MraidFullScreenAdListener.$r8$lambda$3mSkAdG5tKXjFAM693vjCGpQQxc(this.f$0, (Boolean) obj);
    }
}
