package io.bidmachine.ads.networks.gam_dynamic;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
enum InternalAd$Status {
    Idle,
    Loading,
    Loaded,
    Showing,
    Shown,
    Expired
}
