package io.bidmachine.ads.networks.gam;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import io.bidmachine.ContextProvider;
import io.bidmachine.NetworkAdUnit;
import io.bidmachine.core.VisibilitySource;
import io.bidmachine.unified.UnifiedBannerAd;
import io.bidmachine.unified.UnifiedBannerAdCallback;
import io.bidmachine.unified.UnifiedBannerAdRequestParams;
import io.bidmachine.unified.UnifiedMediationParams;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class GAMBanner extends UnifiedBannerAd {
    static final /* synthetic */ boolean $assertionsDisabled = false;

    @Nullable
    private InternalGAMBannerAd gamBannerAd;

    @NonNull
    private final GAMNetwork gamNetwork;

    @Nullable
    private InternalGAMBannerAdListener listener;

    protected GAMBanner(@NonNull GAMNetwork gamNetwork) {
        this.gamNetwork = gamNetwork;
    }

    public void load(@NonNull ContextProvider contextProvider, @NonNull UnifiedBannerAdCallback callback, @NonNull UnifiedBannerAdRequestParams requestParams, @NonNull UnifiedMediationParams unifiedMediationParams, @NonNull NetworkAdUnit networkAdUnit) throws Throwable {
        if (new GAMParams(unifiedMediationParams).isValid(callback)) {
            if (!this.gamNetwork.isOverrideCallbacks()) {
                callback.setVisibilitySource(VisibilitySource.BidMachine);
            }
            Listener listener = new Listener(this, callback, (1) null);
            this.listener = listener;
            this.gamNetwork.loadBanner(networkAdUnit, listener);
        }
    }

    public void onShown() {
        super/*io.bidmachine.unified.UnifiedAd*/.onShown();
        InternalGAMBannerAd internalGAMBannerAd = this.gamBannerAd;
        if (internalGAMBannerAd != null) {
            internalGAMBannerAd.onAdShown();
        }
    }

    public void onDestroy() {
        this.listener = null;
        InternalGAMBannerAd internalGAMBannerAd = this.gamBannerAd;
        if (internalGAMBannerAd != null) {
            internalGAMBannerAd.destroy();
            this.gamBannerAd = null;
        }
    }
}
