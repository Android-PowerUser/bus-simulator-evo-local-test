package io.bidmachine.ads.networks.mraid;

import android.content.Context;
import io.bidmachine.core.Logger;
import io.bidmachine.iab.mraid.MraidInterstitial;
import io.bidmachine.unified.UnifiedFullscreenAdCallback;
import io.bidmachine.utils.BMError;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class MraidFullScreenAd$1 implements Runnable {
    final /* synthetic */ MraidFullScreenAd this$0;
    final /* synthetic */ Context val$applicationContext;
    final /* synthetic */ UnifiedFullscreenAdCallback val$callback;
    final /* synthetic */ String val$creativeAdm;
    final /* synthetic */ MraidParams val$mraidParams;

    MraidFullScreenAd$1(final MraidFullScreenAd this$0, final MraidParams val$mraidParams, final Context val$applicationContext, final UnifiedFullscreenAdCallback val$callback, final String val$creativeAdm) {
        this.this$0 = this$0;
        this.val$mraidParams = val$mraidParams;
        this.val$applicationContext = val$applicationContext;
        this.val$callback = val$callback;
        this.val$creativeAdm = val$creativeAdm;
    }

    @Override // java.lang.Runnable
    public void run() {
        try {
            MraidFullScreenAd.access$002(this.this$0, MraidInterstitial.newBuilder().setCacheControl(this.val$mraidParams.cacheControl).setPlaceholderTimeoutSec(this.val$mraidParams.placeholderTimeoutSec).setCloseTime(this.val$mraidParams.skipOffset).forceUseNativeCloseButton(this.val$mraidParams.useNativeClose).setListener(new MraidFullScreenAdListener(this.val$applicationContext, this.val$callback, MraidFullScreenAd.access$100(this.this$0))).setR1(this.val$mraidParams.r1).setR2(this.val$mraidParams.r2).setDurationSec(this.val$mraidParams.progressDuration).setProductLink(this.val$mraidParams.storeUrl).setCloseStyle(this.val$mraidParams.closeableViewStyle).setCountDownStyle(this.val$mraidParams.countDownStyle).setProgressStyle(this.val$mraidParams.progressStyle).setAdMeasurer(MraidFullScreenAd.access$100(this.this$0)).build(this.val$applicationContext));
            MraidFullScreenAd.access$000(this.this$0).load(this.val$creativeAdm);
        } catch (Throwable th) {
            Logger.w(th);
            this.val$callback.onAdLoadFailed(BMError.throwable("Exception loading MRAID fullscreen object", th));
        }
    }
}
