package io.bidmachine.ads.networks.vast;

import androidx.annotation.NonNull;
import io.bidmachine.iab.IabError;
import io.bidmachine.iab.vast.VastRequest;
import io.bidmachine.iab.vast.VastRequestListener;
import io.bidmachine.unified.UnifiedFullscreenAdCallback;
import io.bidmachine.utils.IabUtils;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class VastFullScreenAdLoadListener implements VastRequestListener {

    @NonNull
    private final UnifiedFullscreenAdCallback callback;

    VastFullScreenAdLoadListener(@NonNull UnifiedFullscreenAdCallback callback) {
        this.callback = callback;
    }

    public void onVastLoaded(@NonNull VastRequest vastRequest) {
        this.callback.onAdLoaded();
    }

    public void onVastLoadFailed(@NonNull VastRequest vastRequest, @NonNull IabError iabError) {
        if (iabError.getCode() == 6) {
            this.callback.onAdExpired();
        } else {
            this.callback.onAdLoadFailed(IabUtils.mapError(iabError));
        }
    }
}
