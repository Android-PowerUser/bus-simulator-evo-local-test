package io.bidmachine.ads.networks.gam.versions.v22_0_0;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.VersionInfo;
import io.bidmachine.AdsFormat;
import io.bidmachine.ads.networks.gam.GAMLoader;
import io.bidmachine.ads.networks.gam.GAMUnitData;
import io.bidmachine.ads.networks.gam.InternalGAMAd;
import io.bidmachine.ads.networks.gam.versions.BaseVersionWrapper;
import io.bidmachine.utils.version.Version;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class VersionWrapperImpl extends BaseVersionWrapper {
    public VersionWrapperImpl() {
        super(19, new Version(22, 0, 0));
    }

    private boolean a(Context context) {
        try {
            Bundle bundle = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128).metaData;
            if (bundle == null) {
                return false;
            }
            return !TextUtils.isEmpty(bundle.getString("com.google.android.gms.ads.APPLICATION_ID"));
        } catch (Exception unused) {
            return false;
        }
    }

    @Nullable
    public InternalGAMAd createAd(@NonNull GAMLoader gamLoader, @NonNull AdsFormat adsFormat, @NonNull GAMUnitData gamUnitData) {
        switch (a.a[adsFormat.ordinal()]) {
            case 1:
            case 2:
                return new c(gamLoader, adsFormat, gamUnitData, AdSize.BANNER);
            case 3:
                return new c(gamLoader, adsFormat, gamUnitData, AdSize.LEADERBOARD);
            case 4:
                return new c(gamLoader, adsFormat, gamUnitData, AdSize.MEDIUM_RECTANGLE);
            case 5:
            case 6:
            case 7:
                return new d(gamLoader, adsFormat, gamUnitData);
            case 8:
            case 9:
            case 10:
                return new e(gamLoader, adsFormat, gamUnitData);
            default:
                return null;
        }
    }

    @Nullable
    public Version getVersion() {
        VersionInfo version = MobileAds.getVersion();
        return new Version(version.getMajorVersion(), version.getMinorVersion(), version.getMicroVersion());
    }

    @SuppressLint({"MissingPermission"})
    public void initialize(@NonNull Context context) {
        MobileAds.initialize(context);
    }

    public boolean isGAMPresent(@NonNull Context context) {
        return a(context) && a();
    }

    private boolean a() {
        try {
            Class.forName("com.google.android.gms.ads.admanager.AdManagerAdView");
            return true;
        } catch (Exception unused) {
            return false;
        }
    }
}
