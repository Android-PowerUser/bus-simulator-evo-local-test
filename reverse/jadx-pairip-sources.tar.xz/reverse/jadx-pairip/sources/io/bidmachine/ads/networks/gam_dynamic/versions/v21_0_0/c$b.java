package io.bidmachine.ads.networks.gam_dynamic.versions.v21_0_0;

import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.admanager.AdManagerInterstitialAd;
import com.google.android.gms.ads.admanager.AdManagerInterstitialAdLoadCallback;
import io.bidmachine.ads.networks.gam_dynamic.InternalAdLoadData;
import io.bidmachine.ads.networks.gam_dynamic.InternalLoadListener;
import io.bidmachine.utils.BMError;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class c$b extends AdManagerInterstitialAdLoadCallback {
    private final c a;
    private final InternalLoadListener b;

    public c$b(c cVar, InternalLoadListener internalLoadListener) {
        this.a = cVar;
        this.b = internalLoadListener;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(AdManagerInterstitialAd adManagerInterstitialAd) {
        InternalAdLoadData internalAdLoadDataA = e.a(adManagerInterstitialAd);
        this.a.onAdLoaded(internalAdLoadDataA);
        this.b.onAdLoaded(this.a, internalAdLoadDataA);
    }

    public void onAdFailedToLoad(LoadAdError loadAdError) {
        c.b(this.a, new c$b$.ExternalSyntheticLambda1(this, loadAdError));
    }

    public void onAdLoaded(AdManagerInterstitialAd adManagerInterstitialAd) {
        adManagerInterstitialAd.setOnPaidEventListener(new c$c(this.a));
        c.a(this.a, adManagerInterstitialAd);
        c.a(this.a, new c$b$.ExternalSyntheticLambda0(this, adManagerInterstitialAd));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(LoadAdError loadAdError) {
        this.b.onAdLoadFailed(this.a, e.a(BMError.NoFill, loadAdError));
    }
}
