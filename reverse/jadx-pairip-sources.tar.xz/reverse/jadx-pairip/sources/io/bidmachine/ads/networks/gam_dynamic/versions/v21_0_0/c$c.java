package io.bidmachine.ads.networks.gam_dynamic.versions.v21_0_0;

import androidx.annotation.NonNull;
import com.google.android.gms.ads.AdValue;
import com.google.android.gms.ads.OnPaidEventListener;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class c$c implements OnPaidEventListener {
    private final c a;

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(AdValue adValue) {
        this.a.onPaidEvent(e.a(adValue));
    }

    public void onPaidEvent(AdValue adValue) {
        c.c(this.a, new c$c$.ExternalSyntheticLambda0(this, adValue));
    }

    private c$c(@NonNull c versionInterstitialAd) {
        this.a = versionInterstitialAd;
    }
}
