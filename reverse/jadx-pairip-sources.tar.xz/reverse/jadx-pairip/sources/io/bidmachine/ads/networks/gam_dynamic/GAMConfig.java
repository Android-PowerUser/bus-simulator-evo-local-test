package io.bidmachine.ads.networks.gam_dynamic;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import io.bidmachine.NetworkAdapter;
import io.bidmachine.NetworkConfig;
import java.util.Map;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class GAMConfig extends NetworkConfig {

    @NonNull
    static final String KEY_AD_UNIT_ID = "ad_unit_id";

    @NonNull
    static final String KEY_CONTEXT = "context";

    @NonNull
    static final String KEY_PRICE = "price";

    @NonNull
    static final String KEY_SUPPORTED_VERSIONS_RANGE = "supported_versions_range";

    public GAMConfig(@Nullable Map<String, String> networkConfig) {
        super("gam_dynamic", networkConfig);
    }

    public GAMConfig(@NonNull String networkKey, @Nullable Map<String, String> networkParams) {
        super(networkKey, networkParams);
    }

    @NonNull
    protected NetworkAdapter createNetworkAdapter() {
        return new GAMAdapter(getNetworkKey());
    }
}
