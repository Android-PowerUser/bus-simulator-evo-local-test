package io.bidmachine.ads.networks.mraid;

import android.content.Context;
import io.bidmachine.Executable;
import io.bidmachine.rendering.model.PrivacySheetParams;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class MraidFullScreenAdListener$$ExternalSyntheticLambda0 implements Executable {
    public final /* synthetic */ PrivacySheetParams f$0;

    public final void execute(Object obj) {
        MraidFullScreenAdListener.$r8$lambda$dhFnQ6WqavZKvUqnH6wGURoKumc(this.f$0, (Context) obj);
    }
}
