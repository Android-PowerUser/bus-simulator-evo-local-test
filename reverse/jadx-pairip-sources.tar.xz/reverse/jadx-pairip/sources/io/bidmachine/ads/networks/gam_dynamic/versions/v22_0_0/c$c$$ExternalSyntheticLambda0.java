package io.bidmachine.ads.networks.gam_dynamic.versions.v22_0_0;

import com.google.android.gms.ads.AdValue;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class c$c$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ c.c f$0;
    public final /* synthetic */ AdValue f$1;

    public /* synthetic */ c$c$$ExternalSyntheticLambda0(c.c cVar, AdValue adValue) {
        this.f$0 = cVar;
        this.f$1 = adValue;
    }

    @Override // java.lang.Runnable
    public final void run() {
        c.c.$r8$lambda$k6WTgeauXBth2HMPgmMRyg9KJds(this.f$0, this.f$1);
    }
}
