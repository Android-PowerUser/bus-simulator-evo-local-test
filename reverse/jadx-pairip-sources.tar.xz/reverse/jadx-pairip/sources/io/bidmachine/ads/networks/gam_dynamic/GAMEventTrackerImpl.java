package io.bidmachine.ads.networks.gam_dynamic;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import io.bidmachine.AdsFormat;
import io.bidmachine.TrackEventType;
import io.bidmachine.protobuf.AdExtension;
import io.bidmachine.tracking.EventData;
import io.bidmachine.tracking.EventTrackerImpl;
import io.bidmachine.tracking.SimpleTrackingObject;
import io.bidmachine.tracking.TrackEventInfo;
import io.bidmachine.utils.BMError;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class GAMEventTrackerImpl extends EventTrackerImpl implements GAMEventTracker {
    GAMEventTrackerImpl(@NonNull AdExtension.EventConfiguration eventConfiguration) {
        super(eventConfiguration);
    }

    public void trackEvent(@NonNull TrackEventType trackEventType, @NonNull AdsFormat adsFormat, @NonNull EventData eventData, @Nullable BMError bmError) {
        trackEvent(new SimpleTrackingObject(), trackEventType, (TrackEventInfo) null, adsFormat.getAdsType(), bmError, eventData);
    }
}
