package io.bidmachine.ads.networks.adaptiverendering.measurer;

import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.UiThread;
import com.iab.omid.library.appodeal.adsession.AdEvents;
import com.iab.omid.library.appodeal.adsession.AdSession;
import com.iab.omid.library.appodeal.adsession.AdSessionConfiguration;
import com.iab.omid.library.appodeal.adsession.AdSessionContext;
import com.iab.omid.library.appodeal.adsession.ErrorType;
import com.iab.omid.library.appodeal.adsession.media.MediaEvents;
import io.bidmachine.core.Logger;
import io.bidmachine.core.Utils;
import io.bidmachine.rendering.measurer.Measurer;
import io.bidmachine.rendering.model.Error;
import io.bidmachine.utils.Tag;
import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public abstract class OMMeasurer<AdView extends View> implements Measurer<AdView> {

    @Nullable
    private AdEvents adEvents;

    @Nullable
    private AdSession adSession;

    @Nullable
    protected MediaEvents mediaEvents;

    @NonNull
    private final Tag tag = new Tag("OMMeasurer");

    @NonNull
    private final AtomicBoolean isLoadedTracked = new AtomicBoolean(false);

    @NonNull
    private final AtomicBoolean isShownTracked = new AtomicBoolean(false);

    protected long getDestroyDelayMs() {
        return 0L;
    }

    @UiThread
    protected abstract void onAdLoaded(@NonNull AdEvents adEvents) throws Throwable;

    public void onViewAddedToContainer(@NonNull AdView adView, @NonNull ViewGroup viewGroup) {
    }

    public void onViewCreated(@NonNull AdView adView) {
    }

    public void onViewReady(@NonNull AdView adView) {
    }

    public void onShown() {
        if (this.isShownTracked.compareAndSet(false, true)) {
            Utils.onUiThread(new 1(this));
        }
    }

    public void onClicked() {
        Utils.onUiThread(new 2(this));
    }

    public void onError(@NonNull Error error) {
        trackError(error.getMessage());
    }

    public void destroy(@Nullable Runnable postback) {
        Utils.onUiThread(new 3(this, postback, Utils.createHandlerWithMyOrMainLooper()));
    }

    protected void trackLoaded() {
        if (this.isLoadedTracked.compareAndSet(false, true)) {
            Utils.onUiThread(new 4(this));
        }
    }

    public void trackError(@NonNull String errorMessage) {
        trackError(ErrorType.GENERIC, errorMessage);
    }

    public void trackVideoError(@NonNull String errorMessage) {
        trackError(ErrorType.VIDEO, errorMessage);
    }

    private void trackError(@NonNull ErrorType errorType, @NonNull String errorMessage) {
        Utils.onUiThread(new 5(this, errorType, errorMessage));
    }

    protected boolean isSessionPrepared() {
        return this.adSession != null;
    }

    protected void log(@NonNull String message) {
        Logger.d(this.tag, message);
    }

    @UiThread
    protected void prepareAdSession(@NonNull AdSessionConfiguration adSessionConfiguration, @NonNull AdSessionContext adSessionContext) {
        try {
            AdSession adSessionCreateAdSession = AdSession.createAdSession(adSessionConfiguration, adSessionContext);
            this.adSession = adSessionCreateAdSession;
            this.adEvents = AdEvents.createAdEvents(adSessionCreateAdSession);
            if (adSessionConfiguration.isNativeMediaEventsOwner()) {
                this.mediaEvents = MediaEvents.createMediaEvents(this.adSession);
            }
            this.adSession.start();
            log("prepareAdSession");
        } catch (Throwable th) {
            Logger.w(th);
        }
    }

    protected void registerView(@NonNull View view) {
        Utils.onUiThread(new 6(this, view));
    }
}
