package io.bidmachine.ads.networks.gam_dynamic.versions.v22_0_0;

import com.google.android.gms.ads.LoadAdError;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class d$b$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ d.b f$0;
    public final /* synthetic */ LoadAdError f$1;

    public /* synthetic */ d$b$$ExternalSyntheticLambda1(d.b bVar, LoadAdError loadAdError) {
        this.f$0 = bVar;
        this.f$1 = loadAdError;
    }

    @Override // java.lang.Runnable
    public final void run() {
        d.b.$r8$lambda$O4j2OtQTTzHlZlkqbiMUyGHfzA0(this.f$0, this.f$1);
    }
}
