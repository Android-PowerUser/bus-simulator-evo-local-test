package io.bidmachine.ads.networks.gam.versions.v23_0_0;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.FullScreenContentCallback;
import io.bidmachine.ads.networks.gam.InternalGAMFullscreenAdPresentListener;
import io.bidmachine.utils.BMError;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class b extends FullScreenContentCallback {
    private final InternalGAMFullscreenAdPresentListener a;

    b(InternalGAMFullscreenAdPresentListener internalGAMFullscreenAdPresentListener) {
        this.a = internalGAMFullscreenAdPresentListener;
    }

    public void onAdClicked() {
        this.a.onAdClicked();
    }

    public void onAdDismissedFullScreenContent() {
        this.a.onAdComplete();
        this.a.onAdClosed();
    }

    public void onAdFailedToShowFullScreenContent(AdError adError) {
        this.a.onAdShowFailed(new BMError(BMError.InternalUnknownError, adError.getCode(), adError.getMessage()));
    }

    public void onAdImpression() {
        this.a.onAdShown();
    }
}
