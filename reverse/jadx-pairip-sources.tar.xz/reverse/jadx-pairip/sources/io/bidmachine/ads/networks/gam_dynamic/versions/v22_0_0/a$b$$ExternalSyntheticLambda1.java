package io.bidmachine.ads.networks.gam_dynamic.versions.v22_0_0;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class a$b$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ a.b f$0;

    @Override // java.lang.Runnable
    public final void run() {
        a.b.$r8$lambda$NQ-YBKabZ6tx5ZBBUvA66u7qPho(this.f$0);
    }
}
