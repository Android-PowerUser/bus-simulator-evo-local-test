package io.bidmachine.ads.networks.gam_dynamic;

import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;
import io.bidmachine.unified.UnifiedFullscreenAdCallback;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@VisibleForTesting
final class GAMRewardedAd$Listener extends GAMFullscreenAdListener<InternalRewardedAd> implements InternalRewardedAdListener {
    GAMRewardedAd$Listener(@NonNull UnifiedFullscreenAdCallback unifiedFullscreenAdCallback, @NonNull GAMFullscreenAd gamFullscreenAd) {
        super(unifiedFullscreenAdCallback, gamFullscreenAd);
    }
}
