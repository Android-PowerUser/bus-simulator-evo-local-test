package io.bidmachine.ads.networks.gam;

import io.bidmachine.AdsFormat;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class GAMLoader$GAMTaskLoader$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ GAMLoader.GAMTaskLoader f$0;
    public final /* synthetic */ GAMLoader.LoadAdUnitListTask f$1;
    public final /* synthetic */ AdsFormat f$2;

    public /* synthetic */ GAMLoader$GAMTaskLoader$$ExternalSyntheticLambda0(GAMLoader.GAMTaskLoader gAMTaskLoader, GAMLoader.LoadAdUnitListTask loadAdUnitListTask, AdsFormat adsFormat) {
        this.f$0 = gAMTaskLoader;
        this.f$1 = loadAdUnitListTask;
        this.f$2 = adsFormat;
    }

    @Override // java.lang.Runnable
    public final void run() {
        GAMLoader.GAMTaskLoader.$r8$lambda$5eQs10Tb9KFDvyp3lwUVxAmrJyU(this.f$0, this.f$1, this.f$2);
    }
}
