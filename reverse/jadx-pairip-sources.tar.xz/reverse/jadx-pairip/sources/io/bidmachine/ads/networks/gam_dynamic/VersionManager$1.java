package io.bidmachine.ads.networks.gam_dynamic;

import io.bidmachine.ads.networks.gam_dynamic.versions.VersionWrapper;
import io.bidmachine.ads.networks.gam_dynamic.versions.v21_0_0.VersionWrapperImpl;
import java.util.ArrayList;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class VersionManager$1 extends ArrayList<VersionWrapper> {
    VersionManager$1() {
        add(new VersionWrapperImpl());
        add(new io.bidmachine.ads.networks.gam_dynamic.versions.v22_0_0.VersionWrapperImpl());
        add(new io.bidmachine.ads.networks.gam_dynamic.versions.v23_0_0.VersionWrapperImpl());
    }
}
