package io.bidmachine.ads.networks.gam_dynamic;

import androidx.annotation.NonNull;
import io.bidmachine.ads.networks.gam_dynamic.InternalFullscreenAd;
import io.bidmachine.unified.UnifiedFullscreenAdCallback;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class GAMFullscreenAdListener<InternalAdType extends InternalFullscreenAd> extends GAMBaseAdListener<InternalAdType, UnifiedFullscreenAdCallback> implements InternalAdLoadListener<InternalAdType>, InternalFullscreenAdPresentListener {

    @NonNull
    private final GAMFullscreenAd gamFullscreenAd;

    GAMFullscreenAdListener(@NonNull UnifiedFullscreenAdCallback callback, @NonNull GAMFullscreenAd gamFullscreenAd) {
        super(callback);
        this.gamFullscreenAd = gamFullscreenAd;
    }

    public void onAdLoaded(@NonNull InternalAdType internalAd) {
        this.gamFullscreenAd.internalFullscreenAd = internalAd;
        getCallback().onAdLoaded();
    }

    public void onAdComplete() {
        getCallback().onAdFinished();
    }

    public void onAdClosed() {
        getCallback().onAdClosed();
    }
}
