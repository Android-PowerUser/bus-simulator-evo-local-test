package io.bidmachine.ads.networks.adaptiverendering.measurer;

import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.FloatRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import com.iab.omid.library.appodeal.adsession.AdEvents;
import com.iab.omid.library.appodeal.adsession.VerificationScriptResource;
import com.iab.omid.library.appodeal.adsession.media.Position;
import com.iab.omid.library.appodeal.adsession.media.VastProperties;
import io.bidmachine.core.Utils;
import io.bidmachine.rendering.measurer.VideoMeasurer;
import java.util.List;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class OMVideoMeasurer extends OMMeasurer<View> implements VideoMeasurer {
    private static final boolean IS_AUTO_PLAY = true;

    @NonNull
    @VisibleForTesting
    final VastProperties vastProperties;

    @NonNull
    @VisibleForTesting
    final List<VerificationScriptResource> verificationScriptResourceList;

    public OMVideoMeasurer(@NonNull List<VerificationScriptResource> verificationScriptResourceList, @Nullable Float skipOffsetSec) {
        VastProperties vastPropertiesCreateVastPropertiesForNonSkippableMedia;
        this.verificationScriptResourceList = verificationScriptResourceList;
        if (skipOffsetSec != null && skipOffsetSec.floatValue() >= 0.0f) {
            vastPropertiesCreateVastPropertiesForNonSkippableMedia = VastProperties.createVastPropertiesForSkippableMedia(skipOffsetSec.floatValue(), IS_AUTO_PLAY, Position.STANDALONE);
        } else {
            vastPropertiesCreateVastPropertiesForNonSkippableMedia = VastProperties.createVastPropertiesForNonSkippableMedia(IS_AUTO_PLAY, Position.STANDALONE);
        }
        this.vastProperties = vastPropertiesCreateVastPropertiesForNonSkippableMedia;
    }

    @Override // io.bidmachine.ads.networks.adaptiverendering.measurer.OMMeasurer
    public void onViewCreated(@NonNull View view) {
        startAdSession();
    }

    @Override // io.bidmachine.ads.networks.adaptiverendering.measurer.OMMeasurer
    public void onViewReady(@NonNull View view) {
        trackLoaded();
    }

    @Override // io.bidmachine.ads.networks.adaptiverendering.measurer.OMMeasurer
    public void onViewAddedToContainer(@NonNull View view, @NonNull ViewGroup viewGroup) {
        registerView(viewGroup);
    }

    public void onMediaStarted(float durationMs, @FloatRange(from = 0.0d, to = 1.0d) float volume) {
        Utils.onUiThread(new 1(this, durationMs, volume));
    }

    public void onMediaFirstQuartile() {
        Utils.onUiThread(new 2(this));
    }

    public void onMediaMidpoint() {
        Utils.onUiThread(new 3(this));
    }

    public void onMediaThirdQuartile() {
        Utils.onUiThread(new 4(this));
    }

    public void onMediaCompleted() {
        Utils.onUiThread(new 5(this));
    }

    public void onMediaPaused() {
        Utils.onUiThread(new 6(this));
    }

    public void onMediaResumed() {
        Utils.onUiThread(new 7(this));
    }

    public void onMediaVolumeChanged(@FloatRange(from = 0.0d, to = 1.0d) float volume) {
        Utils.onUiThread(new 8(this, volume));
    }

    public void onMediaSkipped() {
        Utils.onUiThread(new 9(this));
    }

    @Override // io.bidmachine.ads.networks.adaptiverendering.measurer.OMMeasurer
    protected void onAdLoaded(@NonNull AdEvents adEvents) throws Throwable {
        adEvents.loaded(this.vastProperties);
    }

    protected void startAdSession() {
        Utils.onUiThread(new 10(this));
    }
}
