package io.bidmachine.ads.networks.mraid;

import io.bidmachine.core.Logger;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class MraidFullScreenAd$2 implements Runnable {
    final /* synthetic */ MraidFullScreenAd this$0;

    MraidFullScreenAd$2(final MraidFullScreenAd this$0) {
        this.this$0 = this$0;
    }

    @Override // java.lang.Runnable
    public void run() {
        try {
            MraidFullScreenAd.access$200(this.this$0);
        } catch (Throwable th) {
            Logger.w(th);
        }
    }
}
