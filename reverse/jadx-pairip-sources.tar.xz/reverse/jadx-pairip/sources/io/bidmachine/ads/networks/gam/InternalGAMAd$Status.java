package io.bidmachine.ads.networks.gam;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
enum InternalGAMAd$Status {
    Idle,
    Loading,
    Loaded,
    Showing,
    Shown,
    Expired
}
