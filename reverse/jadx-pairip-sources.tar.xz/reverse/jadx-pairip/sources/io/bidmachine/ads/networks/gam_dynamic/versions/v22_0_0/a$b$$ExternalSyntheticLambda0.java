package io.bidmachine.ads.networks.gam_dynamic.versions.v22_0_0;

import com.google.android.gms.ads.LoadAdError;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class a$b$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ a.b f$0;
    public final /* synthetic */ LoadAdError f$1;

    public /* synthetic */ a$b$$ExternalSyntheticLambda0(a.b bVar, LoadAdError loadAdError) {
        this.f$0 = bVar;
        this.f$1 = loadAdError;
    }

    @Override // java.lang.Runnable
    public final void run() {
        a.b.$r8$lambda$wVeklIfLgbJxDjBJ1m4oHFpXl0A(this.f$0, this.f$1);
    }
}
