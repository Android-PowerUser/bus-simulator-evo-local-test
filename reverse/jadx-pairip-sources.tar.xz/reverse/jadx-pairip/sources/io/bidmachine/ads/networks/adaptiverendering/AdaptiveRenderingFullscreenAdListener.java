package io.bidmachine.ads.networks.adaptiverendering;

import android.content.Context;
import io.bidmachine.core.Utils;
import io.bidmachine.rendering.ad.fullscreen.FullScreenAd;
import io.bidmachine.rendering.ad.fullscreen.FullScreenAdListener;
import io.bidmachine.rendering.model.BrokenCreativeEvent;
import io.bidmachine.rendering.model.Error;
import io.bidmachine.rendering.model.PrivacySheetParams;
import io.bidmachine.rendering.view.PrivacySheetDialog;
import io.bidmachine.rendering.view.PrivacySheetDialog$Companion;
import io.bidmachine.unified.UnifiedFullscreenAdCallback;
import io.bidmachine.utils.BMError;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: AdaptiveRenderingFullscreenAdListener.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0000\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0016J\u0010\u0010\u000e\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0016J\u0010\u0010\u000f\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0016J\u0010\u0010\u0010\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0016J\u0018\u0010\u0011\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u0012\u001a\u00020\u0013H\u0016J\u0018\u0010\u0014\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u0012\u001a\u00020\u0013H\u0016J\u0010\u0010\u0015\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0016J\u0010\u0010\u0016\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0016J\u0010\u0010\u0017\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0016J\u0018\u0010\u0018\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u0019\u001a\u00020\u001aH\u0016J\u0018\u0010\u001b\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u001c\u001a\u00020\u001dH\u0016R\u000e\u0010\u0007\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u001e"}, d2 = {"Lio/bidmachine/ads/networks/adaptiverendering/AdaptiveRenderingFullscreenAdListener;", "Lio/bidmachine/rendering/ad/fullscreen/FullScreenAdListener;", "context", "Landroid/content/Context;", "callback", "Lio/bidmachine/unified/UnifiedFullscreenAdCallback;", "(Landroid/content/Context;Lio/bidmachine/unified/UnifiedFullscreenAdCallback;)V", "applicationContext", "isShown", "", "onAdAppeared", "", "fullScreenAd", "Lio/bidmachine/rendering/ad/fullscreen/FullScreenAd;", "onAdClicked", "onAdDisappeared", "onAdExpired", "onAdFailToLoad", "error", "Lio/bidmachine/rendering/model/Error;", "onAdFailToShow", "onAdFinished", "onAdLoaded", "onAdShown", "onBrokenCreativeEvent", "brokenCreativeEvent", "Lio/bidmachine/rendering/model/BrokenCreativeEvent;", "onOpenPrivacySheet", "privacySheetParams", "Lio/bidmachine/rendering/model/PrivacySheetParams;", "bidmachine-android-sdk_bh_3_5_1"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class AdaptiveRenderingFullscreenAdListener implements FullScreenAdListener {

    @NotNull
    private final Context applicationContext;

    @NotNull
    private final UnifiedFullscreenAdCallback callback;
    private volatile boolean isShown;

    public void onAdAppeared(@NotNull FullScreenAd fullScreenAd) {
        Intrinsics.checkNotNullParameter(fullScreenAd, "fullScreenAd");
    }

    public void onAdDisappeared(@NotNull FullScreenAd fullScreenAd) {
        Intrinsics.checkNotNullParameter(fullScreenAd, "fullScreenAd");
    }

    public AdaptiveRenderingFullscreenAdListener(@NotNull Context context, @NotNull UnifiedFullscreenAdCallback unifiedFullscreenAdCallback) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(unifiedFullscreenAdCallback, "callback");
        this.callback = unifiedFullscreenAdCallback;
        Context applicationContext = context.getApplicationContext();
        Intrinsics.checkNotNullExpressionValue(applicationContext, "context.applicationContext");
        this.applicationContext = applicationContext;
    }

    public void onAdLoaded(@NotNull FullScreenAd fullScreenAd) {
        Intrinsics.checkNotNullParameter(fullScreenAd, "fullScreenAd");
        this.callback.onAdLoaded();
    }

    public void onAdFailToLoad(@NotNull FullScreenAd fullScreenAd, @NotNull Error error) {
        Intrinsics.checkNotNullParameter(fullScreenAd, "fullScreenAd");
        Intrinsics.checkNotNullParameter(error, "error");
        UnifiedFullscreenAdCallback unifiedFullscreenAdCallback = this.callback;
        BMError bMError = BMError.NoFill;
        Intrinsics.checkNotNullExpressionValue(bMError, "NoFill");
        unifiedFullscreenAdCallback.onAdLoadFailed(AdaptiveRenderingAdapterKt.toBMError(error, bMError));
    }

    public void onAdShown(@NotNull FullScreenAd fullScreenAd) {
        Intrinsics.checkNotNullParameter(fullScreenAd, "fullScreenAd");
        this.isShown = true;
        this.callback.onAdShown();
    }

    public void onAdFailToShow(@NotNull FullScreenAd fullScreenAd, @NotNull Error error) {
        Intrinsics.checkNotNullParameter(fullScreenAd, "fullScreenAd");
        Intrinsics.checkNotNullParameter(error, "error");
        UnifiedFullscreenAdCallback unifiedFullscreenAdCallback = this.callback;
        BMError bMError = BMError.InternalUnknownError;
        Intrinsics.checkNotNullExpressionValue(bMError, "InternalUnknownError");
        unifiedFullscreenAdCallback.onAdShowFailed(AdaptiveRenderingAdapterKt.toBMError(error, bMError));
    }

    public void onAdClicked(@NotNull FullScreenAd fullScreenAd) {
        Intrinsics.checkNotNullParameter(fullScreenAd, "fullScreenAd");
        this.callback.onAdClicked();
    }

    public void onAdFinished(@NotNull FullScreenAd fullScreenAd) {
        Intrinsics.checkNotNullParameter(fullScreenAd, "fullScreenAd");
        if (this.isShown) {
            this.callback.onAdFinished();
        }
        this.callback.onAdClosed();
    }

    public void onAdExpired(@NotNull FullScreenAd fullScreenAd) {
        Intrinsics.checkNotNullParameter(fullScreenAd, "fullScreenAd");
        this.callback.onAdExpired();
    }

    public void onOpenPrivacySheet(@NotNull FullScreenAd fullScreenAd, @NotNull PrivacySheetParams privacySheetParams) {
        Intrinsics.checkNotNullParameter(fullScreenAd, "fullScreenAd");
        Intrinsics.checkNotNullParameter(privacySheetParams, "privacySheetParams");
        PrivacySheetDialog$Companion privacySheetDialog$Companion = PrivacySheetDialog.Companion;
        Context contextFindDialogContext = Utils.findDialogContext(this.applicationContext);
        Intrinsics.checkNotNullExpressionValue(contextFindDialogContext, "findDialogContext(applicationContext)");
        privacySheetDialog$Companion.show(contextFindDialogContext, privacySheetParams);
    }

    public void onBrokenCreativeEvent(@NotNull FullScreenAd fullScreenAd, @NotNull BrokenCreativeEvent brokenCreativeEvent) {
        Intrinsics.checkNotNullParameter(fullScreenAd, "fullScreenAd");
        Intrinsics.checkNotNullParameter(brokenCreativeEvent, "brokenCreativeEvent");
        this.callback.onBrokenCreativeEvent(AdaptiveRenderingAdapterKt.toEventParams(brokenCreativeEvent));
    }
}
