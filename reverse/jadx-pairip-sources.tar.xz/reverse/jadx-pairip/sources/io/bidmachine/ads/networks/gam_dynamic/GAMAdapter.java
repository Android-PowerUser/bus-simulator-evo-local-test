package io.bidmachine.ads.networks.gam_dynamic;

import android.content.Context;
import android.text.TextUtils;
import android.util.Base64;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import com.applovin.mediation.adapters.bidmachine.BuildConfig;
import com.explorestack.protobuf.Struct;
import io.bidmachine.AdsType;
import io.bidmachine.ContextProvider;
import io.bidmachine.ExtraParamsManager;
import io.bidmachine.HeaderBiddingAdRequestParams;
import io.bidmachine.HeaderBiddingAdapter;
import io.bidmachine.HeaderBiddingCollectParamsCallback;
import io.bidmachine.InitializationParams;
import io.bidmachine.NetworkAdUnit;
import io.bidmachine.NetworkConfigParams;
import io.bidmachine.NetworkInitializationCallback;
import io.bidmachine.ads.networks.gam_dynamic.versions.VersionWrapper;
import io.bidmachine.protobuf.Waterfall;
import io.bidmachine.unified.UnifiedAdRequestParams;
import io.bidmachine.unified.UnifiedBannerAd;
import io.bidmachine.unified.UnifiedFullscreenAd;
import io.bidmachine.utils.BMError;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class GAMAdapter extends HeaderBiddingAdapter {

    @NonNull
    private static final String GAM_NETWORK_ERROR = "GAMNetwork is null";

    @NonNull
    private static final String NETWORK_NAME = "GAMDynamic";

    @Nullable
    @VisibleForTesting
    GAMNetwork gamNetwork;

    @NonNull
    public String getNetworkName() {
        return NETWORK_NAME;
    }

    protected boolean isNetworkInitializationStatusCheckSupported() {
        return true;
    }

    GAMAdapter(@NonNull String key) {
        this(key, "null", BuildConfig.VERSION_NAME, 16);
    }

    protected GAMAdapter(@NonNull String key, @NonNull String version, @NonNull String adapterVersion, int adapterMinDeviceApiVersion) {
        this(key, version, adapterVersion, adapterMinDeviceApiVersion, new AdsType[]{AdsType.Banner, AdsType.Interstitial, AdsType.Rewarded});
    }

    protected GAMAdapter(@NonNull String key, @NonNull String version, @NonNull String adapterVersion, int adapterMinDeviceApiVersion, @NonNull AdsType[] supportedTypes) {
        super(key, version, adapterVersion, adapterMinDeviceApiVersion, supportedTypes);
    }

    @Nullable
    public String getNetworkSdkVersion() throws Throwable {
        GAMNetwork gAMNetwork = this.gamNetwork;
        if (gAMNetwork != null) {
            return gAMNetwork.getVersion();
        }
        return null;
    }

    public UnifiedBannerAd createBanner() {
        GAMNetwork gAMNetwork = this.gamNetwork;
        if (gAMNetwork != null) {
            return new GAMBannerAd(gAMNetwork);
        }
        throw new IllegalArgumentException(GAM_NETWORK_ERROR);
    }

    public UnifiedFullscreenAd createInterstitial() {
        GAMNetwork gAMNetwork = this.gamNetwork;
        if (gAMNetwork != null) {
            return new GAMInterstitialAd(gAMNetwork);
        }
        throw new IllegalArgumentException(GAM_NETWORK_ERROR);
    }

    public UnifiedFullscreenAd createRewarded() {
        GAMNetwork gAMNetwork = this.gamNetwork;
        if (gAMNetwork != null) {
            return new GAMRewardedAd(gAMNetwork);
        }
        throw new IllegalArgumentException(GAM_NETWORK_ERROR);
    }

    protected boolean isNetworkInitialized(@NonNull ContextProvider contextProvider) throws Throwable {
        GAMNetwork gAMNetwork = this.gamNetwork;
        return gAMNetwork != null && gAMNetwork.isInitialized();
    }

    protected void onNetworkInitialize(@NonNull ContextProvider contextProvider, @NonNull InitializationParams initializationParams, @NonNull NetworkConfigParams networkConfigParams, @NonNull NetworkInitializationCallback callback) throws Throwable {
        String strRemoveFromNetworkParams = networkConfigParams.removeFromNetworkParams("supported_versions_range");
        if (TextUtils.isEmpty(strRemoveFromNetworkParams)) {
            callback.onFail("supported_versions_range not provided");
            return;
        }
        VersionWrapper versionWrapperFindVersionWrapper = VersionManager.findVersionWrapper(strRemoveFromNetworkParams);
        if (versionWrapperFindVersionWrapper == null) {
            callback.onFail("Unsupported GAM version (VersionWrapper not found)");
            return;
        }
        Context applicationContext = contextProvider.getApplicationContext();
        if (!versionWrapperFindVersionWrapper.isGAMPresent(applicationContext)) {
            callback.onFail("GAM is absent or used unsupported version");
            return;
        }
        String strRemoveFromNetworkParams2 = networkConfigParams.removeFromNetworkParams("context");
        if (TextUtils.isEmpty(strRemoveFromNetworkParams2)) {
            callback.onFail("context not provided");
            return;
        }
        Waterfall.Context waterfallContext = parseWaterfallContext(strRemoveFromNetworkParams2);
        if (waterfallContext == null) {
            callback.onFail("context can't transform to model");
            return;
        }
        GAMNetworkImpl gAMNetworkImpl = new GAMNetworkImpl(applicationContext, new GAMNetworkParams(getKey(), getNetworkName()), waterfallContext, versionWrapperFindVersionWrapper);
        this.gamNetwork = gAMNetworkImpl;
        gAMNetworkImpl.init(applicationContext);
        this.gamNetwork.cache();
        callback.onSuccess();
    }

    protected void onCollectHeaderBiddingParams(@NonNull ContextProvider contextProvider, @NonNull UnifiedAdRequestParams adRequestParams, @NonNull NetworkAdUnit networkAdUnit, @NonNull HeaderBiddingAdRequestParams hbAdRequestParams, @NonNull HeaderBiddingCollectParamsCallback collectCallback) throws Throwable {
        GAMNetwork gAMNetwork = this.gamNetwork;
        if (gAMNetwork == null) {
            collectCallback.onCollectFail(BMError.adapter("GAM network is null"));
            return;
        }
        InternalAdData internalAdDataReserveMostExpensiveAd = gAMNetwork.reserveMostExpensiveAd(networkAdUnit, networkAdUnit.getAdFormat());
        if (internalAdDataReserveMostExpensiveAd == null) {
            collectCallback.onCollectFail(BMError.adapter("Can't find idle ad"));
            return;
        }
        HashMap map = new HashMap();
        map.put("ad_unit_id", internalAdDataReserveMostExpensiveAd.getAdUnitId());
        map.put("price", String.valueOf(internalAdDataReserveMostExpensiveAd.getPrice()));
        for (Map.Entry entry : internalAdDataReserveMostExpensiveAd.getCustomParamsMap().entrySet()) {
            String str = (String) entry.getKey();
            Object value = entry.getValue();
            if (!TextUtils.isEmpty(str) && value != null) {
                map.put(str, String.valueOf(value));
            }
        }
        collectCallback.onCollectFinished(map);
    }

    public void onLossAuction(@NonNull NetworkAdUnit networkAdUnit) throws Throwable {
        GAMNetwork gAMNetwork = this.gamNetwork;
        if (gAMNetwork != null) {
            gAMNetwork.unReserveAd(networkAdUnit);
        }
    }

    public void clearAuction(@NonNull NetworkAdUnit networkAdUnit) throws Throwable {
        GAMNetwork gAMNetwork = this.gamNetwork;
        if (gAMNetwork != null) {
            gAMNetwork.unReserveAd(networkAdUnit);
        }
    }

    @Nullable
    @VisibleForTesting
    Waterfall.Context parseWaterfallContext(@NonNull String context) {
        try {
            return Waterfall.Context.parseFrom(Base64.decode(context, 0));
        } catch (Throwable unused) {
            return null;
        }
    }

    @VisibleForTesting
    static class GAMNetworkParams extends NetworkParamsImpl {
        public GAMNetworkParams(@NonNull String networkKey, @NonNull String networkName) {
            super(networkKey, networkName);
        }

        @Nullable
        public Struct getExt(@NonNull Context context) {
            return ExtraParamsManager.get().getPrivateStruct(context);
        }
    }
}
