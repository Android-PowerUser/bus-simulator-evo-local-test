package io.bidmachine.ads.networks.gam_dynamic.versions.v22_0_0;

import com.google.android.gms.ads.rewarded.RewardedAd;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class d$b$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ d.b f$0;
    public final /* synthetic */ RewardedAd f$1;

    public /* synthetic */ d$b$$ExternalSyntheticLambda0(d.b bVar, RewardedAd rewardedAd) {
        this.f$0 = bVar;
        this.f$1 = rewardedAd;
    }

    @Override // java.lang.Runnable
    public final void run() {
        d.b.$r8$lambda$9SMeRaDxwYbrDZqEIiMJfJIixkE(this.f$0, this.f$1);
    }
}
