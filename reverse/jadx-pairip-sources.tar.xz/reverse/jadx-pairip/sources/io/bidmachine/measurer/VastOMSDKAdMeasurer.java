package io.bidmachine.measurer;

import android.text.TextUtils;
import android.view.View;
import androidx.annotation.FloatRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.UiThread;
import com.iab.omid.library.appodeal.adsession.AdEvents;
import com.iab.omid.library.appodeal.adsession.VerificationScriptResource;
import com.iab.omid.library.appodeal.adsession.media.Position;
import com.iab.omid.library.appodeal.adsession.media.VastProperties;
import io.bidmachine.core.Logger;
import io.bidmachine.core.Utils;
import io.bidmachine.iab.measurer.VastAdMeasurer;
import io.bidmachine.iab.vast.VastPlaybackListener;
import io.bidmachine.iab.vast.VastRequest;
import io.bidmachine.iab.vast.tags.AdVerificationsExtensionTag;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class VastOMSDKAdMeasurer extends OMSDKAdMeasurer<View> implements VastAdMeasurer, VastPlaybackListener {
    private static final boolean IS_AUTO_PLAY = true;

    @NonNull
    private final List<VerificationScriptResource> resourceList = new ArrayList();

    @Nullable
    private Float skipOffset;

    public void onVastModelLoaded(@NonNull VastRequest vastRequest) {
        Utils.onUiThread(new 1(this, vastRequest));
    }

    public void setupAdMeasurer(@NonNull VastRequest vastRequest) {
        Utils.onUiThread(new 2(this, vastRequest));
    }

    public void addVerificationScriptResourceList(@Nullable final List<AdVerificationsExtensionTag> adVerificationsExtensionTagList) {
        if (adVerificationsExtensionTagList == null) {
            return;
        }
        Utils.onUiThread(new 3(this, adVerificationsExtensionTagList));
    }

    @UiThread
    public void addVerificationScriptResource(@NonNull String resourceUrl, @Nullable String vendorKey, @Nullable String params) {
        VerificationScriptResource verificationScriptResourceCreateVerificationScriptResourceWithoutParameters;
        try {
            URL url = new URL(resourceUrl);
            if (!TextUtils.isEmpty(vendorKey) && !TextUtils.isEmpty(params)) {
                verificationScriptResourceCreateVerificationScriptResourceWithoutParameters = VerificationScriptResource.createVerificationScriptResourceWithParameters(vendorKey, url, params);
            } else {
                verificationScriptResourceCreateVerificationScriptResourceWithoutParameters = VerificationScriptResource.createVerificationScriptResourceWithoutParameters(url);
            }
            this.resourceList.add(verificationScriptResourceCreateVerificationScriptResourceWithoutParameters);
        } catch (Throwable th) {
            Logger.w(th);
        }
    }

    public void setSkipOffset(@Nullable Float skipOffset) {
        this.skipOffset = skipOffset;
    }

    protected void startAdSession(@NonNull List<VerificationScriptResource> verificationScriptResourceList) {
        Utils.onUiThread(new 4(this, verificationScriptResourceList));
    }

    @UiThread
    protected void onAdLoaded(@NonNull AdEvents adEvents) throws Throwable {
        VastProperties vastPropertiesCreateVastPropertiesForSkippableMedia;
        Float f = this.skipOffset;
        if (f == null) {
            vastPropertiesCreateVastPropertiesForSkippableMedia = VastProperties.createVastPropertiesForNonSkippableMedia(IS_AUTO_PLAY, Position.STANDALONE);
        } else {
            vastPropertiesCreateVastPropertiesForSkippableMedia = VastProperties.createVastPropertiesForSkippableMedia(f.floatValue(), IS_AUTO_PLAY, Position.STANDALONE);
        }
        adEvents.loaded(vastPropertiesCreateVastPropertiesForSkippableMedia);
        log("onAdLoaded");
    }

    public void onVideoStarted(final float duration, @FloatRange(from = 0.0d, to = 1.0d) final float volume) {
        onMediaStarted(duration, volume);
    }

    public void onVideoFirstQuartile() {
        onMediaFirstQuartile();
    }

    public void onVideoMidpoint() {
        onMediaMidpoint();
    }

    public void onVideoThirdQuartile() {
        onMediaThirdQuartile();
    }

    public void onVideoCompleted() {
        onMediaCompleted();
    }

    public void onVideoPaused() {
        onMediaPaused();
    }

    public void onVideoResumed() {
        onMediaResumed();
    }

    public void onVideoVolumeChanged(@FloatRange(from = 0.0d, to = 1.0d) final float volume) {
        onMediaVolumeChanged(volume);
    }

    public void onVideoSkipped() {
        onMediaSkipped();
    }
}
