package io.bidmachine.measurer;

import io.bidmachine.core.Logger;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class OMSDKAdMeasurer$8 implements Runnable {
    final /* synthetic */ OMSDKAdMeasurer this$0;

    OMSDKAdMeasurer$8(final OMSDKAdMeasurer this$0) {
        this.this$0 = this$0;
    }

    @Override // java.lang.Runnable
    public void run() {
        try {
            if (OMSDKAdMeasurer.access$400(this.this$0) != null) {
                OMSDKAdMeasurer.access$400(this.this$0).complete();
                this.this$0.log("onMediaCompleted");
            }
        } catch (Throwable th) {
            Logger.w(th);
        }
    }
}
