package io.bidmachine.rendering.internal.meanbackground;

import android.graphics.Bitmap;
import android.graphics.Rect;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
final class k$b$a$a extends SuspendLambda implements Function2 {
    int a;
    final /* synthetic */ k b;
    final /* synthetic */ Bitmap c;
    final /* synthetic */ Rect d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    k$b$a$a(k kVar, Bitmap bitmap, Rect rect, Continuation continuation) {
        super(2, continuation);
        this.b = kVar;
        this.c = bitmap;
        this.d = rect;
    }

    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public final Object invoke(CoroutineScope coroutineScope, Continuation continuation) {
        return ((k$b$a$a) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    public final Continuation create(Object obj, Continuation continuation) {
        return new k$b$a$a(this.b, this.c, this.d, continuation);
    }

    public final Object invokeSuspend(Object obj) throws Throwable {
        IntrinsicsKt.getCOROUTINE_SUSPENDED();
        if (this.a != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        ResultKt.throwOnFailure(obj);
        return Boxing.boxInt(k.c(this.b).a(this.c, this.d));
    }
}
