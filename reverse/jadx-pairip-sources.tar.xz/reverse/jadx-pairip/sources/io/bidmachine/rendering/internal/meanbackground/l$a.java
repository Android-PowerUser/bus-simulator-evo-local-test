package io.bidmachine.rendering.internal.meanbackground;

import kotlin.jvm.internal.DefaultConstructorMarker;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class l$a {
    public /* synthetic */ l$a(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }

    private l$a() {
    }
}
