package io.bidmachine.rendering.internal.controller;

import io.bidmachine.rendering.Rendering;
import io.bidmachine.util.cache.MediaFileCacheManager;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Lambda;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
final class h$y$a extends Lambda implements Function0 {
    public static final h$y$a a = new h$y$a();

    h$y$a() {
        super(0);
    }

    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public final MediaFileCacheManager invoke() {
        Function0 mediaFileCacheManagerProvider = Rendering.getMediaFileCacheManagerProvider();
        if (mediaFileCacheManagerProvider != null) {
            return (MediaFileCacheManager) mediaFileCacheManagerProvider.invoke();
        }
        return null;
    }
}
