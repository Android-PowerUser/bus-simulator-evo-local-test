package io.bidmachine.rendering.internal.screenshot;

import android.graphics.Bitmap;
import android.view.PixelCopy;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class a$a implements PixelCopy.OnPixelCopyFinishedListener {
    final /* synthetic */ b a;
    final /* synthetic */ Bitmap b;

    a$a(b bVar, Bitmap bitmap) {
        this.a = bVar;
        this.b = bitmap;
    }

    @Override // android.view.PixelCopy.OnPixelCopyFinishedListener
    public void onPixelCopyFinished(int i) {
        if (i == 0) {
            this.a.a(this.b);
        } else {
            this.a.a();
        }
    }
}
