package io.bidmachine.rendering.internal;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.graphics.drawable.Drawable;
import android.view.View;
import java.lang.ref.WeakReference;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class y$g extends AnimatorListenerAdapter {
    final /* synthetic */ WeakReference a;
    final /* synthetic */ Drawable b;

    y$g(WeakReference weakReference, Drawable drawable) {
        this.a = weakReference;
        this.b = drawable;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationStart(Animator animator) {
        Intrinsics.checkNotNullParameter(animator, "animation");
        View view = (View) this.a.get();
        if (view == null) {
            return;
        }
        view.setBackground(this.b);
    }
}
