package io.bidmachine.rendering.internal.adform.video;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import io.bidmachine.rendering.Repository;
import io.bidmachine.rendering.internal.adform.c;
import io.bidmachine.rendering.internal.adform.video.player.b;
import io.bidmachine.rendering.internal.n;
import io.bidmachine.rendering.measurer.VideoMeasurer;
import io.bidmachine.rendering.model.AdElementParams;
import io.bidmachine.rendering.model.Error;
import io.bidmachine.rendering.model.MediaSource;
import io.bidmachine.rendering.model.Resource;
import io.bidmachine.rendering.model.ResourceSource;
import io.bidmachine.rendering.model.UrlResourceSource;
import io.bidmachine.rendering.utils.UiUtils;
import java.util.List;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class a extends io.bidmachine.rendering.internal.adform.a {
    private final VideoMeasurer s;
    private b t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a(Context context, Object obj, Repository repository, AdElementParams adElementParams, c cVar, io.bidmachine.rendering.internal.event.b bVar, io.bidmachine.rendering.internal.detector.brokencreative.a aVar, VideoMeasurer videoMeasurer) {
        super(context, obj, repository, adElementParams, cVar, bVar, aVar);
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(obj, "assetsHolder");
        Intrinsics.checkNotNullParameter(repository, "repository");
        Intrinsics.checkNotNullParameter(adElementParams, "adElementParams");
        Intrinsics.checkNotNullParameter(cVar, "adFormListener");
        Intrinsics.checkNotNullParameter(bVar, "eventCallback");
        this.s = videoMeasurer;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void g(a aVar) {
        Intrinsics.checkNotNullParameter(aVar, "this$0");
        b bVar = aVar.t;
        if (bVar != null) {
            bVar.play();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void h(a aVar) {
        Intrinsics.checkNotNullParameter(aVar, "this$0");
        b bVar = aVar.t;
        if (bVar != null) {
            bVar.k();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void i(a aVar) {
        Intrinsics.checkNotNullParameter(aVar, "this$0");
        b bVar = aVar.t;
        if (bVar != null) {
            bVar.e();
        }
    }

    public void B() {
        super.B();
        VideoMeasurer videoMeasurer = this.s;
        if (videoMeasurer != null) {
            videoMeasurer.onShown();
        }
    }

    public final void E() {
        UiUtils.onUiThread(new a$.ExternalSyntheticLambda5(this));
    }

    public void d() {
        UiUtils.onUiThread(new a$.ExternalSyntheticLambda3(this));
    }

    public void e() {
        UiUtils.onUiThread(new a$.ExternalSyntheticLambda1(this));
    }

    public void f() {
        super.f();
        UiUtils.onUiThread(new a$.ExternalSyntheticLambda8(this));
    }

    public void k() {
        UiUtils.onUiThread(new a$.ExternalSyntheticLambda6(this));
    }

    public View x() {
        b bVar = this.t;
        if (bVar != null) {
            return bVar.n();
        }
        return null;
    }

    public void y() {
        super.y();
        VideoMeasurer videoMeasurer = this.s;
        if (videoMeasurer != null) {
            videoMeasurer.onClicked();
        }
    }

    protected void z() {
        Unit unit;
        VideoMeasurer videoMeasurer = this.s;
        if (videoMeasurer != null) {
            videoMeasurer.destroy(new a$.ExternalSyntheticLambda7(this));
            unit = Unit.INSTANCE;
        } else {
            unit = null;
        }
        if (unit == null) {
            E();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void d(a aVar) {
        Intrinsics.checkNotNullParameter(aVar, "this$0");
        b bVar = aVar.t;
        if (bVar != null) {
            bVar.a();
        }
        aVar.t = null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void e(a aVar) {
        Intrinsics.checkNotNullParameter(aVar, "this$0");
        aVar.E();
    }

    public void c() {
        Resource resource = h().getResource();
        List listListOf = null;
        ResourceSource source = resource != null ? resource.getSource() : null;
        if (source == null) {
            String source2 = h().getSource();
            if (source2 != null) {
                listListOf = CollectionsKt.listOf(source2);
            }
        } else if (source instanceof UrlResourceSource) {
            listListOf = ((UrlResourceSource) source).getUrls();
        } else {
            b("Invalid resource type (" + source.getClass().getSimpleName() + "), it should be UrlResourceSource");
        }
        MediaSource mediaSourceFromUrls = MediaSource.Companion.fromUrls(listListOf == null ? CollectionsKt.emptyList() : listListOf);
        if (mediaSourceFromUrls != null) {
            UiUtils.onUiThread(new a$.ExternalSyntheticLambda0(this, mediaSourceFromUrls.getDeliveryType() == MediaSource.DeliveryType.STREAM ? "exo" : h().getCustomParam("player")));
            w().getVideo(mediaSourceFromUrls, v(), new b(this));
            return;
        }
        a(new Error("Invalid adm url (" + listListOf + ')'));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void a(a aVar, String str) {
        Intrinsics.checkNotNullParameter(aVar, "this$0");
        try {
            b bVarA = io.bidmachine.rendering.internal.adform.video.player.c.a(aVar.u(), str);
            bVarA.a(new a(aVar));
            VideoMeasurer videoMeasurer = aVar.s;
            if (videoMeasurer != null) {
                videoMeasurer.onViewCreated(bVarA.n());
            }
            aVar.t = bVarA;
        } catch (Throwable th) {
            n.b(th);
            aVar.a(Error.Companion.create(th));
        }
    }

    public void b(Integer num) {
        UiUtils.onUiThread(new a$.ExternalSyntheticLambda2(this, num));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void b(a aVar, Integer num) {
        Intrinsics.checkNotNullParameter(aVar, "this$0");
        b bVar = aVar.t;
        if (bVar != null) {
            bVar.a(num);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void f(a aVar) {
        Intrinsics.checkNotNullParameter(aVar, "this$0");
        b bVar = aVar.t;
        if (bVar != null) {
            bVar.pause();
        }
    }

    public void b() {
        e();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void b(Error error) {
        VideoMeasurer videoMeasurer = this.s;
        if (videoMeasurer != null) {
            videoMeasurer.onError(error);
        }
        s().a(this, error);
    }

    public void a(ViewGroup viewGroup) {
        Intrinsics.checkNotNullParameter(viewGroup, "rootContainer");
        UiUtils.onUiThread(new a$.ExternalSyntheticLambda9(this, viewGroup));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void a(a aVar, ViewGroup viewGroup) {
        Intrinsics.checkNotNullParameter(aVar, "this$0");
        Intrinsics.checkNotNullParameter(viewGroup, "$rootContainer");
        b bVar = aVar.t;
        VideoMeasurer videoMeasurer = aVar.s;
        if (videoMeasurer == null || bVar == null) {
            return;
        }
        videoMeasurer.onViewAddedToContainer(bVar.n(), viewGroup);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void a(a aVar, Integer num) {
        Intrinsics.checkNotNullParameter(aVar, "this$0");
        b bVar = aVar.t;
        if (bVar != null) {
            bVar.b(num);
        }
    }

    public void a(Integer num) {
        UiUtils.onUiThread(new a$.ExternalSyntheticLambda4(this, num));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void a(Error error) {
        VideoMeasurer videoMeasurer = this.s;
        if (videoMeasurer != null) {
            videoMeasurer.onError(error);
        }
        s().c(this, error);
    }
}
