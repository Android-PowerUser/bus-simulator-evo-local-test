package io.bidmachine.rendering.ad.fullscreen;

import io.bidmachine.rendering.ad.view.AdView;
import io.bidmachine.rendering.ad.view.AdViewListener;
import io.bidmachine.rendering.internal.adform.lYZ.KUJk;
import io.bidmachine.rendering.model.BrokenCreativeEvent;
import io.bidmachine.rendering.model.Error;
import io.bidmachine.rendering.model.PrivacySheetParams;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class FullScreenAd$a implements AdViewListener {
    final /* synthetic */ FullScreenAd a;

    public FullScreenAd$a(FullScreenAd fullScreenAd) {
        this.a = fullScreenAd;
    }

    public void onAdAppeared(AdView adView) {
        Intrinsics.checkNotNullParameter(adView, "adView");
        FullScreenAd.access$notifyAdAppeared(this.a);
    }

    public void onAdClicked(AdView adView) {
        Intrinsics.checkNotNullParameter(adView, "adView");
        FullScreenAd.access$notifyAdClicked(this.a);
    }

    public void onAdDisappeared(AdView adView) {
        Intrinsics.checkNotNullParameter(adView, "adView");
        FullScreenAd.access$notifyAdDisappeared(this.a);
    }

    public void onAdExpired(AdView adView) {
        Intrinsics.checkNotNullParameter(adView, "adView");
        FullScreenAd.access$notifyAdExpired(this.a);
    }

    public void onAdFailToLoad(AdView adView, Error error) {
        Intrinsics.checkNotNullParameter(adView, "adView");
        Intrinsics.checkNotNullParameter(error, "error");
        FullScreenAd.access$notifyAdFailToLoad(this.a, error);
    }

    public void onAdFailToShow(AdView adView, Error error) {
        Intrinsics.checkNotNullParameter(adView, "adView");
        Intrinsics.checkNotNullParameter(error, "error");
        this.a.notifyAdFailToShow(error);
    }

    public void onAdFinished(AdView adView) {
        Intrinsics.checkNotNullParameter(adView, "adView");
        this.a.processAdClosed();
    }

    public void onAdLoaded(AdView adView) {
        Intrinsics.checkNotNullParameter(adView, "adView");
        FullScreenAd.access$notifyAdLoaded(this.a);
    }

    public void onAdShown(AdView adView) {
        Intrinsics.checkNotNullParameter(adView, "adView");
        FullScreenAd.access$notifyAdShown(this.a);
    }

    public void onBrokenCreativeEvent(AdView adView, BrokenCreativeEvent brokenCreativeEvent) {
        Intrinsics.checkNotNullParameter(adView, "adView");
        Intrinsics.checkNotNullParameter(brokenCreativeEvent, KUJk.uuBu);
        FullScreenAd.access$notifyBrokenCreativeEvent(this.a, brokenCreativeEvent);
    }

    public void onOpenPrivacySheet(AdView adView, PrivacySheetParams privacySheetParams) {
        Intrinsics.checkNotNullParameter(adView, "adView");
        Intrinsics.checkNotNullParameter(privacySheetParams, "privacySheetParams");
        FullScreenAd.access$notifyPrivacySheetOpen(this.a, privacySheetParams);
    }
}
