package io.bidmachine.rendering.view;

import android.content.Context;
import io.bidmachine.rendering.internal.n;
import io.bidmachine.rendering.model.PrivacySheetParams;
import java.lang.ref.WeakReference;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0018\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0007R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u000b"}, d2 = {"Lio/bidmachine/rendering/view/PrivacySheetDialog$Companion;", "", "()V", "lastPrivacySheetDialogRef", "Ljava/lang/ref/WeakReference;", "Lio/bidmachine/rendering/view/PrivacySheetDialog;", "show", "context", "Landroid/content/Context;", "privacySheetParams", "Lio/bidmachine/rendering/model/PrivacySheetParams;", "bidmachine-android-sdk_bi_3_5_1"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class PrivacySheetDialog$Companion {
    public /* synthetic */ PrivacySheetDialog$Companion(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }

    @JvmStatic
    @NotNull
    public final PrivacySheetDialog show(@NotNull Context context, @NotNull PrivacySheetParams privacySheetParams) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(privacySheetParams, "privacySheetParams");
        PrivacySheetDialog privacySheetDialog = (PrivacySheetDialog) PrivacySheetDialog.access$getLastPrivacySheetDialogRef$cp().get();
        if (privacySheetDialog != null && privacySheetDialog.isShowing()) {
            if (Intrinsics.areEqual(PrivacySheetDialog.access$getPrivacySheetParams$p(privacySheetDialog), privacySheetParams)) {
                return privacySheetDialog;
            }
            privacySheetDialog.dismiss();
        }
        PrivacySheetDialog privacySheetDialog2 = new PrivacySheetDialog(context, privacySheetParams, (DefaultConstructorMarker) null);
        PrivacySheetDialog.access$setLastPrivacySheetDialogRef$cp(new WeakReference(privacySheetDialog2));
        try {
            privacySheetDialog2.show();
        } catch (Throwable th) {
            n.b(th);
        }
        return privacySheetDialog2;
    }

    private PrivacySheetDialog$Companion() {
    }
}
