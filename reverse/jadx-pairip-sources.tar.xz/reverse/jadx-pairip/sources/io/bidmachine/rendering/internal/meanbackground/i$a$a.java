package io.bidmachine.rendering.internal.meanbackground;

import io.bidmachine.util.MathUtils;
import kotlin.math.MathKt;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface i$a$a {

    public static final class a implements i$a$a {
        public static final a a = new a();

        private a() {
        }

        @Override // io.bidmachine.rendering.internal.meanbackground.i$a$a
        public int a(int i, int i2, int i3, int i4, int i5) {
            return MathKt.roundToInt(MathUtils.lerp(i4, i5, (i * i2) / (i3 * i3)));
        }
    }

    int a(int i, int i2, int i3, int i4, int i5);
}
