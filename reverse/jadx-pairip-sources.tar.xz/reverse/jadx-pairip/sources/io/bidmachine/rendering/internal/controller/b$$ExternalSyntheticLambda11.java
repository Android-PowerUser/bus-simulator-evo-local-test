package io.bidmachine.rendering.internal.controller;

import io.bidmachine.rendering.model.Error;
import io.bidmachine.util.Executable;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class b$$ExternalSyntheticLambda11 implements Executable {
    public final /* synthetic */ b f$0;
    public final /* synthetic */ e f$1;

    public /* synthetic */ b$$ExternalSyntheticLambda11(b bVar, e eVar) {
        this.f$0 = bVar;
        this.f$1 = eVar;
    }

    public final void execute(Object obj) {
        b.$r8$lambda$3iLRutKqMLhULjQ9-S8nPCkeg5M(this.f$0, this.f$1, (Error) obj);
    }
}
