package io.bidmachine.rendering.internal.detector.brokencreative.algorithm;

import io.bidmachine.rendering.model.BrokenCreativeAlgorithmType;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public /* synthetic */ class b$a {
    public static final /* synthetic */ int[] $EnumSwitchMapping$0;

    static {
        int[] iArr = new int[BrokenCreativeAlgorithmType.values().length];
        try {
            iArr[BrokenCreativeAlgorithmType.ColorHistogram.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr[BrokenCreativeAlgorithmType.BrightnessVariance.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr[BrokenCreativeAlgorithmType.EdgeDetection.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        $EnumSwitchMapping$0 = iArr;
    }
}
