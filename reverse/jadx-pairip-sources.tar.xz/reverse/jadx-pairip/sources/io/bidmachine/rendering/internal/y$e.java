package io.bidmachine.rendering.internal;

import android.view.View;
import io.bidmachine.rendering.model.Border;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Lambda;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
final class y$e extends Lambda implements Function0 {
    final /* synthetic */ View a;
    final /* synthetic */ int b;
    final /* synthetic */ y c;
    final /* synthetic */ Integer d;
    final /* synthetic */ Border e;
    final /* synthetic */ y$a f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    y$e(View view, int i, y yVar, Integer num, Border border, y$a y_a) {
        super(0);
        this.a = view;
        this.b = i;
        this.c = yVar;
        this.d = num;
        this.e = border;
        this.f = y_a;
    }

    public final void a() {
        y.a(this.a, this.c, this.d, this.e, this.f, true, this.b);
    }

    public /* bridge */ /* synthetic */ Object invoke() {
        a();
        return Unit.INSTANCE;
    }
}
