package io.bidmachine.rendering.internal.adform.video.player;

import io.bidmachine.rendering.internal.m;
import io.bidmachine.rendering.utils.UiUtils;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class a$a implements m {
    private final AtomicBoolean a = new AtomicBoolean(false);
    private final AtomicInteger b = new AtomicInteger(0);
    private final int c;
    final /* synthetic */ a d;

    public a$a(a aVar, int i) {
        this.d = aVar;
        this.c = i;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void d() {
        this.a.set(false);
        UiUtils.cancelOnUiThread(this);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void onRun() {
        if (this.a.get()) {
            if (this.d.D()) {
                a();
            }
            a aVar = this.d;
            aVar.b(aVar.p());
            UiUtils.onUiThread(this, this.c);
        }
    }

    private void a() {
        Long lP = this.d.p();
        if (lP == null) {
            return;
        }
        long jG = this.d.g();
        if (jG <= 0) {
            return;
        }
        float fLongValue = (lP.longValue() * 100.0f) / jG;
        int i = this.b.get();
        if (fLongValue > (i * 25.0f) - 1.0f) {
            if (i == 0) {
                this.d.M();
            } else if (i == 1) {
                this.d.K();
            } else if (i == 2) {
                this.d.L();
            } else if (i == 3) {
                this.d.N();
            } else if (i == 4) {
                this.d.J();
            }
            this.b.incrementAndGet();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void b() {
        this.b.set(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void c() {
        d();
        this.a.set(true);
        UiUtils.onUiThread(this);
    }
}
