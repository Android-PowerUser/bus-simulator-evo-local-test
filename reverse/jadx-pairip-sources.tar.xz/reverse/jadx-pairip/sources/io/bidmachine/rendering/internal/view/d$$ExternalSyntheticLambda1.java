package io.bidmachine.rendering.internal.view;

import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class d$$ExternalSyntheticLambda1 implements View.OnClickListener {
    public final /* synthetic */ d f$0;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        d.$r8$lambda$9jdH0MacChY1or8BqEC26mhWbYw(this.f$0, view);
    }
}
