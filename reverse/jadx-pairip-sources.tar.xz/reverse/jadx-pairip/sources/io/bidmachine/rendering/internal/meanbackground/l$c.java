package io.bidmachine.rendering.internal.meanbackground;

import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Lambda;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
final class l$c extends Lambda implements Function0 {
    final /* synthetic */ String a;
    final /* synthetic */ long b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    l$c(String str, long j) {
        super(0);
        this.a = str;
        this.b = j;
    }

    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public final String invoke() {
        return this.a + " took " + (System.currentTimeMillis() - this.b) + " ms";
    }
}
