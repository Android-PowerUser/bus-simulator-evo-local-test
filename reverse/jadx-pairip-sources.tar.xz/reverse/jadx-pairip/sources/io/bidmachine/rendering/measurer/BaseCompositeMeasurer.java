package io.bidmachine.rendering.measurer;

import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import io.bidmachine.rendering.measurer.Measurer;
import io.bidmachine.rendering.model.Error;
import io.bidmachine.rendering.utils.CountDownPostback;
import io.bidmachine.rendering.utils.Utils;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class BaseCompositeMeasurer<MeasurerType extends Measurer<ViewType>, ViewType extends View> implements Measurer<ViewType> {

    @NonNull
    public final List<MeasurerType> measurerList;

    public BaseCompositeMeasurer(@NonNull List<MeasurerType> measurerList) {
        this.measurerList = new CopyOnWriteArrayList(measurerList);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(Handler handler, Runnable runnable) {
        this.measurerList.clear();
        handler.post(runnable);
    }

    public void destroy(@Nullable Runnable postback) {
        CountDownPostback countDownPostback = postback != null ? new CountDownPostback(this.measurerList.size(), new BaseCompositeMeasurer$.ExternalSyntheticLambda0(this, Utils.createHandlerWithMyOrMainLooper(), postback)) : null;
        Iterator<MeasurerType> it = this.measurerList.iterator();
        while (it.hasNext()) {
            it.next().destroy(countDownPostback);
        }
    }

    public void onClicked() {
        Iterator<MeasurerType> it = this.measurerList.iterator();
        while (it.hasNext()) {
            it.next().onClicked();
        }
    }

    public void onError(@NonNull Error error) {
        Iterator<MeasurerType> it = this.measurerList.iterator();
        while (it.hasNext()) {
            it.next().onError(error);
        }
    }

    public void onShown() {
        Iterator<MeasurerType> it = this.measurerList.iterator();
        while (it.hasNext()) {
            it.next().onShown();
        }
    }

    public void onViewAddedToContainer(@NonNull ViewType viewType, @NonNull ViewGroup container) {
        Iterator<MeasurerType> it = this.measurerList.iterator();
        while (it.hasNext()) {
            it.next().onViewAddedToContainer(viewType, container);
        }
    }

    public void onViewCreated(@NonNull ViewType viewType) {
        Iterator<MeasurerType> it = this.measurerList.iterator();
        while (it.hasNext()) {
            it.next().onViewCreated(viewType);
        }
    }

    public void onViewReady(@NonNull ViewType viewType) {
        Iterator<MeasurerType> it = this.measurerList.iterator();
        while (it.hasNext()) {
            it.next().onViewReady(viewType);
        }
    }
}
