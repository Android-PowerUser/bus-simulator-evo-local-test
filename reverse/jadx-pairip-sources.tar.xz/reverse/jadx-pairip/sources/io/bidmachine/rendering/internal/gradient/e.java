package io.bidmachine.rendering.internal.gradient;

import android.graphics.Shader;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface e {
    Shader a(boolean z);
}
