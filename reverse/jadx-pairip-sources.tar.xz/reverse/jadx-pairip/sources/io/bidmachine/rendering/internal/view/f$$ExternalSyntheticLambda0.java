package io.bidmachine.rendering.internal.view;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class f$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ f f$0;

    @Override // java.lang.Runnable
    public final void run() {
        f.$r8$lambda$Gr3sfterjGKsYMt3XNJtQkgBeaQ(this.f$0);
    }
}
