package io.bidmachine.rendering.internal.controller;

import io.bidmachine.rendering.internal.m;
import io.bidmachine.rendering.internal.u;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class h$f$l$a implements m {
    final /* synthetic */ Object a;
    final /* synthetic */ long b;

    public h$f$l$a(Object obj, long j) {
        this.a = obj;
        this.b = j;
    }

    public final void onRun() {
        ((u) this.a).a(this.b);
    }
}
