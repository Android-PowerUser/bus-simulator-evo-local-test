package io.bidmachine.rendering.model;

import com.mbridge.msdk.foundation.entity.RewardPlus;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000e\n\u0002\b\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\b\u0010\t¨\u0006\n"}, d2 = {"Lio/bidmachine/rendering/model/MethodParams;", "", "", RewardPlus.NAME, "<init>", "(Ljava/lang/String;)V", "a", "Ljava/lang/String;", "getName", "()Ljava/lang/String;", "bidmachine-android-sdk_bi_3_5_1"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class MethodParams {

    /* JADX INFO: renamed from: a, reason: from kotlin metadata */
    private final String name;

    public MethodParams(@NotNull String str) {
        Intrinsics.checkNotNullParameter(str, RewardPlus.NAME);
        Locale locale = Locale.ENGLISH;
        Intrinsics.checkNotNullExpressionValue(locale, "ENGLISH");
        String lowerCase = str.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "this as java.lang.String).toLowerCase(locale)");
        this.name = lowerCase;
    }

    @NotNull
    public final String getName() {
        return this.name;
    }
}
