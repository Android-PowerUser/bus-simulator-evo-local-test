package io.bidmachine.rendering.internal;

import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Lambda;
import kotlinx.coroutines.CoroutineDispatcher;
import kotlinx.coroutines.Dispatchers;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
final class g$b extends Lambda implements Function0 {
    public static final g$b a = new g$b();

    g$b() {
        super(0);
    }

    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public final CoroutineDispatcher invoke() {
        return Dispatchers.getMain().getImmediate();
    }
}
