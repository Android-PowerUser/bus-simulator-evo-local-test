package io.bidmachine.rendering.internal.gradient;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.RectF;
import android.graphics.Shader;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class a extends BitmapShader {
    public static final a a = new a((DefaultConstructorMarker) null);

    /* JADX WARN: Illegal instructions before constructor call */
    public a(RectF rectF, int[] iArr, Bitmap.Config config) {
        Intrinsics.checkNotNullParameter(rectF, "bounds");
        Intrinsics.checkNotNullParameter(iArr, "colors");
        Intrinsics.checkNotNullParameter(config, "config");
        Bitmap bitmapA = a.a(a, rectF, iArr, config);
        Shader.TileMode tileMode = Shader.TileMode.CLAMP;
        super(bitmapA, tileMode, tileMode);
    }
}
