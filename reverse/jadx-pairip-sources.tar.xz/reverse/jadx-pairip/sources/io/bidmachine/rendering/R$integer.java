package io.bidmachine.rendering;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class R$integer {
    public static final int bm_bottom_sheet_slide_duration = 2131427330;

    private R$integer() {
    }
}
