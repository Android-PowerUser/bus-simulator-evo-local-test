package io.bidmachine.rendering.internal;

import android.view.View;
import io.bidmachine.rendering.model.Border;
import io.bidmachine.rendering.model.Gradient;
import java.util.List;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
final class y$d extends Lambda implements Function1 {
    final /* synthetic */ View a;
    final /* synthetic */ Gradient b;
    final /* synthetic */ y c;
    final /* synthetic */ Integer d;
    final /* synthetic */ Border e;
    final /* synthetic */ y$a f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    y$d(View view, Gradient gradient, y yVar, Integer num, Border border, y$a y_a) {
        super(1);
        this.a = view;
        this.b = gradient;
        this.c = yVar;
        this.d = num;
        this.e = border;
        this.f = y_a;
    }

    public final void a(List list) {
        Intrinsics.checkNotNullParameter(list, "it");
        y.a(this.a, this.c, this.d, this.e, this.f, true, new Gradient(this.b.getType(), this.b.getDirection(), list));
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        a((List) obj);
        return Unit.INSTANCE;
    }
}
