package io.bidmachine.rendering.internal.controller;

import io.bidmachine.rendering.internal.view.f;
import io.bidmachine.util.Executable;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class b$$ExternalSyntheticLambda13 implements Executable {
    public final void execute(Object obj) {
        ((f) obj).b();
    }
}
