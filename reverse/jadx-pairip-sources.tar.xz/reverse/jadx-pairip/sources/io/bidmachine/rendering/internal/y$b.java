package io.bidmachine.rendering.internal;

import android.graphics.Bitmap;
import android.view.View;
import io.bidmachine.rendering.Repository;
import io.bidmachine.rendering.model.Border;
import io.bidmachine.rendering.model.Error;
import io.bidmachine.rendering.model.ScaleType;
import java.lang.ref.WeakReference;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class y$b implements Repository.ResultCallback {
    private final boolean a;
    private final ScaleType b;
    private final Integer c;
    private final Border d;
    private final WeakReference e;
    final /* synthetic */ y f;

    public y$b(y yVar, View view, boolean z, ScaleType scaleType, Integer num, Border border) {
        Intrinsics.checkNotNullParameter(view, "view");
        this.f = yVar;
        this.a = z;
        this.b = scaleType;
        this.c = num;
        this.d = border;
        this.e = new WeakReference(view);
    }

    public void onError(Error error) {
        Intrinsics.checkNotNullParameter(error, "error");
    }

    public void onSuccess(Bitmap bitmap) {
        Intrinsics.checkNotNullParameter(bitmap, "successType");
        y yVar = this.f;
        try {
            View view = (View) this.e.get();
            if (view == null) {
                return;
            }
            Intrinsics.checkNotNullExpressionValue(view, "weakView.get() ?: return");
            yVar.a(view, this.a, bitmap, this.b, this.c, this.d);
            Unit unit = Unit.INSTANCE;
        } catch (Throwable unused) {
        }
    }
}
