package io.bidmachine.rendering.internal.controller;

import io.bidmachine.util.Executable;
import kotlin.jvm.functions.Function0;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class b$$ExternalSyntheticLambda14 implements Executable {
    public final /* synthetic */ b f$0;

    public final void execute(Object obj) {
        b.$r8$lambda$Evq1mykrhcIAE5ARGRWVG8eIQRE(this.f$0, (Function0) obj);
    }
}
