package io.bidmachine.rendering.internal.meanbackground;

import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.IntCompanionObject;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
final class l$b extends ContinuationImpl {
    Object a;
    Object b;
    long c;
    /* synthetic */ Object d;
    final /* synthetic */ l e;
    int f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    l$b(l lVar, Continuation continuation) {
        super(continuation);
        this.e = lVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final Object invokeSuspend(Object obj) {
        this.d = obj;
        this.f |= IntCompanionObject.MIN_VALUE;
        return this.e.a((String) null, (Function1) null, this);
    }
}
