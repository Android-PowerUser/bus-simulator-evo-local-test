package io.bidmachine.rendering.internal.meanbackground;

import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class c$a {
    private final Integer a;
    private final float b;
    private final float c;
    private final float d;

    public c$a(Integer num, float f, float f2, float f3) {
        this.a = num;
        this.b = f;
        this.c = f2;
        this.d = f3;
    }

    public final float a() {
        return this.b;
    }

    public final Integer b() {
        return this.a;
    }

    public final float c() {
        return this.d;
    }

    public final float d() {
        return this.c;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c$a)) {
            return false;
        }
        c$a c_a = (c$a) obj;
        return Intrinsics.areEqual(this.a, c_a.a) && Float.compare(this.b, c_a.b) == 0 && Float.compare(this.c, c_a.c) == 0 && Float.compare(this.d, c_a.d) == 0;
    }

    public int hashCode() {
        Integer num = this.a;
        return ((((((num == null ? 0 : num.hashCode()) * 31) + Float.hashCode(this.b)) * 31) + Float.hashCode(this.c)) * 31) + Float.hashCode(this.d);
    }

    public String toString() {
        return "Config(backgroundColor=" + this.a + ", alphaThreshold=" + this.b + ", tolerance=" + this.c + ", brightnessThreshold=" + this.d + ')';
    }
}
