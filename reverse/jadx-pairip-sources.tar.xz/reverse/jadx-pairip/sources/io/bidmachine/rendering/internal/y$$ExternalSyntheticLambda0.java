package io.bidmachine.rendering.internal;

import android.animation.ValueAnimator;
import android.graphics.drawable.Drawable;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class y$$ExternalSyntheticLambda0 implements ValueAnimator.AnimatorUpdateListener {
    public final /* synthetic */ Drawable f$0;

    @Override // android.animation.ValueAnimator.AnimatorUpdateListener
    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        y.$r8$lambda$hss22ctj0LwDfBa38Eu8V0SXG44(this.f$0, valueAnimator);
    }
}
