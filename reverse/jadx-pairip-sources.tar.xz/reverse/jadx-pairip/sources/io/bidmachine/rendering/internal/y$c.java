package io.bidmachine.rendering.internal;

import android.view.View;
import io.bidmachine.rendering.model.Border;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Lambda;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
final class y$c extends Lambda implements Function1 {
    final /* synthetic */ View a;
    final /* synthetic */ boolean b;
    final /* synthetic */ y c;
    final /* synthetic */ Integer d;
    final /* synthetic */ Border e;
    final /* synthetic */ y$a f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    y$c(View view, boolean z, y yVar, Integer num, Border border, y$a y_a) {
        super(1);
        this.a = view;
        this.b = z;
        this.c = yVar;
        this.d = num;
        this.e = border;
        this.f = y_a;
    }

    public final void a(int i) {
        y.a(this.a, this.c, this.d, this.e, this.f, this.b, i);
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        a(((Number) obj).intValue());
        return Unit.INSTANCE;
    }
}
