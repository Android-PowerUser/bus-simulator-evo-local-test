package io.bidmachine.rendering.model;

import io.bidmachine.util.Utils;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
final class MediaSource$Companion$b extends Lambda implements Function1 {
    public static final MediaSource$Companion$b a = new MediaSource$Companion$b();

    MediaSource$Companion$b() {
        super(1);
    }

    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public final Boolean invoke(String str) {
        Intrinsics.checkNotNullParameter(str, "it");
        return Boolean.valueOf(Utils.isHttpUrl(str));
    }
}
