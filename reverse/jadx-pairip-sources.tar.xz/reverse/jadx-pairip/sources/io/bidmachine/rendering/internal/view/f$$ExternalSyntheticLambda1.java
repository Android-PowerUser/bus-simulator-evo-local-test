package io.bidmachine.rendering.internal.view;

import io.bidmachine.rendering.model.BrokenCreativeEvent;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class f$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ f f$0;
    public final /* synthetic */ BrokenCreativeEvent f$1;

    public /* synthetic */ f$$ExternalSyntheticLambda1(f fVar, BrokenCreativeEvent brokenCreativeEvent) {
        this.f$0 = fVar;
        this.f$1 = brokenCreativeEvent;
    }

    @Override // java.lang.Runnable
    public final void run() {
        f.$r8$lambda$hxg2RDqtf-b8DDnu5WPqe0_6FpY(this.f$0, this.f$1);
    }
}
