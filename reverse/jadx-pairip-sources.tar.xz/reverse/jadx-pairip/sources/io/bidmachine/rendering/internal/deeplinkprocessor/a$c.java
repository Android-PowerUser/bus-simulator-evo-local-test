package io.bidmachine.rendering.internal.deeplinkprocessor;

import android.content.Context;
import android.net.Uri;
import io.bidmachine.rendering.utils.UiUtils;
import io.bidmachine.rendering.utils.UrlHandler;
import io.bidmachine.util.Executable;
import io.bidmachine.util.Utils;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class a$c implements Executable {
    private final Uri a;
    private final Executable b;
    private final Context c;

    public a$c(Context context, Uri uri, Executable executable) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(uri, "baseUri");
        this.a = uri;
        this.b = executable;
        Context applicationContext = context.getApplicationContext();
        Intrinsics.checkNotNullExpressionValue(applicationContext, "context.applicationContext");
        this.c = applicationContext;
    }

    public void a(boolean z) {
        if (z) {
            UrlHandler.track$bidmachine_android_sdk_bi_3_5_1(this.a.getQueryParameter("primaryTrackingUrl"));
            UiUtils.onUiThreadWithArgSafely(Boolean.TRUE, this.b);
            return;
        }
        String queryParameter = this.a.getQueryParameter("fallbackUrl");
        if (queryParameter == null || queryParameter.length() == 0) {
            UiUtils.onUiThreadWithArgSafely(Boolean.FALSE, this.b);
            return;
        }
        Uri validUri = Utils.getValidUri(queryParameter);
        if (validUri == null) {
            UiUtils.onUiThreadWithArgSafely(Boolean.FALSE, this.b);
            return;
        }
        Context context = this.c;
        final Uri uri = this.a;
        final Executable executable = this.b;
        UrlHandler.openBrowser(context, validUri, new Executable(uri, executable) { // from class: io.bidmachine.rendering.internal.deeplinkprocessor.a$b
            private final Uri a;
            private final Executable b;

            {
                Intrinsics.checkNotNullParameter(uri, "baseUri");
                this.a = uri;
                this.b = executable;
            }

            public void a(boolean z2) {
                if (z2) {
                    UrlHandler.track$bidmachine_android_sdk_bi_3_5_1(this.a.getQueryParameter("fallbackTrackingUrl"));
                }
                UiUtils.onUiThreadWithArgSafely(Boolean.valueOf(z2), this.b);
            }

            public /* bridge */ /* synthetic */ void execute(Object obj) {
                a(((Boolean) obj).booleanValue());
            }
        });
    }

    public /* bridge */ /* synthetic */ void execute(Object obj) {
        a(((Boolean) obj).booleanValue());
    }
}
