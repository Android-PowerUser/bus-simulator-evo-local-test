package io.bidmachine.rendering.utils;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public enum NetworkRequest$Method {
    Get("GET"),
    Post("POST");

    private final String a;

    NetworkRequest$Method(String networkName) {
        this.a = networkName;
    }

    public String getNetworkName() {
        return this.a;
    }
}
