package io.bidmachine.rendering.model;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\b\u0010\t¨\u0006\n"}, d2 = {"Lio/bidmachine/rendering/model/Base64ResourceSource;", "Lio/bidmachine/rendering/model/ResourceSource;", "", "base64", "<init>", "(Ljava/lang/String;)V", "a", "Ljava/lang/String;", "getBase64", "()Ljava/lang/String;", "bidmachine-android-sdk_bi_3_5_1"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class Base64ResourceSource implements ResourceSource {

    /* JADX INFO: renamed from: a, reason: from kotlin metadata */
    private final String base64;

    public Base64ResourceSource(@NotNull String str) {
        Intrinsics.checkNotNullParameter(str, "base64");
        this.base64 = str;
    }

    @NotNull
    public final String getBase64() {
        return this.base64;
    }
}
