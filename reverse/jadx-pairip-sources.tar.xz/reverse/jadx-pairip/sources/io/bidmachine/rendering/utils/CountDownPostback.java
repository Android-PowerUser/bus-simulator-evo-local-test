package io.bidmachine.rendering.utils;

import androidx.annotation.NonNull;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class CountDownPostback implements Runnable {
    private final Runnable a;
    private final AtomicInteger b;

    public CountDownPostback(int count, @NonNull Runnable runnable) {
        this.a = runnable;
        this.b = new AtomicInteger(count);
    }

    @Override // java.lang.Runnable
    public void run() {
        if (this.b.decrementAndGet() > 0) {
            return;
        }
        this.a.run();
    }
}
