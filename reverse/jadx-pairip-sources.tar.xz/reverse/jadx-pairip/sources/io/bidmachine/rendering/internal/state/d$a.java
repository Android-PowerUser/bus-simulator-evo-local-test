package io.bidmachine.rendering.internal.state;

import androidx.core.app.NotificationCompat;
import com.facebook.AccessToken;
import io.bidmachine.rendering.internal.n;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class d$a implements a.b {
    final /* synthetic */ d a;

    d$a(d dVar) {
        this.a = dVar;
    }

    public void a(a aVar, a.a aVar2) {
        Intrinsics.checkNotNullParameter(aVar, AccessToken.SOURCE_KEY);
        Intrinsics.checkNotNullParameter(aVar2, NotificationCompat.CATEGORY_EVENT);
        n.b(d.a(this.a), "Event: " + aVar2, new Object[0]);
    }
}
