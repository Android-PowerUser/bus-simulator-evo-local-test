package io.bidmachine.rendering.internal.gradient;

import android.graphics.Bitmap;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Build;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class c implements e {
    private final boolean a;
    private final Shader b;
    private final Shader c;

    public c(RectF rectF, int[] iArr, Bitmap.Config config, boolean z) {
        Intrinsics.checkNotNullParameter(rectF, "bounds");
        Intrinsics.checkNotNullParameter(iArr, "colors");
        Intrinsics.checkNotNullParameter(config, "bitmapConfig");
        this.a = z;
        this.b = new a(rectF, iArr, config);
        this.c = z ? new b(rectF, iArr) : null;
    }

    @Override // io.bidmachine.rendering.internal.gradient.e
    public Shader a(boolean z) {
        Shader shader;
        return (this.a && (shader = this.c) != null && z) ? shader : this.b;
    }

    public /* synthetic */ c(RectF rectF, int[] iArr, Bitmap.Config config, boolean z, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(rectF, iArr, (i & 4) != 0 ? Bitmap.Config.ARGB_8888 : config, (i & 8) != 0 ? Build.VERSION.SDK_INT >= 33 : z);
    }
}
