package io.bidmachine.rendering.internal.view;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class f$$ExternalSyntheticLambda2 implements Runnable {
    public final /* synthetic */ f f$0;

    @Override // java.lang.Runnable
    public final void run() {
        f.$r8$lambda$MupWqAl0bIbx1oPL7BWHsy1svlU(this.f$0);
    }
}
