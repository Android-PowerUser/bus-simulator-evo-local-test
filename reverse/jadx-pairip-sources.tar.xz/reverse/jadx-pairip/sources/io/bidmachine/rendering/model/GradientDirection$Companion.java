package io.bidmachine.rendering.model;

import io.bidmachine.util.UtilsKt;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0014\u0010\u0003\u001a\u0004\u0018\u00010\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006H\u0007¨\u0006\u0007"}, d2 = {"Lio/bidmachine/rendering/model/GradientDirection$Companion;", "", "()V", "get", "Lio/bidmachine/rendering/model/GradientDirection;", "key", "", "bidmachine-android-sdk_bi_3_5_1"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class GradientDirection$Companion {
    public /* synthetic */ GradientDirection$Companion(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }

    @JvmStatic
    @Nullable
    public final GradientDirection get(@Nullable String key) {
        return UtilsKt.find(GradientDirection.values(), key);
    }

    private GradientDirection$Companion() {
    }
}
