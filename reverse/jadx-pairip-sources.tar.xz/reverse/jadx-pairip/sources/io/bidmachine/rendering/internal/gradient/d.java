package io.bidmachine.rendering.internal.gradient;

import android.graphics.Shader;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class d implements e {
    private final Shader a;

    public d(Shader shader) {
        Intrinsics.checkNotNullParameter(shader, "shader");
        this.a = shader;
    }

    @Override // io.bidmachine.rendering.internal.gradient.e
    public Shader a(boolean z) {
        return this.a;
    }
}
