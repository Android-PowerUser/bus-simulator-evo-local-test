package io.bidmachine.rendering.internal.controller;

import io.bidmachine.rendering.internal.m;
import io.bidmachine.rendering.utils.VisibilityChanger;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class h$f$u$a implements m {
    final /* synthetic */ Object a;

    public h$f$u$a(Object obj) {
        this.a = obj;
    }

    public final void onRun() {
        ((VisibilityChanger) this.a).unlockVisibility();
    }
}
