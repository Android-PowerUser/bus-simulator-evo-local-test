package io.bidmachine.rendering.internal;

import kotlin.jvm.internal.DefaultConstructorMarker;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class g$e {
    public /* synthetic */ g$e(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }

    public final g a() {
        return g.a();
    }

    private g$e() {
    }
}
