package io.bidmachine.rendering.utils.taskmanager;

import androidx.annotation.CallSuper;
import androidx.annotation.NonNull;
import io.bidmachine.rendering.utils.Cancelable;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public abstract class BaseTaskManager implements TaskManager {
    private void a(Runnable runnable, boolean z) {
        try {
            if (runnable instanceof Cancelable) {
                ((Cancelable) runnable).setCancel(z);
            }
        } catch (Throwable unused) {
        }
    }

    @CallSuper
    public void cancel(@NonNull Runnable task) {
        a(task, true);
    }

    @CallSuper
    public void execute(@NonNull Runnable task) {
        a(task, false);
    }

    @CallSuper
    public void schedule(@NonNull Runnable task, long delay, @NonNull TimeUnit timeUnit) {
        a(task, false);
    }
}
