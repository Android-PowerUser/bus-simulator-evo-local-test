package io.bidmachine.rendering.internal;

import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Lambda;
import kotlinx.coroutines.CoroutineDispatcher;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
final class g$h extends Lambda implements Function0 {
    final /* synthetic */ g a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    g$h(g gVar) {
        super(0);
        this.a = gVar;
    }

    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public final CoroutineDispatcher invoke() {
        return (CoroutineDispatcher) g.d(this.a).invoke();
    }
}
