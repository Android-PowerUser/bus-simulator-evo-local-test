package io.bidmachine.rendering.internal;

import android.animation.TimeInterpolator;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class y$a {
    private final long a;
    private final TimeInterpolator b;

    public y$a(long j, TimeInterpolator timeInterpolator) {
        Intrinsics.checkNotNullParameter(timeInterpolator, "interpolator");
        this.a = j;
        this.b = timeInterpolator;
    }

    public final long a() {
        return this.a;
    }

    public final TimeInterpolator b() {
        return this.b;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof y$a)) {
            return false;
        }
        y$a y_a = (y$a) obj;
        return this.a == y_a.a && Intrinsics.areEqual(this.b, y_a.b);
    }

    public int hashCode() {
        return (Long.hashCode(this.a) * 31) + this.b.hashCode();
    }

    public String toString() {
        return "AnimationConfig(durationMs=" + this.a + ", interpolator=" + this.b + ')';
    }

    public final boolean a(View view) {
        Intrinsics.checkNotNullParameter(view, "view");
        return this.a > 0 && view.isLaidOut();
    }

    public /* synthetic */ y$a(long j, TimeInterpolator timeInterpolator, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? 200L : j, (i & 2) != 0 ? new DecelerateInterpolator() : timeInterpolator);
    }
}
