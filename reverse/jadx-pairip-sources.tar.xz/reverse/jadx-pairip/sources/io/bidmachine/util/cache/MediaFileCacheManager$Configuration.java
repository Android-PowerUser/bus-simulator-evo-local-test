package io.bidmachine.util.cache;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: MediaFileCacheManager.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000e¨\u0006\u000f"}, d2 = {"Lio/bidmachine/util/cache/MediaFileCacheManager$Configuration;", "", "cleanConfiguration", "Lio/bidmachine/util/cache/MediaFileCacheManager$CleanConfiguration;", "connectionConfiguration", "Lio/bidmachine/util/cache/MediaFileCacheManager$ConnectionConfiguration;", "policyConfiguration", "Lio/bidmachine/util/cache/MediaFileCacheManager$PolicyConfiguration;", "(Lio/bidmachine/util/cache/MediaFileCacheManager$CleanConfiguration;Lio/bidmachine/util/cache/MediaFileCacheManager$ConnectionConfiguration;Lio/bidmachine/util/cache/MediaFileCacheManager$PolicyConfiguration;)V", "getCleanConfiguration", "()Lio/bidmachine/util/cache/MediaFileCacheManager$CleanConfiguration;", "getConnectionConfiguration", "()Lio/bidmachine/util/cache/MediaFileCacheManager$ConnectionConfiguration;", "getPolicyConfiguration", "()Lio/bidmachine/util/cache/MediaFileCacheManager$PolicyConfiguration;", "bidmachine-android-sdk_ca_3_5_1"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class MediaFileCacheManager$Configuration {

    @NotNull
    private final MediaFileCacheManager.CleanConfiguration cleanConfiguration;

    @NotNull
    private final MediaFileCacheManager.ConnectionConfiguration connectionConfiguration;

    @NotNull
    private final MediaFileCacheManager$PolicyConfiguration policyConfiguration;

    public MediaFileCacheManager$Configuration(@NotNull MediaFileCacheManager.CleanConfiguration cleanConfiguration, @NotNull MediaFileCacheManager.ConnectionConfiguration connectionConfiguration, @NotNull MediaFileCacheManager$PolicyConfiguration mediaFileCacheManager$PolicyConfiguration) {
        Intrinsics.checkNotNullParameter(cleanConfiguration, "cleanConfiguration");
        Intrinsics.checkNotNullParameter(connectionConfiguration, "connectionConfiguration");
        Intrinsics.checkNotNullParameter(mediaFileCacheManager$PolicyConfiguration, "policyConfiguration");
        this.cleanConfiguration = cleanConfiguration;
        this.connectionConfiguration = connectionConfiguration;
        this.policyConfiguration = mediaFileCacheManager$PolicyConfiguration;
    }

    @NotNull
    public final MediaFileCacheManager.CleanConfiguration getCleanConfiguration() {
        return this.cleanConfiguration;
    }

    @NotNull
    public final MediaFileCacheManager.ConnectionConfiguration getConnectionConfiguration() {
        return this.connectionConfiguration;
    }

    @NotNull
    public final MediaFileCacheManager$PolicyConfiguration getPolicyConfiguration() {
        return this.policyConfiguration;
    }
}
