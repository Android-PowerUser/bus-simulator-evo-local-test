package io.bidmachine.util.cache;

import io.bidmachine.util.download.CallData;
import io.bidmachine.util.download.DownloadManager;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.time.Duration;
import kotlinx.coroutines.CoroutineScope;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: MediaFileCacheManager.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "Lkotlin/Result;", "Lio/bidmachine/util/download/DownloadManager$CallData;", "<anonymous>"}, k = 3, mv = {1, 7, 1})
@DebugMetadata(c = "io.bidmachine.util.cache.MediaFileCacheManager$pickRemoteMediaFile$2$remoteMediaFileInfoList$1$1", f = "MediaFileCacheManager.kt", i = {}, l = {302}, m = "invokeSuspend", n = {}, s = {})
final class MediaFileCacheManager$pickRemoteMediaFile$2$remoteMediaFileInfoList$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Result<? extends CallData>>, Object> {
    final /* synthetic */ long $headRequestTimeout;
    final /* synthetic */ String $mediaUrl;
    int label;
    final /* synthetic */ MediaFileCacheManager this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    MediaFileCacheManager$pickRemoteMediaFile$2$remoteMediaFileInfoList$1$1(MediaFileCacheManager mediaFileCacheManager, String str, long j, Continuation<? super MediaFileCacheManager$pickRemoteMediaFile$2$remoteMediaFileInfoList$1$1> continuation) {
        super(2, continuation);
        this.this$0 = mediaFileCacheManager;
        this.$mediaUrl = str;
        this.$headRequestTimeout = j;
    }

    @NotNull
    public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
        return new MediaFileCacheManager$pickRemoteMediaFile$2$remoteMediaFileInfoList$1$1(this.this$0, this.$mediaUrl, this.$headRequestTimeout, continuation);
    }

    @Nullable
    public final Object invoke(@NotNull CoroutineScope coroutineScope, @Nullable Continuation<? super Result<CallData>> continuation) {
        return ((MediaFileCacheManager$pickRemoteMediaFile$2$remoteMediaFileInfoList$1$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Nullable
    public final Object invokeSuspend(@NotNull Object obj) throws Throwable {
        Object obj2;
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i == 0) {
            ResultKt.throwOnFailure(obj);
            DownloadManager downloadManagerAccess$getDownloadManager$p = MediaFileCacheManager.access$getDownloadManager$p(this.this$0);
            String str = this.$mediaUrl;
            Duration duration = Duration.box-impl(this.$headRequestTimeout);
            this.label = 1;
            obj2 = downloadManagerAccess$getDownloadManager$p.getHeadCallData-2Ivn440(str, duration, this);
            if (obj2 == coroutine_suspended) {
                return coroutine_suspended;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            obj2 = ((Result) obj).unbox-impl();
        }
        return Result.box-impl(obj2);
    }
}
