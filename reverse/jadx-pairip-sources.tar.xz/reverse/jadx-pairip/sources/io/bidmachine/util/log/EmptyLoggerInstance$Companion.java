package io.bidmachine.util.log;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: EmptyLoggerInstance.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Lio/bidmachine/util/log/EmptyLoggerInstance$Companion;", "", "()V", "INSTANCE", "Lio/bidmachine/util/log/LoggerInstance;", "getINSTANCE", "()Lio/bidmachine/util/log/LoggerInstance;", "bidmachine-android-sdk_ca_3_5_1"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class EmptyLoggerInstance$Companion {
    public /* synthetic */ EmptyLoggerInstance$Companion(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }

    private EmptyLoggerInstance$Companion() {
    }

    @NotNull
    public final LoggerInstance getINSTANCE() {
        return EmptyLoggerInstance.access$getINSTANCE$cp();
    }
}
