package io.bidmachine.util.download;

import io.bidmachine.util.network.NetworkRequest;
import java.io.File;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Lambda;
import kotlin.time.Duration;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: DownloadManagerImpl.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\u0018\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0010\u0000\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u00012\u000e\u0010\u0003\u001a\n\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u00042\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005H\n¢\u0006\u0004\b\u0007\u0010\b"}, d2 = {"<anonymous>", "Lkotlin/Result;", "Lio/bidmachine/util/download/DownloadManager$DownloadData;", "request", "Lio/bidmachine/util/network/NetworkRequest;", "Ljava/io/File;", "response", "invoke-gIAlu-s", "(Lio/bidmachine/util/network/NetworkRequest;Ljava/io/File;)Ljava/lang/Object;"}, k = 3, mv = {1, 7, 1}, xi = 48)
final class DownloadManagerImpl$NetworkContentFetcher$get$2$listener$1 extends Lambda implements Function2<NetworkRequest<File>, File, Result<? extends DownloadManager.DownloadData>> {
    final /* synthetic */ String $url;
    final /* synthetic */ DownloadManagerImpl.NetworkContentFetcher this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    DownloadManagerImpl$NetworkContentFetcher$get$2$listener$1(DownloadManagerImpl.NetworkContentFetcher networkContentFetcher, String str) {
        super(2);
        this.this$0 = networkContentFetcher;
        this.$url = str;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
        return Result.box-impl(m1880invokegIAlus((NetworkRequest) obj, (File) obj2));
    }

    @NotNull
    /* JADX INFO: renamed from: invoke-gIAlu-s, reason: not valid java name */
    public final Object m1880invokegIAlus(@Nullable NetworkRequest<File> networkRequest, @Nullable File file) {
        DownloadManagerImpl.NetworkContentFetcher.access$getLogger$p(this.this$0).d("DownloadManager", new 1(this.$url));
        Duration duration = networkRequest != null ? networkRequest.getExecutionTime-FghU774() : null;
        if (file != null && duration != null) {
            Result.Companion companion = Result.Companion;
            return Result.constructor-impl(new DownloadManager.DownloadData(duration.unbox-impl(), file, (DefaultConstructorMarker) null));
        }
        Result.Companion companion2 = Result.Companion;
        return Result.constructor-impl((Object) null);
    }
}
