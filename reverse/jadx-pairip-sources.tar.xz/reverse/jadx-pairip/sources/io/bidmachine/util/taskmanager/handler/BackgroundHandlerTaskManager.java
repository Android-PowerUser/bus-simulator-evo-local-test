package io.bidmachine.util.taskmanager.handler;

import android.os.Handler;
import android.os.HandlerThread;
import kotlin.Metadata;

/* JADX INFO: compiled from: BackgroundHandlerTaskManager.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lio/bidmachine/util/taskmanager/handler/BackgroundHandlerTaskManager;", "Lio/bidmachine/util/taskmanager/handler/HandlerTaskManager;", "()V", "bidmachine-android-sdk_ca_3_5_1"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class BackgroundHandlerTaskManager extends HandlerTaskManager {
    public BackgroundHandlerTaskManager() {
        HandlerThread handlerThread = new HandlerThread("BackgroundHandlerTaskManager");
        handlerThread.start();
        super(new Handler(handlerThread.getLooper()));
    }
}
