package io.bidmachine.util.download;

import io.bidmachine.rendering.model.EventTaskParams;
import io.bidmachine.util.network.NetworkUtils;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlin.time.Duration;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: renamed from: io.bidmachine.util.download.DownloadManager$CallData, reason: from toString */
/* JADX INFO: compiled from: DownloadManager.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010 \n\u0002\b\n\n\u0002\u0010\t\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0007\b\u0086\b\u0018\u00002\u00020\u0001B*\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0018\u0010\u0004\u001a\u0014\u0012\u0004\u0012\u00020\u0006\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u00070\u0005ø\u0001\u0000¢\u0006\u0002\u0010\bJ\u0019\u0010\u000e\u001a\u00020\u0003HÆ\u0003ø\u0001\u0002ø\u0001\u0001ø\u0001\u0000¢\u0006\u0004\b\u000f\u0010\nJ\u001b\u0010\u0010\u001a\u0014\u0012\u0004\u0012\u00020\u0006\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u00070\u0005HÆ\u0003J\r\u0010\u0011\u001a\u0004\u0018\u00010\u0012¢\u0006\u0002\u0010\u0013J\b\u0010\u0014\u001a\u0004\u0018\u00010\u0006J<\u0010\u0015\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\u001a\b\u0002\u0010\u0004\u001a\u0014\u0012\u0004\u0012\u00020\u0006\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u00070\u0005HÆ\u0001ø\u0001\u0001ø\u0001\u0000¢\u0006\u0004\b\u0016\u0010\u0017J\u0013\u0010\u0018\u001a\u00020\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001b\u001a\u00020\u001cHÖ\u0001J!\u0010\u001d\u001a\u0004\u0018\u00010\u00122\u0006\u0010\u001e\u001a\u00020\u00062\n\b\u0002\u0010\u001f\u001a\u0004\u0018\u00010\u0012¢\u0006\u0002\u0010 J\u001c\u0010!\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u001e\u001a\u00020\u00062\n\b\u0002\u0010\u001f\u001a\u0004\u0018\u00010\u0006J\t\u0010\"\u001a\u00020\u0006HÖ\u0001R\u001c\u0010\u0002\u001a\u00020\u0003ø\u0001\u0000ø\u0001\u0001ø\u0001\u0002¢\u0006\n\n\u0002\u0010\u000b\u001a\u0004\b\t\u0010\nR#\u0010\u0004\u001a\u0014\u0012\u0004\u0012\u00020\u0006\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u00070\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\r\u0082\u0002\u000f\n\u0002\b\u0019\n\u0005\b¡\u001e0\u0001\n\u0002\b!¨\u0006#"}, d2 = {"Lio/bidmachine/util/download/DownloadManager$CallData;", "", "executionTime", "Lkotlin/time/Duration;", "headers", "", "", "", "(JLjava/util/Map;Lkotlin/jvm/internal/DefaultConstructorMarker;)V", "getExecutionTime-UwyO8pc", "()J", "J", "getHeaders", "()Ljava/util/Map;", "component1", "component1-UwyO8pc", "component2", "contentLength", "", "()Ljava/lang/Long;", "contentType", "copy", "copy-VtjQ1oo", "(JLjava/util/Map;)Lio/bidmachine/util/download/DownloadManager$CallData;", "equals", "", "other", "hashCode", "", "optLongHeader", "key", EventTaskParams.STATE_GROUP_DEFAULT, "(Ljava/lang/String;Ljava/lang/Long;)Ljava/lang/Long;", "optStringHeader", "toString", "bidmachine-android-sdk_ca_3_5_1"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final /* data */ class CallData {
    private final long executionTime;

    @NotNull
    private final Map<String, List<String>> headers;

    public /* synthetic */ CallData(long j, Map map, DefaultConstructorMarker defaultConstructorMarker) {
        this(j, map);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: copy-VtjQ1oo$default, reason: not valid java name */
    public static /* synthetic */ CallData m1876copyVtjQ1oo$default(CallData callData, long j, Map map, int i, Object obj) {
        if ((i & 1) != 0) {
            j = callData.executionTime;
        }
        if ((i & 2) != 0) {
            map = callData.headers;
        }
        return callData.m1878copyVtjQ1oo(j, map);
    }

    /* JADX INFO: renamed from: component1-UwyO8pc, reason: not valid java name and from getter */
    public final long getExecutionTime() {
        return this.executionTime;
    }

    @NotNull
    public final Map<String, List<String>> component2() {
        return this.headers;
    }

    @NotNull
    /* JADX INFO: renamed from: copy-VtjQ1oo, reason: not valid java name */
    public final CallData m1878copyVtjQ1oo(long executionTime, @NotNull Map<String, ? extends List<String>> headers) {
        Intrinsics.checkNotNullParameter(headers, "headers");
        return new CallData(executionTime, headers, null);
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof CallData)) {
            return false;
        }
        CallData callData = (CallData) other;
        return Duration.equals-impl0(this.executionTime, callData.executionTime) && Intrinsics.areEqual(this.headers, callData.headers);
    }

    public int hashCode() {
        return (Duration.hashCode-impl(this.executionTime) * 31) + this.headers.hashCode();
    }

    @NotNull
    public String toString() {
        return "CallData(executionTime=" + ((Object) Duration.toString-impl(this.executionTime)) + ", headers=" + this.headers + ')';
    }

    /* JADX WARN: Multi-variable type inference failed */
    private CallData(long j, Map<String, ? extends List<String>> map) {
        this.executionTime = j;
        this.headers = map;
    }

    /* JADX INFO: renamed from: getExecutionTime-UwyO8pc, reason: not valid java name */
    public final long m1879getExecutionTimeUwyO8pc() {
        return this.executionTime;
    }

    @NotNull
    public final Map<String, List<String>> getHeaders() {
        return this.headers;
    }

    public static /* synthetic */ Long optLongHeader$default(CallData callData, String str, Long l, int i, Object obj) {
        if ((i & 2) != 0) {
            l = null;
        }
        return callData.optLongHeader(str, l);
    }

    @Nullable
    public final Long optLongHeader(@NotNull String key, @Nullable Long l) {
        String str;
        Long longOrNull;
        Intrinsics.checkNotNullParameter(key, "key");
        List<String> list = this.headers.get(key);
        return (list == null || (str = (String) CollectionsKt.firstOrNull(list)) == null || (longOrNull = StringsKt.toLongOrNull(str)) == null) ? l : longOrNull;
    }

    public static /* synthetic */ String optStringHeader$default(CallData callData, String str, String str2, int i, Object obj) {
        if ((i & 2) != 0) {
            str2 = null;
        }
        return callData.optStringHeader(str, str2);
    }

    @Nullable
    public final String optStringHeader(@NotNull String key, @Nullable String str) {
        String str2;
        Intrinsics.checkNotNullParameter(key, "key");
        List<String> list = this.headers.get(key);
        return (list == null || (str2 = (String) CollectionsKt.firstOrNull(list)) == null) ? str : str2;
    }

    @Nullable
    public final Long contentLength() {
        return optLongHeader$default(this, NetworkUtils.HEADER_CONTENT_LENGTH, null, 2, null);
    }

    @Nullable
    public final String contentType() {
        return optStringHeader$default(this, NetworkUtils.HEADER_CONTENT_TYPE, null, 2, null);
    }
}
