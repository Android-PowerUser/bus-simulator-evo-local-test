package io.bidmachine.util.cache;

import java.io.File;
import java.util.Date;
import java.util.Map;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.time.Duration;
import kotlin.time.DurationKt;
import kotlin.time.DurationUnit;
import kotlinx.coroutines.CoroutineScope;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: MediaFileMetadataManager.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0010\u0002\u001a\u0004\u0018\u00010\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "Lio/bidmachine/util/cache/MediaFileMetadata;", "<anonymous>"}, k = 3, mv = {1, 7, 1})
@DebugMetadata(c = "io.bidmachine.util.cache.MediaFileMetadataManager$getMediaFileMetadata$2", f = "MediaFileMetadataManager.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
final class MediaFileMetadataManager$getMediaFileMetadata$2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super MediaFileMetadata>, Object> {
    final /* synthetic */ File $mediaFile;
    private /* synthetic */ Object L$0;
    int label;
    final /* synthetic */ MediaFileMetadataManager this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    MediaFileMetadataManager$getMediaFileMetadata$2(File file, MediaFileMetadataManager mediaFileMetadataManager, Continuation<? super MediaFileMetadataManager$getMediaFileMetadata$2> continuation) {
        super(2, continuation);
        this.$mediaFile = file;
        this.this$0 = mediaFileMetadataManager;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [io.bidmachine.util.cache.MediaFileMetadataManager$getMediaFileMetadata$2, kotlin.coroutines.Continuation<kotlin.Unit>] */
    @NotNull
    public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
        ?? mediaFileMetadataManager$getMediaFileMetadata$2 = new MediaFileMetadataManager$getMediaFileMetadata$2(this.$mediaFile, this.this$0, continuation);
        mediaFileMetadataManager$getMediaFileMetadata$2.L$0 = obj;
        return mediaFileMetadataManager$getMediaFileMetadata$2;
    }

    @Nullable
    public final Object invoke(@NotNull CoroutineScope coroutineScope, @Nullable Continuation<? super MediaFileMetadata> continuation) {
        return ((MediaFileMetadataManager$getMediaFileMetadata$2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    @Nullable
    public final Object invokeSuspend(@NotNull Object obj) throws Throwable {
        Object obj2;
        MediaFileMetadata mediaFileMetadata;
        IntrinsicsKt.getCOROUTINE_SUSPENDED();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        ResultKt.throwOnFailure(obj);
        if (!this.$mediaFile.exists()) {
            return null;
        }
        Object objAccess$getMediaFileMetadataMapLock$p = MediaFileMetadataManager.access$getMediaFileMetadataMapLock$p(this.this$0);
        MediaFileMetadataManager mediaFileMetadataManager = this.this$0;
        File file = this.$mediaFile;
        synchronized (objAccess$getMediaFileMetadataMapLock$p) {
            try {
                MediaFileMetadata mediaFileMetadata2 = (MediaFileMetadata) MediaFileMetadataManager.access$getMediaFileMetadataMap$p(mediaFileMetadataManager).get(file.getName());
                if (mediaFileMetadata2 != null) {
                    return mediaFileMetadata2;
                }
                MediaFileMetadata mediaFileMetadataAccess$loadMediaFileMetadata = MediaFileMetadataManager.access$loadMediaFileMetadata(mediaFileMetadataManager, file);
                if (mediaFileMetadataAccess$loadMediaFileMetadata != null) {
                    Map mapAccess$getMediaFileMetadataMap$p = MediaFileMetadataManager.access$getMediaFileMetadataMap$p(mediaFileMetadataManager);
                    String name = file.getName();
                    Intrinsics.checkNotNullExpressionValue(name, "mediaFile.name");
                    mapAccess$getMediaFileMetadataMap$p.put(name, mediaFileMetadataAccess$loadMediaFileMetadata);
                    return mediaFileMetadataAccess$loadMediaFileMetadata;
                }
                try {
                    long length = file.length();
                    Duration.Companion companion = Duration.Companion;
                    DurationUnit durationUnit = DurationUnit.MILLISECONDS;
                    obj2 = objAccess$getMediaFileMetadataMapLock$p;
                    try {
                        mediaFileMetadata = new MediaFileMetadata(file, "", length, 0L, DurationKt.toDuration(0, durationUnit), DurationKt.toDuration(0, durationUnit), new Date(file.lastModified()), new Date(file.lastModified()), (DefaultConstructorMarker) null);
                    } catch (Throwable unused) {
                        mediaFileMetadata = null;
                    }
                } catch (Throwable unused2) {
                    obj2 = objAccess$getMediaFileMetadataMapLock$p;
                }
                if (mediaFileMetadata != null) {
                    try {
                        mediaFileMetadataManager.saveMediaFileMetadata(mediaFileMetadata);
                    } catch (Throwable th) {
                        th = th;
                    }
                } else {
                    mediaFileMetadata = null;
                }
                return mediaFileMetadata;
            } catch (Throwable th2) {
                th = th2;
                obj2 = objAccess$getMediaFileMetadataMapLock$p;
            }
            throw th;
        }
    }
}
