package io.bidmachine.util.cache;

import java.io.File;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Lambda;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: MediaFileCacheManager.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0010\u000e\n\u0000\u0010\u0000\u001a\u00020\u0001H\n¢\u0006\u0002\b\u0002"}, d2 = {"<anonymous>", "", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
final class MediaFileCacheManager$unholdMediaFile$1 extends Lambda implements Function0<String> {
    final /* synthetic */ Object $holder;
    final /* synthetic */ File $mediaFile;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    MediaFileCacheManager$unholdMediaFile$1(File file, Object obj) {
        super(0);
        this.$mediaFile = file;
        this.$holder = obj;
    }

    @NotNull
    public final String invoke() {
        return "Unhold media file " + this.$mediaFile.getName() + ", holder: " + this.$holder;
    }
}
