package io.bidmachine.util.cache;

import java.io.File;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: MediaFileCacheManager.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0000\u001a\u0010\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u00012\u0006\u0010\u0004\u001a\u00020\u0002H\n¢\u0006\u0002\b\u0005"}, d2 = {"<anonymous>", "Lkotlin/Pair;", "", "Ljava/io/File;", "mediaUrl", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
final class MediaFileCacheManager$getMediaFileInternal$2$cachedMediaFile$1 extends Lambda implements Function1<String, Pair<? extends String, ? extends File>> {
    final /* synthetic */ MediaFileCacheManager this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    MediaFileCacheManager$getMediaFileInternal$2$cachedMediaFile$1(MediaFileCacheManager mediaFileCacheManager) {
        super(1);
        this.this$0 = mediaFileCacheManager;
    }

    @Nullable
    public final Pair<String, File> invoke(@NotNull String str) {
        Intrinsics.checkNotNullParameter(str, "mediaUrl");
        File resourceCacheFile$bidmachine_android_sdk_ca_3_5_1 = this.this$0.getResourceCacheFile$bidmachine_android_sdk_ca_3_5_1(str);
        if (resourceCacheFile$bidmachine_android_sdk_ca_3_5_1 != null) {
            return new Pair<>(str, resourceCacheFile$bidmachine_android_sdk_ca_3_5_1);
        }
        return null;
    }
}
