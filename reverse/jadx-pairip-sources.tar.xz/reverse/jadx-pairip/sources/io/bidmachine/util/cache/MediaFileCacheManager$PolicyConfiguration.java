package io.bidmachine.util.cache;

import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: MediaFileCacheManager.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u001b\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\u0002\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\f"}, d2 = {"Lio/bidmachine/util/cache/MediaFileCacheManager$PolicyConfiguration;", "", "downloadPolicy", "Lio/bidmachine/util/cache/MediaFileCacheManager$DownloadPolicy;", "evictionPolicyList", "", "Lio/bidmachine/util/cache/MediaFileCacheManager$EvictionPolicy;", "(Lio/bidmachine/util/cache/MediaFileCacheManager$DownloadPolicy;Ljava/util/List;)V", "getDownloadPolicy", "()Lio/bidmachine/util/cache/MediaFileCacheManager$DownloadPolicy;", "getEvictionPolicyList", "()Ljava/util/List;", "bidmachine-android-sdk_ca_3_5_1"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class MediaFileCacheManager$PolicyConfiguration {

    @NotNull
    private final MediaFileCacheManager.DownloadPolicy downloadPolicy;

    @NotNull
    private final List<MediaFileCacheManager.EvictionPolicy> evictionPolicyList;

    public MediaFileCacheManager$PolicyConfiguration(@NotNull MediaFileCacheManager.DownloadPolicy downloadPolicy, @NotNull List<MediaFileCacheManager.EvictionPolicy> list) {
        Intrinsics.checkNotNullParameter(downloadPolicy, "downloadPolicy");
        Intrinsics.checkNotNullParameter(list, "evictionPolicyList");
        this.downloadPolicy = downloadPolicy;
        this.evictionPolicyList = list;
    }

    @NotNull
    public final MediaFileCacheManager.DownloadPolicy getDownloadPolicy() {
        return this.downloadPolicy;
    }

    @NotNull
    public final List<MediaFileCacheManager.EvictionPolicy> getEvictionPolicyList() {
        return this.evictionPolicyList;
    }
}
