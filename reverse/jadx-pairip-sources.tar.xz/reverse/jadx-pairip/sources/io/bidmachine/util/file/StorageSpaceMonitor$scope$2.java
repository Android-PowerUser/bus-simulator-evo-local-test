package io.bidmachine.util.file;

import io.bidmachine.util.SdkDispatchers;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Lambda;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.SupervisorKt;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: StorageSpaceMonitor.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u0001H\n¢\u0006\u0002\b\u0002"}, d2 = {"<anonymous>", "Lkotlinx/coroutines/CoroutineScope;", "invoke"}, k = 3, mv = {1, 7, 1}, xi = 48)
final class StorageSpaceMonitor$scope$2 extends Lambda implements Function0<CoroutineScope> {
    final /* synthetic */ SdkDispatchers $sdkDispatchers;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    StorageSpaceMonitor$scope$2(SdkDispatchers sdkDispatchers) {
        super(0);
        this.$sdkDispatchers = sdkDispatchers;
    }

    @NotNull
    public final CoroutineScope invoke() {
        return CoroutineScopeKt.CoroutineScope(SupervisorKt.SupervisorJob$default((Job) null, 1, (Object) null).plus(this.$sdkDispatchers.getIo()));
    }
}
