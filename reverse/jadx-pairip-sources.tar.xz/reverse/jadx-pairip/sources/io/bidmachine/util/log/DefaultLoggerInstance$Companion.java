package io.bidmachine.util.log;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* JADX INFO: compiled from: DefaultLoggerInstance.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0005"}, d2 = {"Lio/bidmachine/util/log/DefaultLoggerInstance$Companion;", "", "()V", "MAX_CHAR_PER_LINE_COUNT", "", "bidmachine-android-sdk_ca_3_5_1"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class DefaultLoggerInstance$Companion {
    public /* synthetic */ DefaultLoggerInstance$Companion(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }

    private DefaultLoggerInstance$Companion() {
    }
}
