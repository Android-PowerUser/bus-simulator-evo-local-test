package io.bidmachine.util.network;

import io.bidmachine.util.taskmanager.CancelableTask;
import kotlin.Metadata;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: compiled from: NetworkRequest.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0016¨\u0006\u0005"}, d2 = {"Lio/bidmachine/util/network/NetworkRequest$ProcessTask;", "Lio/bidmachine/util/taskmanager/CancelableTask;", "(Lio/bidmachine/util/network/NetworkRequest;)V", "runTask", "", "bidmachine-android-sdk_ca_3_5_1"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class NetworkRequest$ProcessTask extends CancelableTask {
    final /* synthetic */ NetworkRequest<ResponseType> this$0;

    public NetworkRequest$ProcessTask(NetworkRequest networkRequest) {
        this.this$0 = networkRequest;
    }

    @Override // io.bidmachine.util.taskmanager.CancelableTask
    public void runTask() {
        NetworkRequest.access$sendInternal(this.this$0);
    }
}
