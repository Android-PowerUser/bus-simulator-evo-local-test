package io.bidmachine.util.download;

import io.bidmachine.util.network.NetworkError;
import io.bidmachine.util.network.NetworkRequest;
import java.io.File;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: DownloadManagerImpl.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\u001e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0000\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u00012\u000e\u0010\u0003\u001a\n\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u00042\u0006\u0010\u0006\u001a\u00020\u0007H\n¢\u0006\u0004\b\b\u0010\t"}, d2 = {"<anonymous>", "Lkotlin/Result;", "Lio/bidmachine/util/download/DownloadManager$DownloadData;", "request", "Lio/bidmachine/util/network/NetworkRequest;", "Ljava/io/File;", "networkError", "Lio/bidmachine/util/network/NetworkError;", "invoke-gIAlu-s", "(Lio/bidmachine/util/network/NetworkRequest;Lio/bidmachine/util/network/NetworkError;)Ljava/lang/Object;"}, k = 3, mv = {1, 7, 1}, xi = 48)
final class DownloadManagerImpl$NetworkContentFetcher$get$2$listener$2 extends Lambda implements Function2<NetworkRequest<File>, NetworkError, Result<? extends DownloadManager.DownloadData>> {
    final /* synthetic */ String $url;
    final /* synthetic */ DownloadManagerImpl.NetworkContentFetcher this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    DownloadManagerImpl$NetworkContentFetcher$get$2$listener$2(DownloadManagerImpl.NetworkContentFetcher networkContentFetcher, String str) {
        super(2);
        this.this$0 = networkContentFetcher;
        this.$url = str;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
        return Result.box-impl(m1881invokegIAlus((NetworkRequest) obj, (NetworkError) obj2));
    }

    @NotNull
    /* JADX INFO: renamed from: invoke-gIAlu-s, reason: not valid java name */
    public final Object m1881invokegIAlus(@Nullable NetworkRequest<File> networkRequest, @NotNull NetworkError networkError) {
        Intrinsics.checkNotNullParameter(networkError, "networkError");
        DownloadManagerImpl.NetworkContentFetcher.access$getLogger$p(this.this$0).w("DownloadManager", (Function0<String>) new 1(networkError, this.$url));
        Result.Companion companion = Result.Companion;
        return Result.constructor-impl(ResultKt.createFailure(networkError.getThrowable()));
    }
}
