package io.bidmachine.util.network;

import android.net.Uri;
import androidx.annotation.WorkerThread;
import com.google.android.gms.common.internal.ImagesContract;
import com.safedk.android.internal.partials.BidMachineNetworkBridge;
import com.unity3d.services.UnityAdsConstants$RequestPolicy;
import io.bidmachine.util.Utils;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: NetworkUtils.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0010$\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J$\u0010\f\u001a\u00020\u00042\u0006\u0010\r\u001a\u00020\u00042\u0012\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00040\u000fH\u0007J\u0012\u0010\u0010\u001a\u00020\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u0013H\u0007J\u001a\u0010\u0014\u001a\u00020\u00042\u0006\u0010\u0015\u001a\u00020\u00042\b\b\u0002\u0010\u0016\u001a\u00020\bH\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\bX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0017"}, d2 = {"Lio/bidmachine/util/network/NetworkUtils;", "", "()V", "HEADER_CONTENT_LENGTH", "", "HEADER_CONTENT_TYPE", "HEADER_LOCATION", "HTTP_PERMANENT_REDIRECT", "", "HTTP_TEMPORARY_REDIRECT", "PROTOCOL_HTTP", "PROTOCOL_HTTPS", "appendQueryParameters", ImagesContract.URL, "queryParameters", "", "disconnectSafely", "", "httpURLConnection", "Ljava/net/HttpURLConnection;", "findEndpoint", "urlString", "timeOut", "bidmachine-android-sdk_ca_3_5_1"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class NetworkUtils {

    @NotNull
    public static final String HEADER_CONTENT_LENGTH = "Content-Length";

    @NotNull
    public static final String HEADER_CONTENT_TYPE = "Content-Type";

    @NotNull
    public static final String HEADER_LOCATION = "Location";
    public static final int HTTP_PERMANENT_REDIRECT = 308;
    public static final int HTTP_TEMPORARY_REDIRECT = 307;

    @NotNull
    public static final NetworkUtils INSTANCE = new NetworkUtils();

    @NotNull
    public static final String PROTOCOL_HTTP = "http";

    @NotNull
    public static final String PROTOCOL_HTTPS = "https";

    @JvmStatic
    @NotNull
    @JvmOverloads
    @WorkerThread
    public static final String findEndpoint(@NotNull String str) {
        Intrinsics.checkNotNullParameter(str, "urlString");
        return findEndpoint$default(str, 0, 2, null);
    }

    private NetworkUtils() {
    }

    @JvmStatic
    public static final void disconnectSafely(@Nullable HttpURLConnection httpURLConnection) {
        NetworkUtilsKt.disconnectSafely(httpURLConnection);
    }

    public static /* synthetic */ String findEndpoint$default(String str, int i, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            i = UnityAdsConstants$RequestPolicy.RETRY_WAIT_BASE;
        }
        return findEndpoint(str, i);
    }

    /* JADX WARN: Code duplicated, block: B:44:0x00bf  */
    /* JADX WARN: Code duplicated, block: B:45:0x00c0  */
    /* JADX WARN: Code duplicated, block: B:47:0x00c3 A[Catch: Exception -> 0x00d5, all -> 0x00ea, TRY_LEAVE, TryCatch #1 {Exception -> 0x00d5, blocks: (B:26:0x0076, B:31:0x0092, B:38:0x00a7, B:41:0x00ad, B:42:0x00b0, B:47:0x00c3), top: B:67:0x0076, outer: #0 }] */
    /* JADX WARN: Code duplicated, block: B:50:0x00ca A[Catch: all -> 0x00ea, TRY_ENTER, TRY_LEAVE, TryCatch #0 {all -> 0x00ea, blocks: (B:4:0x0023, B:7:0x002d, B:59:0x00e3, B:8:0x0033, B:10:0x003c, B:16:0x0048, B:19:0x0053, B:21:0x005d, B:24:0x006b, B:26:0x0076, B:31:0x0092, B:38:0x00a7, B:41:0x00ad, B:42:0x00b0, B:47:0x00c3, B:50:0x00ca, B:56:0x00dc, B:53:0x00d5), top: B:66:0x0023, inners: #1 }] */
    @JvmStatic
    @NotNull
    @JvmOverloads
    @WorkerThread
    public static final String findEndpoint(@NotNull String urlString, int timeOut) {
        Intrinsics.checkNotNullParameter(urlString, "urlString");
        HttpURLConnection httpURLConnection = null;
        try {
            URL url = new URL(urlString);
            URLConnection uRLConnectionOpenConnection = url.openConnection();
            Intrinsics.checkNotNull(uRLConnectionOpenConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
            HttpURLConnection httpURLConnection2 = (HttpURLConnection) uRLConnectionOpenConnection;
            httpURLConnection2.setInstanceFollowRedirects(false);
            httpURLConnection2.setConnectTimeout(timeOut);
            httpURLConnection2.setReadTimeout(timeOut);
            try {
                switch (BidMachineNetworkBridge.httpUrlConnectionGetResponseCode(httpURLConnection2)) {
                    case 301:
                    case 302:
                    case 303:
                    case 305:
                    case HTTP_TEMPORARY_REDIRECT /* 307 */:
                    case HTTP_PERMANENT_REDIRECT /* 308 */:
                        String headerField = httpURLConnection2.getHeaderField(HEADER_LOCATION);
                        boolean z = true;
                        if (headerField == null || headerField.length() == 0) {
                            String string = url.toString();
                            Intrinsics.checkNotNullExpressionValue(string, "url.toString()");
                            NetworkUtilsKt.disconnectSafely(httpURLConnection2);
                            return string;
                        }
                        Intrinsics.checkNotNullExpressionValue(headerField, "nextUrl");
                        if (Utils.isHttpUrl(headerField)) {
                            NetworkUtilsKt.disconnectSafely(httpURLConnection2);
                            Intrinsics.checkNotNullExpressionValue(headerField, "nextUrl");
                            String strFindEndpoint$default = findEndpoint$default(headerField, 0, 2, null);
                            NetworkUtilsKt.disconnectSafely(httpURLConnection2);
                            return strFindEndpoint$default;
                        }
                        if (new URI(headerField).getScheme() != null) {
                            Intrinsics.checkNotNullExpressionValue(headerField, "nextUrl");
                            NetworkUtilsKt.disconnectSafely(httpURLConnection2);
                            return headerField;
                        }
                        try {
                            String string2 = new URL(url, headerField).toString();
                            Intrinsics.checkNotNullExpressionValue(string2, "URL(url, nextUrl).toString()");
                            int length = string2.length() - 1;
                            int i = 0;
                            boolean z2 = false;
                            while (i <= length) {
                                boolean z3 = Intrinsics.compare(string2.charAt(!z2 ? i : length), 32) <= 0;
                                if (z2) {
                                    if (!z3) {
                                        if (string2.subSequence(i, length + 1).toString().length() == 0) {
                                            z = false;
                                        }
                                        if (z) {
                                            Intrinsics.checkNotNullExpressionValue(headerField, "nextUrl");
                                            NetworkUtilsKt.disconnectSafely(httpURLConnection2);
                                            return headerField;
                                        }
                                        NetworkUtilsKt.disconnectSafely(httpURLConnection2);
                                        String strFindEndpoint$default2 = findEndpoint$default(string2, 0, 2, null);
                                        NetworkUtilsKt.disconnectSafely(httpURLConnection2);
                                        return strFindEndpoint$default2;
                                    }
                                    length--;
                                } else if (z3) {
                                    i++;
                                } else {
                                    z2 = true;
                                }
                            }
                            if (string2.subSequence(i, length + 1).toString().length() == 0) {
                                z = false;
                            }
                            if (z) {
                                Intrinsics.checkNotNullExpressionValue(headerField, "nextUrl");
                                NetworkUtilsKt.disconnectSafely(httpURLConnection2);
                                return headerField;
                            }
                            NetworkUtilsKt.disconnectSafely(httpURLConnection2);
                            String strFindEndpoint$default3 = findEndpoint$default(string2, 0, 2, null);
                            NetworkUtilsKt.disconnectSafely(httpURLConnection2);
                            return strFindEndpoint$default3;
                        } catch (Exception unused) {
                            Intrinsics.checkNotNullExpressionValue(headerField, "nextUrl");
                            NetworkUtilsKt.disconnectSafely(httpURLConnection2);
                            return headerField;
                        }
                    case 304:
                    case 306:
                    default:
                        String string3 = url.toString();
                        Intrinsics.checkNotNullExpressionValue(string3, "url.toString()");
                        NetworkUtilsKt.disconnectSafely(httpURLConnection2);
                        return string3;
                }
            } catch (Throwable unused2) {
                httpURLConnection = httpURLConnection2;
            }
            httpURLConnection = httpURLConnection2;
        } catch (Throwable unused3) {
        }
        NetworkUtilsKt.disconnectSafely(httpURLConnection);
        return urlString;
    }

    @JvmStatic
    @NotNull
    public static final String appendQueryParameters(@NotNull String url, @NotNull Map<String, String> queryParameters) {
        Intrinsics.checkNotNullParameter(url, ImagesContract.URL);
        Intrinsics.checkNotNullParameter(queryParameters, "queryParameters");
        if (queryParameters.isEmpty()) {
            return url;
        }
        Uri.Builder builderBuildUpon = Uri.parse(url).buildUpon();
        for (Map.Entry<String, String> entry : queryParameters.entrySet()) {
            builderBuildUpon.appendQueryParameter(entry.getKey(), entry.getValue());
        }
        String string = builderBuildUpon.build().toString();
        Intrinsics.checkNotNullExpressionValue(string, "parse(url).buildUpon().a…     }.build().toString()");
        return string;
    }
}
