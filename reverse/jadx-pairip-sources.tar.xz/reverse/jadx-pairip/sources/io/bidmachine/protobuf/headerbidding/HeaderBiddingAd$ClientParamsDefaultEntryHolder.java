package io.bidmachine.protobuf.headerbidding;

import com.explorestack.protobuf.Descriptors;
import com.explorestack.protobuf.MapEntry;
import com.explorestack.protobuf.WireFormat;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class HeaderBiddingAd$ClientParamsDefaultEntryHolder {
    static final MapEntry<String, String> defaultEntry;

    private HeaderBiddingAd$ClientParamsDefaultEntryHolder() {
    }

    static {
        Descriptors.Descriptor descriptor = HeaderBiddingProto.internal_static_bidmachine_protobuf_headerbidding_HeaderBiddingAd_ClientParamsEntry_descriptor;
        WireFormat.FieldType fieldType = WireFormat.FieldType.STRING;
        defaultEntry = MapEntry.newDefaultInstance(descriptor, fieldType, "", fieldType, "");
    }
}
