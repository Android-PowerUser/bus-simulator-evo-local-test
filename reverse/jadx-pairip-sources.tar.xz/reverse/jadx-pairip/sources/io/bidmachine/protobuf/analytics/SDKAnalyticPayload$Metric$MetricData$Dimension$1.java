package io.bidmachine.protobuf.analytics;

import com.explorestack.protobuf.AbstractParser;
import com.explorestack.protobuf.CodedInputStream;
import com.explorestack.protobuf.ExtensionRegistryLite;
import com.explorestack.protobuf.InvalidProtocolBufferException;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class SDKAnalyticPayload$Metric$MetricData$Dimension$1 extends AbstractParser<SDKAnalyticPayload.Metric.MetricData.Dimension> {
    SDKAnalyticPayload$Metric$MetricData$Dimension$1() {
    }

    /* JADX INFO: renamed from: parsePartialFrom, reason: merged with bridge method [inline-methods] */
    public SDKAnalyticPayload.Metric.MetricData.Dimension m1349parsePartialFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return new SDKAnalyticPayload.Metric.MetricData.Dimension(codedInputStream, extensionRegistryLite, (SDKAnalyticPayload$1) null);
    }
}
