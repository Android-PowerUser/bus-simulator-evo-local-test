package io.bidmachine.protobuf.analytics;

import com.explorestack.protobuf.AbstractParser;
import com.explorestack.protobuf.CodedInputStream;
import com.explorestack.protobuf.ExtensionRegistryLite;
import com.explorestack.protobuf.InvalidProtocolBufferException;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class SDKAnalyticPayload$1 extends AbstractParser<SDKAnalyticPayload> {
    SDKAnalyticPayload$1() {
    }

    /* JADX INFO: renamed from: parsePartialFrom, reason: merged with bridge method [inline-methods] */
    public SDKAnalyticPayload m1348parsePartialFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return new SDKAnalyticPayload(codedInputStream, extensionRegistryLite, (SDKAnalyticPayload$1) null);
    }
}
