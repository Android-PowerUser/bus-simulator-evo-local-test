package io.bidmachine.protobuf.analytics;

import com.explorestack.protobuf.AbstractMessage;
import com.explorestack.protobuf.AbstractMessageLite;
import com.explorestack.protobuf.AbstractParser;
import com.explorestack.protobuf.ByteString;
import com.explorestack.protobuf.CodedInputStream;
import com.explorestack.protobuf.CodedOutputStream;
import com.explorestack.protobuf.Descriptors;
import com.explorestack.protobuf.ExtensionRegistryLite;
import com.explorestack.protobuf.GeneratedMessageV3;
import com.explorestack.protobuf.GeneratedMessageV3$BuilderParent;
import com.explorestack.protobuf.InvalidProtocolBufferException;
import com.explorestack.protobuf.Parser;
import com.explorestack.protobuf.UnknownFieldSet;
import com.explorestack.protobuf.adcom.Ad;
import com.explorestack.protobuf.adcom.AdOrBuilder;
import com.explorestack.protobuf.openrtb.Response;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class BidEvent extends GeneratedMessageV3 implements BidEventOrBuilder {
    public static final int AD_FIELD_NUMBER = 6;
    public static final int AUCTION_CONTEXT_FIELD_NUMBER = 4;
    public static final int BIDID_FIELD_NUMBER = 2;
    public static final int BID_FIELD_NUMBER = 5;
    private static final BidEvent DEFAULT_INSTANCE = new BidEvent();
    private static final Parser<BidEvent> PARSER = new AbstractParser<BidEvent>() { // from class: io.bidmachine.protobuf.analytics.BidEvent.1
        /* JADX INFO: renamed from: parsePartialFrom, reason: merged with bridge method [inline-methods] */
        public BidEvent m1347parsePartialFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return new BidEvent(codedInputStream, extensionRegistryLite);
        }
    };
    public static final int SEAT_FIELD_NUMBER = 3;
    public static final int TIMESTAMP_FIELD_NUMBER = 1;
    private static final long serialVersionUID = 0;
    private Ad ad_;
    private AuctionContext auctionContext_;
    private Response.Seatbid.Bid bid_;
    private volatile Object bidid_;
    private byte memoizedIsInitialized;
    private volatile Object seat_;
    private volatile Object timestamp_;

    private BidEvent(GeneratedMessageV3.Builder<?> builder) {
        super(builder);
        this.memoizedIsInitialized = (byte) -1;
    }

    private BidEvent() {
        this.memoizedIsInitialized = (byte) -1;
        this.timestamp_ = "";
        this.bidid_ = "";
        this.seat_ = "";
    }

    protected Object newInstance(GeneratedMessageV3.UnusedPrivateParameter unusedPrivateParameter) {
        return new BidEvent();
    }

    public final UnknownFieldSet getUnknownFields() {
        return ((GeneratedMessageV3) this).unknownFields;
    }

    private BidEvent(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        AuctionContext.Builder builder;
        this();
        extensionRegistryLite.getClass();
        UnknownFieldSet.Builder builderNewBuilder = UnknownFieldSet.newBuilder();
        boolean z = false;
        while (!z) {
            try {
                try {
                    try {
                        int tag = codedInputStream.readTag();
                        if (tag != 0) {
                            if (tag == 10) {
                                this.timestamp_ = codedInputStream.readStringRequireUtf8();
                            } else if (tag == 18) {
                                this.bidid_ = codedInputStream.readStringRequireUtf8();
                            } else if (tag != 26) {
                                if (tag == 34) {
                                    AuctionContext auctionContext = this.auctionContext_;
                                    builder = auctionContext != null ? auctionContext.toBuilder() : null;
                                    AuctionContext message = codedInputStream.readMessage(AuctionContext.parser(), extensionRegistryLite);
                                    this.auctionContext_ = message;
                                    if (builder != null) {
                                        builder.mergeFrom(message);
                                        this.auctionContext_ = builder.buildPartial();
                                    }
                                } else if (tag == 42) {
                                    Response.Seatbid.Bid bid = this.bid_;
                                    builder = bid != null ? bid.toBuilder() : null;
                                    Response.Seatbid.Bid bid2 = (Response.Seatbid.Bid) codedInputStream.readMessage(Response.Seatbid.Bid.parser(), extensionRegistryLite);
                                    this.bid_ = bid2;
                                    if (builder != null) {
                                        builder.mergeFrom(bid2);
                                        this.bid_ = builder.m721buildPartial();
                                    }
                                } else if (tag == 50) {
                                    Ad ad = this.ad_;
                                    builder = ad != null ? ad.toBuilder() : null;
                                    Ad message2 = codedInputStream.readMessage(Ad.parser(), extensionRegistryLite);
                                    this.ad_ = message2;
                                    if (builder != null) {
                                        builder.mergeFrom(message2);
                                        this.ad_ = builder.buildPartial();
                                    }
                                } else if (!parseUnknownField(codedInputStream, builderNewBuilder, extensionRegistryLite, tag)) {
                                }
                            } else {
                                this.seat_ = codedInputStream.readStringRequireUtf8();
                            }
                        }
                        z = true;
                    } catch (IOException e) {
                        throw new InvalidProtocolBufferException(e).setUnfinishedMessage(this);
                    }
                } catch (InvalidProtocolBufferException e2) {
                    throw e2.setUnfinishedMessage(this);
                }
            } catch (Throwable th) {
                ((GeneratedMessageV3) this).unknownFields = builderNewBuilder.build();
                makeExtensionsImmutable();
                throw th;
            }
        }
        ((GeneratedMessageV3) this).unknownFields = builderNewBuilder.build();
        makeExtensionsImmutable();
    }

    public static final Descriptors.Descriptor getDescriptor() {
        return AnalyticsProto.internal_static_bidmachine_protobuf_analytics_BidEvent_descriptor;
    }

    protected GeneratedMessageV3.FieldAccessorTable internalGetFieldAccessorTable() {
        return AnalyticsProto.internal_static_bidmachine_protobuf_analytics_BidEvent_fieldAccessorTable.ensureFieldAccessorsInitialized(BidEvent.class, Builder.class);
    }

    public String getTimestamp() {
        Object obj = this.timestamp_;
        if (obj instanceof String) {
            return (String) obj;
        }
        String stringUtf8 = ((ByteString) obj).toStringUtf8();
        this.timestamp_ = stringUtf8;
        return stringUtf8;
    }

    public ByteString getTimestampBytes() {
        Object obj = this.timestamp_;
        if (obj instanceof String) {
            ByteString byteStringCopyFromUtf8 = ByteString.copyFromUtf8((String) obj);
            this.timestamp_ = byteStringCopyFromUtf8;
            return byteStringCopyFromUtf8;
        }
        return (ByteString) obj;
    }

    public String getBidid() {
        Object obj = this.bidid_;
        if (obj instanceof String) {
            return (String) obj;
        }
        String stringUtf8 = ((ByteString) obj).toStringUtf8();
        this.bidid_ = stringUtf8;
        return stringUtf8;
    }

    public ByteString getBididBytes() {
        Object obj = this.bidid_;
        if (obj instanceof String) {
            ByteString byteStringCopyFromUtf8 = ByteString.copyFromUtf8((String) obj);
            this.bidid_ = byteStringCopyFromUtf8;
            return byteStringCopyFromUtf8;
        }
        return (ByteString) obj;
    }

    public String getSeat() {
        Object obj = this.seat_;
        if (obj instanceof String) {
            return (String) obj;
        }
        String stringUtf8 = ((ByteString) obj).toStringUtf8();
        this.seat_ = stringUtf8;
        return stringUtf8;
    }

    public ByteString getSeatBytes() {
        Object obj = this.seat_;
        if (obj instanceof String) {
            ByteString byteStringCopyFromUtf8 = ByteString.copyFromUtf8((String) obj);
            this.seat_ = byteStringCopyFromUtf8;
            return byteStringCopyFromUtf8;
        }
        return (ByteString) obj;
    }

    public boolean hasAuctionContext() {
        return this.auctionContext_ != null;
    }

    public AuctionContext getAuctionContext() {
        AuctionContext auctionContext = this.auctionContext_;
        return auctionContext == null ? AuctionContext.getDefaultInstance() : auctionContext;
    }

    public AuctionContextOrBuilder getAuctionContextOrBuilder() {
        return getAuctionContext();
    }

    public boolean hasBid() {
        return this.bid_ != null;
    }

    public Response.Seatbid.Bid getBid() {
        Response.Seatbid.Bid bid = this.bid_;
        return bid == null ? Response.Seatbid.Bid.getDefaultInstance() : bid;
    }

    public Response.Seatbid.BidOrBuilder getBidOrBuilder() {
        return getBid();
    }

    public boolean hasAd() {
        return this.ad_ != null;
    }

    public Ad getAd() {
        Ad ad = this.ad_;
        return ad == null ? Ad.getDefaultInstance() : ad;
    }

    public AdOrBuilder getAdOrBuilder() {
        return getAd();
    }

    public final boolean isInitialized() {
        byte b = this.memoizedIsInitialized;
        if (b == 1) {
            return true;
        }
        if (b == 0) {
            return false;
        }
        this.memoizedIsInitialized = (byte) 1;
        return true;
    }

    public void writeTo(CodedOutputStream codedOutputStream) throws IOException {
        if (!getTimestampBytes().isEmpty()) {
            GeneratedMessageV3.writeString(codedOutputStream, 1, this.timestamp_);
        }
        if (!getBididBytes().isEmpty()) {
            GeneratedMessageV3.writeString(codedOutputStream, 2, this.bidid_);
        }
        if (!getSeatBytes().isEmpty()) {
            GeneratedMessageV3.writeString(codedOutputStream, 3, this.seat_);
        }
        if (this.auctionContext_ != null) {
            codedOutputStream.writeMessage(4, getAuctionContext());
        }
        if (this.bid_ != null) {
            codedOutputStream.writeMessage(5, getBid());
        }
        if (this.ad_ != null) {
            codedOutputStream.writeMessage(6, getAd());
        }
        ((GeneratedMessageV3) this).unknownFields.writeTo(codedOutputStream);
    }

    public int getSerializedSize() {
        int i = ((AbstractMessage) this).memoizedSize;
        if (i != -1) {
            return i;
        }
        int iComputeStringSize = getTimestampBytes().isEmpty() ? 0 : 0 + GeneratedMessageV3.computeStringSize(1, this.timestamp_);
        if (!getBididBytes().isEmpty()) {
            iComputeStringSize += GeneratedMessageV3.computeStringSize(2, this.bidid_);
        }
        if (!getSeatBytes().isEmpty()) {
            iComputeStringSize += GeneratedMessageV3.computeStringSize(3, this.seat_);
        }
        if (this.auctionContext_ != null) {
            iComputeStringSize += CodedOutputStream.computeMessageSize(4, getAuctionContext());
        }
        if (this.bid_ != null) {
            iComputeStringSize += CodedOutputStream.computeMessageSize(5, getBid());
        }
        if (this.ad_ != null) {
            iComputeStringSize += CodedOutputStream.computeMessageSize(6, getAd());
        }
        int serializedSize = iComputeStringSize + ((GeneratedMessageV3) this).unknownFields.getSerializedSize();
        ((AbstractMessage) this).memoizedSize = serializedSize;
        return serializedSize;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof BidEvent)) {
            return super/*com.explorestack.protobuf.AbstractMessage*/.equals(obj);
        }
        BidEvent bidEvent = (BidEvent) obj;
        if (!getTimestamp().equals(bidEvent.getTimestamp()) || !getBidid().equals(bidEvent.getBidid()) || !getSeat().equals(bidEvent.getSeat()) || hasAuctionContext() != bidEvent.hasAuctionContext()) {
            return false;
        }
        if ((hasAuctionContext() && !getAuctionContext().equals(bidEvent.getAuctionContext())) || hasBid() != bidEvent.hasBid()) {
            return false;
        }
        if ((!hasBid() || getBid().equals(bidEvent.getBid())) && hasAd() == bidEvent.hasAd()) {
            return (!hasAd() || getAd().equals(bidEvent.getAd())) && ((GeneratedMessageV3) this).unknownFields.equals(((GeneratedMessageV3) bidEvent).unknownFields);
        }
        return false;
    }

    public int hashCode() {
        int i = ((AbstractMessageLite) this).memoizedHashCode;
        if (i != 0) {
            return i;
        }
        int iHashCode = ((((((((((((779 + getDescriptor().hashCode()) * 37) + 1) * 53) + getTimestamp().hashCode()) * 37) + 2) * 53) + getBidid().hashCode()) * 37) + 3) * 53) + getSeat().hashCode();
        if (hasAuctionContext()) {
            iHashCode = (((iHashCode * 37) + 4) * 53) + getAuctionContext().hashCode();
        }
        if (hasBid()) {
            iHashCode = (((iHashCode * 37) + 5) * 53) + getBid().hashCode();
        }
        if (hasAd()) {
            iHashCode = (((iHashCode * 37) + 6) * 53) + getAd().hashCode();
        }
        int iHashCode2 = (iHashCode * 29) + ((GeneratedMessageV3) this).unknownFields.hashCode();
        ((AbstractMessageLite) this).memoizedHashCode = iHashCode2;
        return iHashCode2;
    }

    public static BidEvent parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
        return (BidEvent) PARSER.parseFrom(byteBuffer);
    }

    public static BidEvent parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (BidEvent) PARSER.parseFrom(byteBuffer, extensionRegistryLite);
    }

    public static BidEvent parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (BidEvent) PARSER.parseFrom(byteString);
    }

    public static BidEvent parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (BidEvent) PARSER.parseFrom(byteString, extensionRegistryLite);
    }

    public static BidEvent parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
        return (BidEvent) PARSER.parseFrom(bArr);
    }

    public static BidEvent parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (BidEvent) PARSER.parseFrom(bArr, extensionRegistryLite);
    }

    public static BidEvent parseFrom(InputStream inputStream) throws IOException {
        return GeneratedMessageV3.parseWithIOException(PARSER, inputStream);
    }

    public static BidEvent parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return GeneratedMessageV3.parseWithIOException(PARSER, inputStream, extensionRegistryLite);
    }

    public static BidEvent parseDelimitedFrom(InputStream inputStream) throws IOException {
        return GeneratedMessageV3.parseDelimitedWithIOException(PARSER, inputStream);
    }

    public static BidEvent parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return GeneratedMessageV3.parseDelimitedWithIOException(PARSER, inputStream, extensionRegistryLite);
    }

    public static BidEvent parseFrom(CodedInputStream codedInputStream) throws IOException {
        return GeneratedMessageV3.parseWithIOException(PARSER, codedInputStream);
    }

    public static BidEvent parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return GeneratedMessageV3.parseWithIOException(PARSER, codedInputStream, extensionRegistryLite);
    }

    /* JADX INFO: renamed from: newBuilderForType, reason: collision with other method in class and merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
    public Builder m1342newBuilderForType() {
        return newBuilder();
    }

    public static Builder newBuilder() {
        return DEFAULT_INSTANCE.m1345toBuilder();
    }

    public static Builder newBuilder(BidEvent bidEvent) {
        return DEFAULT_INSTANCE.m1345toBuilder().mergeFrom(bidEvent);
    }

    /* JADX INFO: renamed from: toBuilder, reason: collision with other method in class and merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
    public Builder m1345toBuilder() {
        return this == DEFAULT_INSTANCE ? new Builder((AnonymousClass1) null) : new Builder((AnonymousClass1) null).mergeFrom(this);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public Builder newBuilderForType(GeneratedMessageV3$BuilderParent generatedMessageV3$BuilderParent) {
        return new Builder(generatedMessageV3$BuilderParent, (AnonymousClass1) null);
    }

    public static BidEvent getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Parser<BidEvent> parser() {
        return PARSER;
    }

    public Parser<BidEvent> getParserForType() {
        return PARSER;
    }

    /* JADX INFO: renamed from: getDefaultInstanceForType, reason: collision with other method in class and merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
    public BidEvent m1340getDefaultInstanceForType() {
        return DEFAULT_INSTANCE;
    }
}
