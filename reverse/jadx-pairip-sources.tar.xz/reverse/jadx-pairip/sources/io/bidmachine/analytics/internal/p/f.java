package io.bidmachine.analytics.internal.p;

import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.List;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.collections.CollectionsKt;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class f {
    private Object a;
    private final String b;
    private final String c;
    private final String d;
    private final String e;

    public f() {
        Result.Companion companion = Result.Companion;
        this.a = Result.constructor-impl(ResultKt.createFailure(new NullPointerException()));
        this.b = "amF2YS5sYW5nLlByb2Nlc3NCdWlsZGVy";
        this.c = "c3RhcnQ=";
        this.d = "Z2V0SW5wdXRTdHJlYW0=";
        this.e = "ZGVzdHJveQ==";
    }

    public final InputStream a(List list) {
        Object objCreateFailure;
        Object obj;
        Method method;
        try {
            Result.Companion companion = Result.Companion;
            Class<?> cls = Class.forName(io.bidmachine.analytics.internal.a.e.a(this.b));
            objCreateFailure = Result.constructor-impl(cls.getMethod(io.bidmachine.analytics.internal.a.e.a(this.c), null).invoke(cls.getConstructor(List.class).newInstance(CollectionsKt.toList(list)), null));
        } catch (Throwable th) {
            Result.Companion companion2 = Result.Companion;
            objCreateFailure = Result.constructor-impl(ResultKt.createFailure(th));
        }
        this.a = objCreateFailure;
        if (Result.isSuccess-impl(objCreateFailure)) {
            try {
                Result.Companion companion3 = Result.Companion;
                obj = Result.constructor-impl((InputStream) ((objCreateFailure == null || (method = objCreateFailure.getClass().getMethod(io.bidmachine.analytics.internal.a.e.a(this.d), null)) == null) ? null : method.invoke(objCreateFailure, null)));
            } catch (Throwable th2) {
                Result.Companion companion4 = Result.Companion;
                objCreateFailure = ResultKt.createFailure(th2);
                obj = Result.constructor-impl(objCreateFailure);
            }
        } else {
            obj = Result.constructor-impl(objCreateFailure);
        }
        return (InputStream) (Result.isFailure-impl(obj) ? null : obj);
    }

    public final void a() {
        Method method;
        Object objCreateFailure = this.a;
        if (Result.isSuccess-impl(objCreateFailure)) {
            try {
                Result.Companion companion = Result.Companion;
                Object objInvoke = null;
                if (objCreateFailure != null && (method = objCreateFailure.getClass().getMethod(io.bidmachine.analytics.internal.a.e.a(this.e), null)) != null) {
                    objInvoke = method.invoke(objCreateFailure, null);
                }
                Result.constructor-impl(objInvoke);
                return;
            } catch (Throwable th) {
                Result.Companion companion2 = Result.Companion;
                objCreateFailure = ResultKt.createFailure(th);
            }
        }
        Result.constructor-impl(objCreateFailure);
    }
}
