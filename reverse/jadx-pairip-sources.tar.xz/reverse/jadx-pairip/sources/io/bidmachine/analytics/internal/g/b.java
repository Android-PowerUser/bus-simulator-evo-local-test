package io.bidmachine.analytics.internal.g;

import java.util.Map;
import java.util.UUID;
import kotlin.collections.MapsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class b {
    public static final a g = new a((DefaultConstructorMarker) null);
    private final String a;
    private final String b;
    private final String c;
    private final long d;
    private final Map e;
    private final e f;

    public b(String str, String str2, String str3, long j, Map map, e eVar) {
        this.a = str;
        this.b = str2;
        this.c = str3;
        this.d = j;
        this.e = map;
        this.f = eVar;
    }

    public final b a(String str, String str2, String str3, long j, Map map, e eVar) {
        return new b(str, str2, str3, j, map, eVar);
    }

    public final e b() {
        return this.f;
    }

    public final String c() {
        return this.a;
    }

    public final String d() {
        return this.b;
    }

    public final String e() {
        return this.c;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return Intrinsics.areEqual(this.a, bVar.a) && Intrinsics.areEqual(this.b, bVar.b) && Intrinsics.areEqual(this.c, bVar.c) && this.d == bVar.d && Intrinsics.areEqual(this.e, bVar.e) && Intrinsics.areEqual(this.f, bVar.f);
    }

    public final long f() {
        return this.d;
    }

    public int hashCode() {
        int iHashCode = ((((((((this.a.hashCode() * 31) + this.b.hashCode()) * 31) + this.c.hashCode()) * 31) + Long.hashCode(this.d)) * 31) + this.e.hashCode()) * 31;
        e eVar = this.f;
        return iHashCode + (eVar == null ? 0 : eVar.hashCode());
    }

    public String toString() {
        return "MonitorRecord(id=" + this.a + ", name=" + this.b + ", sessionId=" + this.c + ", timestamp=" + this.d + ", data=" + this.e + ", error=" + this.f + ')';
    }

    public static /* synthetic */ b a(b bVar, String str, String str2, String str3, long j, Map map, e eVar, int i, Object obj) {
        if ((i & 1) != 0) {
            str = bVar.a;
        }
        if ((i & 2) != 0) {
            str2 = bVar.b;
        }
        String str4 = str2;
        if ((i & 4) != 0) {
            str3 = bVar.c;
        }
        String str5 = str3;
        if ((i & 8) != 0) {
            j = bVar.d;
        }
        long j2 = j;
        if ((i & 16) != 0) {
            map = bVar.e;
        }
        Map map2 = map;
        if ((i & 32) != 0) {
            eVar = bVar.f;
        }
        return bVar.a(str, str4, str5, j2, map2, eVar);
    }

    public final Map a() {
        return this.e;
    }

    public /* synthetic */ b(String str, String str2, String str3, long j, Map map, e eVar, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? UUID.randomUUID().toString() : str, str2, str3, (i & 8) != 0 ? System.currentTimeMillis() : j, (i & 16) != 0 ? MapsKt.emptyMap() : map, (i & 32) != 0 ? null : eVar);
    }
}
