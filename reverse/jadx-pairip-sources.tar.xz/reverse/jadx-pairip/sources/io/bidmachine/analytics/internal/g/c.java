package io.bidmachine.analytics.internal.g;

import java.util.UUID;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class c {
    private final String a;
    private final String b;
    private final long c;
    private final String d;
    private final a e;
    private final e f;
    private final boolean g;

    public interface a {

        /* JADX INFO: renamed from: io.bidmachine.analytics.internal.g.c$a$a, reason: collision with other inner class name */
        public static final class C0004a implements a {
            private final String a;
            private final String b;

            public C0004a(String str, String str2) {
                this.a = str;
                this.b = str2;
            }

            public final String a() {
                return this.b;
            }

            public final String b() {
                return this.a;
            }

            public boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                if (!(obj instanceof C0004a)) {
                    return false;
                }
                C0004a c0004a = (C0004a) obj;
                return Intrinsics.areEqual(this.a, c0004a.a) && Intrinsics.areEqual(this.b, c0004a.b);
            }

            public int hashCode() {
                return (this.a.hashCode() * 31) + this.b.hashCode();
            }

            public String toString() {
                return super.toString();
            }
        }

        public static final class b implements a {
            private final String a;
            private final String b;
            private final String c;
            private final boolean d;

            public b(String str, String str2, String str3, boolean z) {
                this.a = str;
                this.b = str2;
                this.c = str3;
                this.d = z;
            }

            public final String a() {
                return this.b;
            }

            public final String b() {
                return this.c;
            }

            public final boolean c() {
                return this.d;
            }

            public final String d() {
                return this.a;
            }

            public boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                if (!(obj instanceof b)) {
                    return false;
                }
                b bVar = (b) obj;
                return Intrinsics.areEqual(this.a, bVar.a) && Intrinsics.areEqual(this.b, bVar.b) && Intrinsics.areEqual(this.c, bVar.c) && this.d == bVar.d;
            }

            /* JADX WARN: Multi-variable type inference failed */
            /* JADX WARN: Type inference failed for: r0v7, types: [int] */
            /* JADX WARN: Type inference failed for: r1v6, types: [int] */
            /* JADX WARN: Type inference failed for: r1v7 */
            /* JADX WARN: Type inference failed for: r1v9 */
            public int hashCode() {
                int iHashCode = ((this.a.hashCode() * 31) + this.b.hashCode()) * 31;
                String str = this.c;
                int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
                boolean z = this.d;
                ?? r1 = z;
                if (z) {
                    r1 = 1;
                }
                return iHashCode2 + r1;
            }

            public String toString() {
                return super.toString();
            }
        }
    }

    public c(String str, String str2, long j, String str3, a aVar, e eVar, boolean z) {
        this.a = str;
        this.b = str2;
        this.c = j;
        this.d = str3;
        this.e = aVar;
        this.f = eVar;
        this.g = z;
    }

    public final c a(String str, String str2, long j, String str3, a aVar, e eVar, boolean z) {
        return new c(str, str2, j, str3, aVar, eVar, z);
    }

    public final e b() {
        return this.f;
    }

    public final String c() {
        return this.a;
    }

    public final String d() {
        return this.b;
    }

    public final a e() {
        return this.e;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return Intrinsics.areEqual(this.a, cVar.a) && Intrinsics.areEqual(this.b, cVar.b) && this.c == cVar.c && Intrinsics.areEqual(this.d, cVar.d) && Intrinsics.areEqual(this.e, cVar.e) && Intrinsics.areEqual(this.f, cVar.f) && this.g == cVar.g;
    }

    public final long f() {
        return this.c;
    }

    public final boolean g() {
        return this.g;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [int] */
    /* JADX WARN: Type inference failed for: r1v12, types: [int] */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v15 */
    public int hashCode() {
        int iHashCode = ((((((((this.a.hashCode() * 31) + this.b.hashCode()) * 31) + Long.hashCode(this.c)) * 31) + this.d.hashCode()) * 31) + this.e.hashCode()) * 31;
        e eVar = this.f;
        int iHashCode2 = (iHashCode + (eVar == null ? 0 : eVar.hashCode())) * 31;
        boolean z = this.g;
        ?? r1 = z;
        if (z) {
            r1 = 1;
        }
        return iHashCode2 + r1;
    }

    public String toString() {
        return "ReaderRecord(id=" + this.a + ", name=" + this.b + ", timestamp=" + this.c + ", dataHash=" + this.d + ", rule=" + this.e + ", error=" + this.f + ", isDirty=" + this.g + ')';
    }

    public final String a() {
        return this.d;
    }

    public /* synthetic */ c(String str, String str2, long j, String str3, a aVar, e eVar, boolean z, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? UUID.randomUUID().toString() : str, str2, (i & 4) != 0 ? System.currentTimeMillis() : j, str3, aVar, (i & 32) != 0 ? null : eVar, (i & 64) != 0 ? true : z);
    }
}
