package io.bidmachine.analytics.internal.D;

import java.util.List;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface a {
    Object a(io.bidmachine.analytics.internal.g.b bVar);

    Object a(String str, String str2);

    Object a(String str, String str2, int i);

    Object a(String str, List list);

    Object a(List list);

    Object b(List list);

    Object c(List list);
}
