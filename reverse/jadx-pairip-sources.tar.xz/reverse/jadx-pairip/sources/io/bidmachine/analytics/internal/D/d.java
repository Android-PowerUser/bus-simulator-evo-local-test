package io.bidmachine.analytics.internal.D;

import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class d implements c {
    private final SQLiteOpenHelper a;
    private final Lazy b = LazyKt.lazy(new a(this));

    public d(SQLiteOpenHelper sQLiteOpenHelper) {
        this.a = sQLiteOpenHelper;
    }

    @Override // io.bidmachine.analytics.internal.D.c
    public Object b(io.bidmachine.analytics.internal.g.c cVar) {
        return a().c(io.bidmachine.analytics.internal.C.d.a(cVar));
    }

    @Override // io.bidmachine.analytics.internal.D.c
    public Object c(List list) {
        io.bidmachine.analytics.internal.B.b bVarA = a();
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(io.bidmachine.analytics.internal.C.d.a((io.bidmachine.analytics.internal.g.c) it.next()));
        }
        return bVarA.d(arrayList);
    }

    private final io.bidmachine.analytics.internal.B.b a() {
        return (io.bidmachine.analytics.internal.B.b) this.b.getValue();
    }

    @Override // io.bidmachine.analytics.internal.D.c
    public Object b(List list) {
        io.bidmachine.analytics.internal.B.b bVarA = a();
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(io.bidmachine.analytics.internal.C.d.a((io.bidmachine.analytics.internal.g.c) it.next()));
        }
        return bVarA.a(arrayList);
    }

    @Override // io.bidmachine.analytics.internal.D.c
    public Object a(io.bidmachine.analytics.internal.g.c cVar) {
        return a().a(io.bidmachine.analytics.internal.C.d.a(cVar));
    }

    @Override // io.bidmachine.analytics.internal.D.c
    public Object a(String str, io.bidmachine.analytics.internal.g.c.a aVar) {
        Object objA = a().a(str, io.bidmachine.analytics.internal.C.d.a(aVar).toString());
        try {
            Result.Companion companion = Result.Companion;
            ResultKt.throwOnFailure(objA);
            io.bidmachine.analytics.internal.C.c cVar = (io.bidmachine.analytics.internal.C.c) objA;
            return Result.constructor-impl(cVar != null ? io.bidmachine.analytics.internal.C.d.a(cVar) : null);
        } catch (Throwable th) {
            Result.Companion companion2 = Result.Companion;
            return Result.constructor-impl(ResultKt.createFailure(th));
        }
    }

    @Override // io.bidmachine.analytics.internal.D.c
    public Object a(String str) {
        return a(a().a(str));
    }

    @Override // io.bidmachine.analytics.internal.D.c
    public Object a(List list) {
        io.bidmachine.analytics.internal.B.b bVarA = a();
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(io.bidmachine.analytics.internal.C.d.a((io.bidmachine.analytics.internal.g.c) it.next()));
        }
        return bVarA.e(arrayList);
    }

    public final Object b() {
        return a().b();
    }

    @Override // io.bidmachine.analytics.internal.D.c
    public Object a(String str, List list) {
        io.bidmachine.analytics.internal.B.b bVarA = a();
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(io.bidmachine.analytics.internal.C.d.a((io.bidmachine.analytics.internal.g.c.a) it.next()).toString());
        }
        return bVarA.a(str, arrayList);
    }

    @Override // io.bidmachine.analytics.internal.D.c
    public Object a(List list, List list2) {
        a().b(list);
        io.bidmachine.analytics.internal.B.b bVarA = a();
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list2, 10));
        Iterator it = list2.iterator();
        while (it.hasNext()) {
            arrayList.add(io.bidmachine.analytics.internal.C.d.a((io.bidmachine.analytics.internal.g.c.a) it.next()).toString());
        }
        bVarA.c(arrayList);
        Result.Companion companion = Result.Companion;
        return Result.constructor-impl(Unit.INSTANCE);
    }

    private final Object a(Object obj) {
        try {
            Result.Companion companion = Result.Companion;
            ResultKt.throwOnFailure(obj);
            Iterable iterable = (Iterable) obj;
            ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
            Iterator it = iterable.iterator();
            while (it.hasNext()) {
                arrayList.add(io.bidmachine.analytics.internal.C.d.a((io.bidmachine.analytics.internal.C.c) it.next()));
            }
            return Result.constructor-impl(arrayList);
        } catch (Throwable th) {
            Result.Companion companion2 = Result.Companion;
            return Result.constructor-impl(ResultKt.createFailure(th));
        }
    }
}
