package io.bidmachine.analytics.internal.q;

import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class a$a {
    private final List a;
    private final List b;
    private final List c;

    public a$a(List list, List list2, List list3) {
        this.a = list;
        this.b = list2;
        this.c = list3;
    }

    public final a$a a(List list, List list2, List list3) {
        return new a$a(list, list2, list3);
    }

    public final List b() {
        return this.c;
    }

    public final List c() {
        return this.b;
    }

    public final boolean d() {
        return this.a.isEmpty() && this.b.isEmpty() && this.c.isEmpty();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a$a)) {
            return false;
        }
        a$a a_a = (a$a) obj;
        return Intrinsics.areEqual(this.a, a_a.a) && Intrinsics.areEqual(this.b, a_a.b) && Intrinsics.areEqual(this.c, a_a.c);
    }

    public int hashCode() {
        return (((this.a.hashCode() * 31) + this.b.hashCode()) * 31) + this.c.hashCode();
    }

    public String toString() {
        return super.toString();
    }

    public static /* synthetic */ a$a a(a$a a_a, List list, List list2, List list3, int i, Object obj) {
        if ((i & 1) != 0) {
            list = a_a.a;
        }
        if ((i & 2) != 0) {
            list2 = a_a.b;
        }
        if ((i & 4) != 0) {
            list3 = a_a.c;
        }
        return a_a.a(list, list2, list3);
    }

    public final List a() {
        return this.a;
    }

    public /* synthetic */ a$a(List list, List list2, List list3, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? CollectionsKt.emptyList() : list, (i & 2) != 0 ? CollectionsKt.emptyList() : list2, (i & 4) != 0 ? CollectionsKt.emptyList() : list3);
    }
}
