package io.bidmachine.analytics.internal.D;

import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.collections.CollectionsKt;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class b implements a {
    private final SQLiteOpenHelper a;
    private final Lazy b = LazyKt.lazy(new a(this));

    public b(SQLiteOpenHelper sQLiteOpenHelper) {
        this.a = sQLiteOpenHelper;
    }

    @Override // io.bidmachine.analytics.internal.D.a
    public Object b(List list) {
        io.bidmachine.analytics.internal.B.a aVarA = a();
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(io.bidmachine.analytics.internal.C.b.a((io.bidmachine.analytics.internal.g.b) it.next()));
        }
        return aVarA.a(arrayList);
    }

    @Override // io.bidmachine.analytics.internal.D.a
    public Object c(List list) {
        io.bidmachine.analytics.internal.B.a aVarA = a();
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(io.bidmachine.analytics.internal.C.b.a((io.bidmachine.analytics.internal.g.b) it.next()));
        }
        return aVarA.b(arrayList);
    }

    private final io.bidmachine.analytics.internal.B.a a() {
        return (io.bidmachine.analytics.internal.B.a) this.b.getValue();
    }

    @Override // io.bidmachine.analytics.internal.D.a
    public Object a(io.bidmachine.analytics.internal.g.b bVar) {
        return a().a(io.bidmachine.analytics.internal.C.b.a(bVar));
    }

    @Override // io.bidmachine.analytics.internal.D.a
    public Object a(String str, String str2) {
        return a(a().a(str, str2));
    }

    @Override // io.bidmachine.analytics.internal.D.a
    public Object a(String str, String str2, int i) {
        return a(a().a(str, str2, Integer.valueOf(i)));
    }

    @Override // io.bidmachine.analytics.internal.D.a
    public Object a(List list) {
        io.bidmachine.analytics.internal.B.a aVarA = a();
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(io.bidmachine.analytics.internal.C.b.a((io.bidmachine.analytics.internal.g.b) it.next()));
        }
        return aVarA.c(arrayList);
    }

    public final Object b() {
        return a().a();
    }

    @Override // io.bidmachine.analytics.internal.D.a
    public Object a(String str, List list) {
        return a().a(str, list);
    }

    private final Object a(Object obj) {
        try {
            Result.Companion companion = Result.Companion;
            ResultKt.throwOnFailure(obj);
            Iterable iterable = (Iterable) obj;
            ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
            Iterator it = iterable.iterator();
            while (it.hasNext()) {
                arrayList.add(io.bidmachine.analytics.internal.C.b.a((io.bidmachine.analytics.internal.C.a) it.next()));
            }
            return Result.constructor-impl(arrayList);
        } catch (Throwable th) {
            Result.Companion companion2 = Result.Companion;
            return Result.constructor-impl(ResultKt.createFailure(th));
        }
    }
}
