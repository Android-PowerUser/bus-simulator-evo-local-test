package io.bidmachine.analytics.internal.B;

import android.database.sqlite.SQLiteDatabase;
import io.bidmachine.analytics.internal.a.a;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Lambda;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
final class a$c extends Lambda implements Function1 {
    final /* synthetic */ SQLiteDatabase a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    a$c(SQLiteDatabase sQLiteDatabase) {
        super(1);
        this.a = sQLiteDatabase;
    }

    public final void a(List list) {
        SQLiteDatabase sQLiteDatabase = this.a;
        String[] strArrA = null;
        String strA = list != null ? a.a(list, "id IN") : null;
        if (list != null) {
            ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
            Iterator it = list.iterator();
            while (it.hasNext()) {
                arrayList.add(((io.bidmachine.analytics.internal.C.a) it.next()).c());
            }
            strArrA = a.a(arrayList);
        }
        sQLiteDatabase.delete("monitor_record", strA, strArrA);
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        a((List) obj);
        return Unit.INSTANCE;
    }
}
