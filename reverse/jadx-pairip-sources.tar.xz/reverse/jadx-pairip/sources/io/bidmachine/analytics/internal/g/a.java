package io.bidmachine.analytics.internal.g;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class a extends Throwable {
    public a(String str) {
        super(str);
    }
}
