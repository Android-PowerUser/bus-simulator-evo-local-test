package io.bidmachine.analytics.internal.p;

import io.bidmachine.analytics.ReaderConfig;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.ranges.RangesKt;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class d {
    private final e a;
    private final b.a b;
    private Map c;

    public d(e eVar, b.a aVar) {
        this.a = eVar;
        this.b = aVar;
    }

    public final void a(io.bidmachine.analytics.internal.n.a.a aVar) {
        List<ReaderConfig.Rule.GeneralRule> listC = aVar.c();
        ArrayList arrayList = new ArrayList();
        for (ReaderConfig.Rule.GeneralRule generalRule : listC) {
            ReaderConfig.Rule.GeneralRule generalRule2 = generalRule instanceof ReaderConfig.Rule.GeneralRule ? generalRule : null;
            if (generalRule2 != null) {
                arrayList.add(generalRule2);
            }
        }
        ArrayList arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList, 10));
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            arrayList2.add(((ReaderConfig.Rule.GeneralRule) it.next()).getPath());
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(arrayList2, 10)), 16));
        for (Object obj : arrayList2) {
            linkedHashMap.put(obj, this.b.a());
        }
        this.c = MapsKt.toMutableMap(linkedHashMap);
    }

    public final void b() {
        Map map = this.c;
        if (map != null) {
            for (Map.Entry entry : map.entrySet()) {
                ((b) entry.getValue()).a((String) entry.getKey());
            }
        }
    }

    public /* synthetic */ d(e eVar, b.a aVar, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(eVar, (i & 2) != 0 ? new a(eVar) : aVar);
    }

    public final void a() {
        Map map = this.c;
        if (map != null) {
            Iterator it = map.entrySet().iterator();
            while (it.hasNext()) {
                ((b) ((Map.Entry) it.next()).getValue()).a();
            }
        }
    }

    public final String a(ReaderConfig.Rule rule) throws FileNotFoundException {
        if (rule instanceof ReaderConfig.Rule.GeneralRule) {
            String strB = this.a.b(((ReaderConfig.Rule.GeneralRule) rule).getPath());
            if (strB != null) {
                return strB;
            }
            throw new FileNotFoundException();
        }
        throw new IllegalStateException("Check failed.");
    }
}
