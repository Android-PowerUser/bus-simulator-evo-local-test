package io.bidmachine.analytics.internal.q;

import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Lambda;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
final class a$b extends Lambda implements Function0 {
    final /* synthetic */ a a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    a$b(a aVar) {
        super(0);
        this.a = aVar;
    }

    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public final String invoke() {
        return a.a(this.a).hashCode() + '_' + CollectionsKt.joinToString$default(CollectionsKt.listOf(new Integer[]{Integer.valueOf(this.a.c().a().size()), Integer.valueOf(this.a.c().c().size()), Integer.valueOf(this.a.c().b().size()), Integer.valueOf(this.a.e().a().size()), Integer.valueOf(this.a.e().c().size()), Integer.valueOf(this.a.e().b().size())}), "_", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (Function1) null, 62, (Object) null);
    }
}
