package io.bidmachine.analytics.internal.p;

import androidx.core.view.accessibility.AccessibilityEventCompat;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class e {
    private static final a d = new a((DefaultConstructorMarker) null);
    private final int a;
    private final Map b;
    private final Object c;

    public e(int i) {
        this.a = i;
        this.b = new LinkedHashMap();
        this.c = new Object();
    }

    public final InputStream a(String str) {
        Object obj;
        synchronized (this.c) {
            try {
                Result.Companion companion = Result.Companion;
                g gVar = (g) this.b.remove(str);
                obj = Result.constructor-impl(new ByteArrayInputStream(gVar != null ? h.a(gVar) : null));
            } catch (Throwable th) {
                Result.Companion companion2 = Result.Companion;
                obj = Result.constructor-impl(ResultKt.createFailure(th));
            }
        }
        return (InputStream) (Result.isFailure-impl(obj) ? null : obj);
    }

    public final String b(String str) {
        Object obj;
        Long lA;
        synchronized (this.c) {
            try {
                Result.Companion companion = Result.Companion;
                g gVar = (g) this.b.get(str);
                obj = Result.constructor-impl((gVar == null || (lA = gVar.a()) == null) ? null : lA.toString());
            } catch (Throwable th) {
                Result.Companion companion2 = Result.Companion;
                obj = Result.constructor-impl(ResultKt.createFailure(th));
            }
        }
        return (String) (Result.isFailure-impl(obj) ? null : obj);
    }

    public /* synthetic */ e(int i, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this((i2 & 1) != 0 ? AccessibilityEventCompat.TYPE_TOUCH_INTERACTION_END : i);
    }

    public final void a(String str, String str2) {
        synchronized (this.c) {
            try {
                Result.Companion companion = Result.Companion;
                Map map = this.b;
                Object objA = map.get(str);
                if (objA == null) {
                    objA = a();
                    map.put(str, objA);
                }
                ((g) objA).a(str2);
                Result.constructor-impl(Unit.INSTANCE);
            } catch (Throwable th) {
                Result.Companion companion2 = Result.Companion;
                Result.constructor-impl(ResultKt.createFailure(th));
            }
        }
    }

    private final g a() {
        int i = this.a;
        return new g(i / 2, i);
    }
}
