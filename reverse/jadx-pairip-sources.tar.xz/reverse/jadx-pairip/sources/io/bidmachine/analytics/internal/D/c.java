package io.bidmachine.analytics.internal.D;

import java.util.List;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface c {
    Object a(io.bidmachine.analytics.internal.g.c cVar);

    Object a(String str);

    Object a(String str, io.bidmachine.analytics.internal.g.c.a aVar);

    Object a(String str, List list);

    Object a(List list);

    Object a(List list, List list2);

    Object b(io.bidmachine.analytics.internal.g.c cVar);

    Object b(List list);

    Object c(List list);
}
