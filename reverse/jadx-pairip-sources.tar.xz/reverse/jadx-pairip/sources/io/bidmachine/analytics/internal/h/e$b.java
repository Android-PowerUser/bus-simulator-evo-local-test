package io.bidmachine.analytics.internal.h;

import com.fyber.inneractive.sdk.player.exoplayer2.text.cea.ekSv.rgysVOtZDFjbA;
import io.bidmachine.analytics.internal.g.c;
import io.bidmachine.analytics.internal.g.d;
import io.bidmachine.analytics.internal.v.a;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.collections.CollectionsKt;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class e$b implements c {
    private final String a;

    public e$b(String str) {
        this.a = str;
    }

    public void a(List list) {
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            c.a aVar = (c.a) it.next();
            String str = this.a;
            String strA = aVar.a();
            if (strA == null) {
                strA = rgysVOtZDFjbA.LcsscnfKLgoA;
            }
            arrayList.add(new c(null, str, 0L, strA, d.a(aVar.c()), aVar.b(), false, 69, null));
        }
        a.a.a(this.a, arrayList);
    }
}
