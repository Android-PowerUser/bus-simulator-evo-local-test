package io.bidmachine.analytics.internal.B;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import io.bidmachine.analytics.internal.C.c;
import io.bidmachine.analytics.internal.a.a;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Lambda;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
final class b$b extends Lambda implements Function1 {
    final /* synthetic */ SQLiteDatabase a;
    final /* synthetic */ ContentValues b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    b$b(SQLiteDatabase sQLiteDatabase, ContentValues contentValues) {
        super(1);
        this.a = sQLiteDatabase;
        this.b = contentValues;
    }

    public final void a(List list) {
        SQLiteDatabase sQLiteDatabase = this.a;
        ContentValues contentValues = this.b;
        String[] strArrA = null;
        String strA = list != null ? a.a(list, "id IN") : null;
        if (list != null) {
            ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
            Iterator it = list.iterator();
            while (it.hasNext()) {
                arrayList.add(((c) it.next()).c());
            }
            strArrA = a.a(arrayList);
        }
        sQLiteDatabase.update("reader_record", contentValues, strA, strArrA);
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        a((List) obj);
        return Unit.INSTANCE;
    }
}
