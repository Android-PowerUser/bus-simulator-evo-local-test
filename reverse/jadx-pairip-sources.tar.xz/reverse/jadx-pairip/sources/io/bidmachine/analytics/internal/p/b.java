package io.bidmachine.analytics.internal.p;

import java.util.Iterator;
import java.util.concurrent.CancellationException;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.sequences.Sequence;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.Job;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class b {
    private final e a;
    private final f b;
    private final CoroutineScope c;
    private Job d;

    public b(e eVar, f fVar, CoroutineScope coroutineScope) {
        this.a = eVar;
        this.b = fVar;
        this.c = coroutineScope;
    }

    private final boolean b() {
        Job job = this.d;
        return job != null && job.isActive();
    }

    public final void a(String str) {
        Job job = this.d;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        this.d = BuildersKt.launch$default(this.c, (CoroutineContext) null, (CoroutineStart) null, new b(this, str, (Continuation) null), 3, (Object) null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void a(String str, Sequence sequence) {
        Iterator it = sequence.iterator();
        while (b() && it.hasNext()) {
            this.a.a(str, (String) it.next());
        }
    }

    public final void a() {
        Job job = this.d;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        this.d = null;
        synchronized (this.b) {
            try {
                Result.Companion companion = Result.Companion;
                this.b.a();
                Result.constructor-impl(Unit.INSTANCE);
            } catch (Throwable th) {
                Result.Companion companion2 = Result.Companion;
                Result.constructor-impl(ResultKt.createFailure(th));
            }
        }
    }
}
