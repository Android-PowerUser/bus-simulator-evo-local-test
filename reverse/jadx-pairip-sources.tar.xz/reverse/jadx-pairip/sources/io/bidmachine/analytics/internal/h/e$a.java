package io.bidmachine.analytics.internal.h;

import io.bidmachine.analytics.internal.g.b;
import io.bidmachine.analytics.internal.g.e;
import io.bidmachine.analytics.internal.v.a;
import java.util.Map;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class e$a implements b {
    private final String a;
    private final String b;

    public e$a(String str, String str2) {
        this.a = str;
        this.b = str2;
    }

    public void a(Map map) {
        a.a.a(new b(null, this.a, this.b, 0L, map, null, 41, null));
    }

    public void a(e eVar) {
        a.a.a(new b(null, this.a, this.b, 0L, null, eVar, 25, null));
    }
}
