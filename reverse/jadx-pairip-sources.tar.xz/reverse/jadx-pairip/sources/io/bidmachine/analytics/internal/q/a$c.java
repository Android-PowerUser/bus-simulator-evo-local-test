package io.bidmachine.analytics.internal.q;

import java.util.Collection;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Lambda;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
final class a$c extends Lambda implements Function0 {
    final /* synthetic */ a a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    a$c(a aVar) {
        super(0);
        this.a = aVar;
    }

    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public final String invoke() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        a aVar = this.a;
        jSONObject.put("ver", aVar.a());
        jSONObject.put("iaa", new JSONArray((Collection) aVar.c().a()));
        jSONObject.put("iah", new JSONArray((Collection) aVar.c().c()));
        jSONObject.put("iad", new JSONArray((Collection) aVar.c().b()));
        jSONObject.put("sua", new JSONArray((Collection) aVar.e().a()));
        jSONObject.put("suh", new JSONArray((Collection) aVar.e().c()));
        jSONObject.put("sud", new JSONArray((Collection) aVar.e().b()));
        return jSONObject.toString();
    }
}
