package io.bidmachine.analytics.internal.g;

import io.bidmachine.analytics.ReaderConfig;
import kotlin.NoWhenBranchMatchedException;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public abstract class d {
    /* JADX INFO: Thrown type has an unknown type hierarchy: kotlin.NoWhenBranchMatchedException */
    public static final c.a a(ReaderConfig.Rule rule) throws NoWhenBranchMatchedException {
        if (rule instanceof ReaderConfig.Rule.GeneralRule) {
            ReaderConfig.Rule.GeneralRule generalRule = (ReaderConfig.Rule.GeneralRule) rule;
            return new c.a.C0004a(generalRule.getTag(), generalRule.getPath());
        }
        if (!(rule instanceof ReaderConfig.Rule.PurRule)) {
            throw new NoWhenBranchMatchedException();
        }
        ReaderConfig.Rule.PurRule purRule = (ReaderConfig.Rule.PurRule) rule;
        return new c.a.b(purRule.getTag(), purRule.getPath(), purRule.getQuery(), purRule.getShouldReport());
    }
}
