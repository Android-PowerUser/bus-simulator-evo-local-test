package io.bidmachine.analytics.internal.p;

import kotlin.text.Charsets;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public abstract class h {
    public static final byte[] a(g gVar) {
        return gVar.toString().getBytes(Charsets.UTF_8);
    }
}
