package io.bidmachine.analytics.internal.p003b;

import io.bidmachine.analytics.internal.b.c;
import java.security.SecureRandom;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class c$a extends ThreadLocal {
    c$a() {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // java.lang.ThreadLocal
    public SecureRandom initialValue() {
        return c.a(c.a);
    }
}
