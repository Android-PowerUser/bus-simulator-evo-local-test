package io.bidmachine.analytics.internal.B;

import kotlin.jvm.internal.DefaultConstructorMarker;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class a$a {
    public /* synthetic */ a$a(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }

    private a$a() {
    }
}
