package io.bidmachine.analytics.internal.p;

import java.text.ParseException;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.text.MatchResult;
import kotlin.text.Regex;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class a {
    public static final a c = new a((DefaultConstructorMarker) null);
    private final Regex a = new Regex("^(\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3}) ([A-Z])\\/(\\S+)\\(\\s*(\\d+)\\): (.*)$");
    private final i b = new i();

    public final b a(String str) throws ParseException {
        MatchResult matchResultFind$default = Regex.find$default(this.a, str, 0, 2, (Object) null);
        if (matchResultFind$default == null) {
            return null;
        }
        MatchResult.Destructured destructured = matchResultFind$default.getDestructured();
        String str2 = (String) destructured.getMatch().getGroupValues().get(1);
        String str3 = (String) destructured.getMatch().getGroupValues().get(2);
        String str4 = (String) destructured.getMatch().getGroupValues().get(3);
        String str5 = (String) destructured.getMatch().getGroupValues().get(5);
        Long lA = this.b.a(str2);
        return new b(lA != null ? lA.longValue() : 0L, str4, str3, str5);
    }
}
