package io.bidmachine.analytics.internal.p;

import android.content.Context;
import io.bidmachine.analytics.ReaderConfig;
import kotlin.coroutines.Continuation;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class c extends io.bidmachine.analytics.internal.n.a {
    public static final a j = new a(null);
    private final e g;
    private final d h;
    private final String i;

    public static final class a {
        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private a() {
        }
    }

    public /* synthetic */ c(e eVar, d dVar, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(eVar, (i & 2) != 0 ? new d(eVar, null, 2, null) : dVar);
    }

    public String a() {
        return this.i;
    }

    public void d(Context context) {
    }

    public void e(Context context) {
        super.e(context);
        this.h.a();
    }

    public void f(Context context) {
        this.h.b();
        super.f(context);
    }

    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public void b(io.bidmachine.analytics.internal.n.a.a aVar) {
        super.a(aVar);
        this.h.a(aVar);
    }

    public c(e eVar, d dVar) {
        this.g = eVar;
        this.h = dVar;
        this.i = "alog";
    }

    public Object a(ReaderConfig.Rule rule, Continuation continuation) {
        return this.h.a(rule);
    }
}
