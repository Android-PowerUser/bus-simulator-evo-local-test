package io.bidmachine.nativead.view;

import io.bidmachine.utils.lazy.LazyValue;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class MediaView$$ExternalSyntheticLambda1 implements LazyValue {
    public final /* synthetic */ int f$0;
    public final /* synthetic */ boolean f$1;

    public /* synthetic */ MediaView$$ExternalSyntheticLambda1(int i, boolean z) {
        this.f$0 = i;
        this.f$1 = z;
    }

    @Override // io.bidmachine.utils.lazy.LazyValue
    public final Object get() {
        return MediaView.$r8$lambda$eFFlVj0dt5pQX7Fxk-7gwn_rrk0(this.f$0, this.f$1);
    }
}
