package io.bidmachine.nativead.view;

import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class MediaView$$ExternalSyntheticLambda5 implements View.OnClickListener {
    public final /* synthetic */ MediaView f$0;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MediaView.$r8$lambda$i8az-uXKgSv0ENnqxCMbcaP8dJo(this.f$0, view);
    }
}
