package io.bidmachine.nativead.tasks;

import android.net.Uri;
import io.bidmachine.iab.vast.VastRequest;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: DownloadVastVideoTask.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 7, 1})
@DebugMetadata(c = "io.bidmachine.nativead.tasks.DownloadVastVideoTask$sendSuccess$2", f = "DownloadVastVideoTask.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
final class DownloadVastVideoTask$sendSuccess$2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ VastRequest $vastRequest;
    final /* synthetic */ Uri $videoFileUri;
    int label;
    final /* synthetic */ DownloadVastVideoTask this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    DownloadVastVideoTask$sendSuccess$2(DownloadVastVideoTask downloadVastVideoTask, Uri uri, VastRequest vastRequest, Continuation<? super DownloadVastVideoTask$sendSuccess$2> continuation) {
        super(2, continuation);
        this.this$0 = downloadVastVideoTask;
        this.$videoFileUri = uri;
        this.$vastRequest = vastRequest;
    }

    @NotNull
    public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
        return new DownloadVastVideoTask$sendSuccess$2(this.this$0, this.$videoFileUri, this.$vastRequest, continuation);
    }

    @Nullable
    public final Object invoke(@NotNull CoroutineScope coroutineScope, @Nullable Continuation<? super Unit> continuation) {
        return ((DownloadVastVideoTask$sendSuccess$2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    @Nullable
    public final Object invokeSuspend(@NotNull Object obj) throws Throwable {
        IntrinsicsKt.getCOROUTINE_SUSPENDED();
        if (this.label != 0) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        ResultKt.throwOnFailure(obj);
        DownloadVastVideoTask.access$getListener$p(this.this$0).onVideoLoaded(this.this$0, this.$videoFileUri, this.$vastRequest);
        return Unit.INSTANCE;
    }
}
