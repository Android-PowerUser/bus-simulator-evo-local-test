package io.bidmachine.nativead;

import androidx.annotation.Nullable;
import io.bidmachine.LabelData;
import io.bidmachine.PrivacySheetData;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface NativeData extends NativePublicData {
    @Nullable
    LabelData getAdLabelData();

    @Nullable
    String getClickUrl();

    @Nullable
    PrivacySheetData getPrivacySheetData();

    @Nullable
    String getVideoAdm();

    @Nullable
    String getVideoUrl();
}
