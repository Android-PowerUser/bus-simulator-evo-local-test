package io.bidmachine.nativead;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import io.bidmachine.AdObjectImpl;
import io.bidmachine.AdProcessCallback;
import io.bidmachine.ContextProvider;
import io.bidmachine.ImageData;
import io.bidmachine.ImageDataImpl;
import io.bidmachine.LabelData;
import io.bidmachine.MediaAssetType;
import io.bidmachine.PrivacySheetData;
import io.bidmachine.RendererConfiguration;
import io.bidmachine.core.Logger;
import io.bidmachine.core.Utils;
import io.bidmachine.iab.vast.VastRequest;
import io.bidmachine.internal.BidMachineAssetCacheInitializer;
import io.bidmachine.internal.utils.visibility.VisibilityTrackerHolder;
import io.bidmachine.media3.exoplayer.DefaultRenderersFactory;
import io.bidmachine.models.AdObjectParams;
import io.bidmachine.nativead.utils.ImageHelper;
import io.bidmachine.nativead.view.MediaView;
import io.bidmachine.nativead.view.NativeMediaView;
import io.bidmachine.rendering.Rendering;
import io.bidmachine.rendering.Repository;
import io.bidmachine.rendering.utils.UrlHandler;
import io.bidmachine.rendering.view.WatermarkView;
import io.bidmachine.unified.UnifiedNativeAd;
import io.bidmachine.unified.UnifiedNativeAdCallback;
import io.bidmachine.unified.UnifiedNativeAdRequestParams;
import io.bidmachine.util.Tag;
import io.bidmachine.util.ViewUtils;
import io.bidmachine.utils.BMError;
import io.bidmachine.utils.ViewHelper;
import io.bidmachine.utils.lazy.LazyCachedValue;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class NativeAdObject extends AdObjectImpl<NativeRequest, AdObjectParams, UnifiedNativeAd, UnifiedNativeAdCallback, UnifiedNativeAdRequestParams> implements NativeData, NativeMediaPrivateData, NativeContainer, NativeInteractor, View.OnClickListener {
    static final float DEFAULT_RATING = -1.0f;
    private static final int ICON_VIEW_ID = 100;
    private static final String INSTALL = "Install";
    private static final int MEDIA_VIEW_ID = 200;

    @NonNull
    private static final WeakHashMap<ViewGroup, WeakHashMap<View, View.OnClickListener>> clickStorage = new WeakHashMap<>(3);

    @Nullable
    private ViewGroup container;

    @Nullable
    private ImageDataImpl iconImageData;
    private boolean isImpressionTracked;

    @Nullable
    private ImageDataImpl mainImageData;

    @Nullable
    private MediaView mediaView;

    @Nullable
    private NativeNetworkAdapter nativeNetworkAdapter;

    @Nullable
    private ProgressDialog progressDialog;

    @Nullable
    private Handler progressDialogCanceller;

    @Nullable
    private Runnable progressRunnable;

    @Nullable
    private View providerView;

    @NonNull
    private final LazyCachedValue<Repository> repository;

    @NonNull
    private final Tag tag;

    @Nullable
    private VastRequest vastRequest;

    @Nullable
    private Uri videoUri;
    private boolean viewRegistered;

    @NonNull
    private final VisibilityTrackerHolder visibilityTrackerHolder;

    @Nullable
    private AutoLayoutListener watermarkAutoLayoutListener;

    @Nullable
    private View watermarkView;

    public void dispatchVideoPlayFinished() {
    }

    NativeAdObject(@NonNull ContextProvider contextProvider, @NonNull AdProcessCallback processCallback, @NonNull NativeRequest adRequest, @NonNull AdObjectParams adObjectParams, @NonNull UnifiedNativeAd unifiedAd) {
        super(contextProvider, processCallback, adRequest, adObjectParams, unifiedAd);
        this.tag = new Tag("NativeAdObject");
        this.visibilityTrackerHolder = new VisibilityTrackerHolder();
        this.repository = new LazyCachedValue<>(new NativeAdObject$.ExternalSyntheticLambda1(contextProvider));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Repository lambda$new$0(ContextProvider contextProvider) {
        return Rendering.INSTANCE.createRepository(BidMachineAssetCacheInitializer.getMediaFileCacheManager(contextProvider.getApplicationContext()));
    }

    @NonNull
    public Tag getTag() {
        return this.tag;
    }

    public void setNativeNetworkAdapter(@Nullable NativeNetworkAdapter nativeNetworkAdapter) {
        this.nativeNetworkAdapter = nativeNetworkAdapter;
        if (nativeNetworkAdapter != null) {
            this.iconImageData = new ImageDataImpl(nativeNetworkAdapter.getIcon());
            this.mainImageData = new ImageDataImpl(nativeNetworkAdapter.getMainImage());
        }
    }

    @Nullable
    public String getTitle() {
        NativeNetworkAdapter nativeNetworkAdapter = this.nativeNetworkAdapter;
        if (nativeNetworkAdapter != null) {
            return nativeNetworkAdapter.getTitle();
        }
        return null;
    }

    @Nullable
    public String getDescription() {
        NativeNetworkAdapter nativeNetworkAdapter = this.nativeNetworkAdapter;
        if (nativeNetworkAdapter != null) {
            return nativeNetworkAdapter.getDescription();
        }
        return null;
    }

    @NonNull
    public String getCallToAction() {
        NativeNetworkAdapter nativeNetworkAdapter = this.nativeNetworkAdapter;
        String callToAction = nativeNetworkAdapter != null ? nativeNetworkAdapter.getCallToAction() : null;
        return TextUtils.isEmpty(callToAction) ? INSTALL : callToAction;
    }

    public float getRating() {
        NativeNetworkAdapter nativeNetworkAdapter = this.nativeNetworkAdapter;
        return nativeNetworkAdapter != null ? nativeNetworkAdapter.getRating() : DEFAULT_RATING;
    }

    @Nullable
    public ImageData getIcon() {
        return this.iconImageData;
    }

    @Nullable
    public ImageData getMainImage() {
        return this.mainImageData;
    }

    @Override // io.bidmachine.nativead.NativeData
    @Nullable
    public String getClickUrl() {
        NativeNetworkAdapter nativeNetworkAdapter = this.nativeNetworkAdapter;
        if (nativeNetworkAdapter != null) {
            return nativeNetworkAdapter.getClickUrl();
        }
        return null;
    }

    @Override // io.bidmachine.nativead.NativeData
    @Nullable
    public String getVideoUrl() {
        NativeNetworkAdapter nativeNetworkAdapter = this.nativeNetworkAdapter;
        if (nativeNetworkAdapter != null) {
            return nativeNetworkAdapter.getVideoUrl();
        }
        return null;
    }

    @Override // io.bidmachine.nativead.NativeData
    @Nullable
    public String getVideoAdm() {
        NativeNetworkAdapter nativeNetworkAdapter = this.nativeNetworkAdapter;
        if (nativeNetworkAdapter != null) {
            return nativeNetworkAdapter.getVideoAdm();
        }
        return null;
    }

    @Override // io.bidmachine.nativead.NativeData
    @Nullable
    public LabelData getAdLabelData() {
        NativeNetworkAdapter nativeNetworkAdapter = this.nativeNetworkAdapter;
        if (nativeNetworkAdapter != null) {
            return nativeNetworkAdapter.getAdLabelData();
        }
        return null;
    }

    @Override // io.bidmachine.nativead.NativeData
    @Nullable
    public PrivacySheetData getPrivacySheetData() {
        NativeNetworkAdapter nativeNetworkAdapter = this.nativeNetworkAdapter;
        if (nativeNetworkAdapter != null) {
            return nativeNetworkAdapter.getPrivacySheetData();
        }
        return null;
    }

    @Nullable
    public Drawable getIconDrawable() {
        ImageDataImpl imageDataImpl = this.iconImageData;
        if (imageDataImpl != null) {
            return imageDataImpl.getImage();
        }
        return null;
    }

    public void setIconBitmap(@Nullable Bitmap iconBitmap) {
        ImageDataImpl imageDataImpl = this.iconImageData;
        if (imageDataImpl != null) {
            imageDataImpl.setImage(new BitmapDrawable(getApplicationContext().getResources(), iconBitmap));
        }
    }

    @Nullable
    public Uri getIconUri() {
        ImageDataImpl imageDataImpl = this.iconImageData;
        if (imageDataImpl != null) {
            return imageDataImpl.getLocalUri();
        }
        return null;
    }

    public void setIconUri(@Nullable Uri iconUri) {
        ImageDataImpl imageDataImpl = this.iconImageData;
        if (imageDataImpl != null) {
            imageDataImpl.setLocalUri(iconUri);
        }
    }

    @Nullable
    public Drawable getImageDrawable() {
        ImageDataImpl imageDataImpl = this.mainImageData;
        if (imageDataImpl != null) {
            return imageDataImpl.getImage();
        }
        return null;
    }

    public void setImageBitmap(@Nullable Bitmap imageBitmap) {
        ImageDataImpl imageDataImpl = this.mainImageData;
        if (imageDataImpl != null) {
            imageDataImpl.setImage(new BitmapDrawable(getApplicationContext().getResources(), imageBitmap));
        }
    }

    @Nullable
    public Uri getImageUri() {
        ImageDataImpl imageDataImpl = this.mainImageData;
        if (imageDataImpl != null) {
            return imageDataImpl.getLocalUri();
        }
        return null;
    }

    public void setImageUri(@Nullable Uri imageUri) {
        ImageDataImpl imageDataImpl = this.mainImageData;
        if (imageDataImpl != null) {
            imageDataImpl.setLocalUri(imageUri);
        }
    }

    public void setVideoUri(@Nullable Uri videoUri) {
        this.videoUri = videoUri;
    }

    @Nullable
    public Uri getVideoUri() {
        return this.videoUri;
    }

    public void setVastRequest(@Nullable VastRequest vastRequest) {
        this.vastRequest = vastRequest;
    }

    @Nullable
    public VastRequest getVastRequest() {
        return this.vastRequest;
    }

    public boolean hasVideo() {
        NativeNetworkAdapter nativeNetworkAdapter;
        return this.videoUri != null || ((nativeNetworkAdapter = this.nativeNetworkAdapter) != null && nativeNetworkAdapter.hasVideo());
    }

    @NonNull
    public UnifiedNativeAdCallback createUnifiedCallback(@NonNull AdProcessCallback processCallback) {
        return new UnifiedNativeAdCallbackImpl(this, processCallback);
    }

    @Nullable
    public View getProviderView(@NonNull Context context) {
        NativeNetworkAdapter nativeNetworkAdapter;
        if (this.providerView == null && (nativeNetworkAdapter = this.nativeNetworkAdapter) != null) {
            this.providerView = nativeNetworkAdapter.createProviderView(context);
        }
        return this.providerView;
    }

    public void registerView(@NonNull ViewGroup nativeAdView, @Nullable View imageView, @Nullable NativeMediaView nativeMediaView, @Nullable Set<View> clickableViews) {
        registerView(nativeAdView, imageView, nativeMediaView, clickableViews, null);
    }

    void registerView(@NonNull ViewGroup nativeAdView, @Nullable View imageView, @Nullable NativeMediaView nativeMediaView, @Nullable Set<View> clickableViews, @Nullable RendererConfiguration rendererConfiguration) {
        try {
            if (!isNativeAdViewValid(nativeAdView, imageView, nativeMediaView)) {
                getProcessCallback().processShowFail(BMError.internal("Native ad views are invalid"));
                return;
            }
            configureClickableView(nativeAdView, clickableViews);
            ImageView imageViewConfigureIconView = configureIconView(imageView);
            configureMediaView(nativeMediaView);
            this.container = nativeAdView;
            if (!this.isImpressionTracked) {
                getProcessCallback().processStartVisibilityTracker();
                this.visibilityTrackerHolder.startTracking(nativeAdView, getParams().getVisibilityParams(), new 1(this));
                dispatchFillAd();
            }
            MediaView mediaView = this.mediaView;
            if (mediaView != null) {
                mediaView.onViewAppearOnScreen();
                this.mediaView.startVideoVisibilityCheckerTimer();
            }
            NativeNetworkAdapter nativeNetworkAdapter = this.nativeNetworkAdapter;
            if (nativeNetworkAdapter != null) {
                nativeNetworkAdapter.registerNative(nativeAdView, imageViewConfigureIconView, nativeMediaView, clickableViews);
            }
            configureWatermark(nativeAdView, rendererConfiguration);
            View view = this.watermarkView;
            if (view != null) {
                view.bringToFront();
            }
            this.viewRegistered = true;
        } catch (Throwable th) {
            Logger.w(this.tag, th);
            unregisterView();
            getProcessCallback().processShowFail(BMError.throwable("Exception registering view for native ad object", th));
        }
    }

    public void unregisterView() {
        try {
            this.visibilityTrackerHolder.stopTracking();
            ViewGroup viewGroup = this.container;
            if (viewGroup != null) {
                removeWatermarkAutoLayout(viewGroup);
                deConfigureClickableView(this.container);
                this.container = null;
            }
            MediaView mediaView = this.mediaView;
            if (mediaView != null) {
                mediaView.stopVideoVisibilityCheckerTimer();
                this.mediaView.release();
                this.mediaView = null;
            }
            NativeNetworkAdapter nativeNetworkAdapter = this.nativeNetworkAdapter;
            if (nativeNetworkAdapter != null) {
                nativeNetworkAdapter.unregisterNative();
            }
            removeWatermark();
            this.viewRegistered = false;
        } catch (Throwable th) {
            Logger.w(this.tag, th);
        }
    }

    public void onDestroy() {
        try {
            super.onDestroy();
            unregisterView();
            Utils.ifNotNull(this.iconImageData, new NativeAdObject$.ExternalSyntheticLambda2());
            Utils.ifNotNull(this.mainImageData, new NativeAdObject$.ExternalSyntheticLambda2());
            Utils.ifNotNull(this.nativeNetworkAdapter, new NativeAdObject$.ExternalSyntheticLambda3());
            this.iconImageData = null;
            this.mainImageData = null;
        } catch (Throwable th) {
            try {
                Logger.w(this.tag, th);
            } finally {
                ((Repository) this.repository.get()).unholdMediaFiles(this.tag);
            }
        }
    }

    @VisibleForTesting
    boolean isNativeAdViewValid(@Nullable ViewGroup nativeAdView, @Nullable View imageView, @Nullable NativeMediaView nativeMediaView) {
        if (nativeAdView == null) {
            Logger.d(this.tag, "NativeAdView cannot be null. NativeAd is NOT registered");
            return false;
        }
        if (imageView == null && nativeMediaView == null) {
            Logger.d(this.tag, "ImageView or NativeMediaView cannot be null. NativeAd is NOT registered");
            return false;
        }
        if (imageView != null && !ViewHelper.belongTo(nativeAdView, imageView)) {
            Logger.d(this.tag, "ImageView should belong to NativeAdView");
        }
        if (nativeMediaView == null || ViewHelper.belongTo(nativeAdView, nativeMediaView)) {
            return true;
        }
        Logger.d(this.tag, "NativeMediaView should belong to NativeAdView");
        return true;
    }

    private void configureClickableView(@NonNull ViewGroup nativeAdView, @Nullable Set<View> clickableViews) {
        deConfigureClickableView(nativeAdView);
        if (clickableViews == null || clickableViews.isEmpty()) {
            return;
        }
        WeakHashMap<View, View.OnClickListener> weakHashMap = new WeakHashMap<>();
        clickStorage.put(nativeAdView, weakHashMap);
        for (View view : clickableViews) {
            if (view != null) {
                view.setOnClickListener(this);
                weakHashMap.put(view, this);
            }
        }
    }

    private void deConfigureClickableView(@NonNull ViewGroup nativeAdView) {
        WeakHashMap<View, View.OnClickListener> weakHashMap = clickStorage.get(nativeAdView);
        if (weakHashMap != null) {
            for (Map.Entry<View, View.OnClickListener> entry : weakHashMap.entrySet()) {
                if (entry != null && entry.getKey() != null) {
                    entry.getKey().setOnClickListener(null);
                }
            }
            clickStorage.remove(nativeAdView);
        }
    }

    @Nullable
    private ImageView configureIconView(@Nullable View view) {
        ImageView imageView;
        if (view instanceof ImageView) {
            imageView = (ImageView) view;
        } else if (view instanceof ViewGroup) {
            ImageView imageView2 = new ImageView(view.getContext());
            imageView2.setId(100);
            imageView2.setScaleType(ImageView.ScaleType.FIT_CENTER);
            ViewGroup viewGroup = (ViewGroup) view;
            viewGroup.removeAllViews();
            viewGroup.addView(imageView2, new ViewGroup.LayoutParams(-1, -1));
            imageView = imageView2;
        } else {
            imageView = null;
        }
        if (imageView != null && this.iconImageData != null) {
            ImageHelper.fillImageView(imageView.getContext(), imageView, this.iconImageData.getLocalUri(), this.iconImageData.getImage());
        }
        return imageView;
    }

    private void configureMediaView(@Nullable NativeMediaView nativeMediaView) {
        if (nativeMediaView == null) {
            return;
        }
        View viewCreateMediaView = createMediaView(nativeMediaView.getContext());
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
        layoutParams.addRule(13, -1);
        ViewUtils.addSingleViewSafely(nativeMediaView, viewCreateMediaView, layoutParams);
    }

    @NonNull
    private View createMediaView(@NonNull Context context) {
        View viewCreateCustomMediaView;
        NativeNetworkAdapter nativeNetworkAdapter = this.nativeNetworkAdapter;
        if (nativeNetworkAdapter != null && (viewCreateCustomMediaView = nativeNetworkAdapter.createCustomMediaView(context)) != null) {
            return viewCreateCustomMediaView;
        }
        MediaView mediaView = new MediaView(context);
        mediaView.setId(200);
        NativeAdRequestParameters adRequestParameters = getAdRequest().getAdRequestParameters();
        if (adRequestParameters.containsAssetType(MediaAssetType.Image) || adRequestParameters.containsAssetType(MediaAssetType.Video)) {
            mediaView.setNativeAdObject(this);
        }
        this.mediaView = mediaView;
        return mediaView;
    }

    private void configureWatermark(@NonNull ViewGroup container, @Nullable RendererConfiguration rendererConfiguration) {
        Drawable watermarkDrawable;
        removeWatermarkAutoLayout(container);
        removeWatermark();
        if (rendererConfiguration == null || (watermarkDrawable = rendererConfiguration.getWatermarkDrawable(getApplicationContext())) == null) {
            return;
        }
        WatermarkView watermarkView = new WatermarkView(container.getContext().getApplicationContext());
        watermarkView.setLayoutParams(ViewUtils.createMatchParentParams());
        watermarkView.setWatermark(watermarkDrawable);
        this.watermarkView = watermarkView;
        AutoLayoutListener autoLayoutListener = new AutoLayoutListener(watermarkView);
        this.watermarkAutoLayoutListener = autoLayoutListener;
        container.addOnLayoutChangeListener(autoLayoutListener);
        container.addView(watermarkView);
    }

    private void removeWatermarkAutoLayout(@NonNull ViewGroup container) {
        AutoLayoutListener autoLayoutListener = this.watermarkAutoLayoutListener;
        if (autoLayoutListener != null) {
            container.removeOnLayoutChangeListener(autoLayoutListener);
            this.watermarkAutoLayoutListener = null;
        }
    }

    private void removeWatermark() {
        View view = this.watermarkView;
        if (view != null) {
            ViewUtils.removeFromParent(view);
            this.watermarkView = null;
        }
    }

    private void showProgressDialog(@Nullable Activity activity) {
        if (this.container != null && mayShowProgressDialog() && Utils.canAddWindowToActivity(activity)) {
            this.container.addOnAttachStateChangeListener(new 2(this));
            ProgressDialog progressDialogShow = ProgressDialog.show(activity, "", "Loading...");
            this.progressDialog = progressDialogShow;
            progressDialogShow.setProgressStyle(0);
            this.progressDialog.setCancelable(false);
            this.progressRunnable = new 3(this);
            Handler handler = new Handler(Looper.getMainLooper());
            this.progressDialogCanceller = handler;
            handler.postDelayed(this.progressRunnable, DefaultRenderersFactory.DEFAULT_ALLOWED_VIDEO_JOINING_TIME_MS);
        }
    }

    private boolean mayShowProgressDialog() {
        ProgressDialog progressDialog = this.progressDialog;
        return progressDialog == null || !progressDialog.isShowing();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void hideProgressDialog() {
        Handler handler;
        ProgressDialog progressDialog = this.progressDialog;
        if (progressDialog != null && progressDialog.isShowing()) {
            this.progressDialog.dismiss();
            this.progressDialog = null;
        }
        Runnable runnable = this.progressRunnable;
        if (runnable == null || (handler = this.progressDialogCanceller) == null) {
            return;
        }
        handler.removeCallbacks(runnable);
        this.progressDialogCanceller = null;
        this.progressRunnable = null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void loadAsset(@NonNull Context context, @NonNull NativeData nativeData) {
        new AssetLoader(context, this.tag, getAdRequest().getAdRequestParameters(), getProcessCallback(), nativeData, this).downloadNativeAdsImages(context);
    }

    public boolean isViewRegistered() {
        return this.viewRegistered;
    }

    public void dispatchFillAd() {
        getProcessCallback().processFillAd();
    }

    public boolean dispatchShown() {
        return getProcessCallback().processVisibilityTrackerShown();
    }

    public void dispatchImpression() {
        getProcessCallback().processVisibilityTrackerImpression();
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        dispatchClick();
    }

    public void onClicked() {
        super.onClicked();
        String clickUrl = getClickUrl();
        if (TextUtils.isEmpty(clickUrl)) {
            return;
        }
        showProgressDialog(getActivity());
        UrlHandler.openUrl(getApplicationContext(), clickUrl, new NativeAdObject$.ExternalSyntheticLambda0(this));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onClicked$1(Boolean bool) throws Throwable {
        hideProgressDialog();
    }

    public void dispatchClick() {
        getProcessCallback().processClicked();
    }
}
