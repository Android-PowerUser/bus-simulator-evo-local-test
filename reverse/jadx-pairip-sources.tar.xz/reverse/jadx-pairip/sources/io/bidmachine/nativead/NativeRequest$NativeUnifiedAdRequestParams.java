package io.bidmachine.nativead;

import androidx.annotation.NonNull;
import io.bidmachine.TargetingParams;
import io.bidmachine.UnifiedAdRequestParamsImpl;
import io.bidmachine.models.DataRestrictions;
import io.bidmachine.unified.UnifiedNativeAdRequestParams;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class NativeRequest$NativeUnifiedAdRequestParams extends UnifiedAdRequestParamsImpl<NativeAdRequestParameters> implements UnifiedNativeAdRequestParams {
    @NonNull
    public /* bridge */ /* synthetic */ NativeAdRequestParameters getAdRequestParameters() {
        return super.getAdRequestParameters();
    }

    private NativeRequest$NativeUnifiedAdRequestParams(@NonNull NativeAdRequestParameters adRequestParameters, @NonNull TargetingParams targetingParams, @NonNull DataRestrictions dataRestrictions) {
        super(adRequestParameters, targetingParams, dataRestrictions);
    }
}
