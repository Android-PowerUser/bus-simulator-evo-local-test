package io.bidmachine.nativead.view;

import android.view.View;
import io.bidmachine.Executable;
import java.util.Set;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class NativeAdContentLayout$$ExternalSyntheticLambda1 implements Executable {
    public final /* synthetic */ Set f$0;

    public final void execute(Object obj) {
        this.f$0.add((View) obj);
    }
}
