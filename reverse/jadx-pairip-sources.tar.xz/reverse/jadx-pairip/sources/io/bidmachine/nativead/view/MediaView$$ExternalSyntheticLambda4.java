package io.bidmachine.nativead.view;

import android.view.TextureView;
import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class MediaView$$ExternalSyntheticLambda4 implements View.OnClickListener {
    public final /* synthetic */ MediaView f$0;
    public final /* synthetic */ TextureView f$1;

    public /* synthetic */ MediaView$$ExternalSyntheticLambda4(MediaView mediaView, TextureView textureView) {
        this.f$0 = mediaView;
        this.f$1 = textureView;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MediaView.$r8$lambda$qI64MjedvllkujssI-cs_xblQRc(this.f$0, this.f$1, view);
    }
}
