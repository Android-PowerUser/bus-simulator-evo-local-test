package io.bidmachine.nativead.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.safedk.android.analytics.brandsafety.DetectTouchUtils;
import io.bidmachine.Executable;
import io.bidmachine.R;
import io.bidmachine.core.Logger;
import io.bidmachine.core.Utils;
import io.bidmachine.nativead.NativeAd;
import io.bidmachine.nativead.NativeData;
import io.bidmachine.nativead.NativePublicData;
import io.bidmachine.utils.ViewHelper;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class NativeAdContentLayout extends NativeAdContainer {

    @Nullable
    protected View callToActionView;
    private int callToActionViewId;

    @NonNull
    private Set<WeakReference<View>> clickableViewRefs;

    @Nullable
    private NativeAd currentAd;

    @Nullable
    protected View descriptionView;
    private int descriptionViewId;

    @Nullable
    protected View iconView;
    private int iconViewId;

    @Nullable
    protected NativeMediaView mediaView;
    private int mediaViewId;

    @Nullable
    protected View providerView;
    private int providerViewId;

    @Nullable
    protected View ratingView;
    private int ratingViewId;

    @Nullable
    protected View titleView;
    private int titleViewId;

    /* JADX WARN: Multi-variable type inference failed */
    public boolean dispatchTouchEvent(MotionEvent me) {
        DetectTouchUtils.viewOnTouch("io.bidmachine", this, me);
        return super.dispatchTouchEvent(me);
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (1 == 0) {
            setMeasuredDimension(0, 0);
        } else {
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        }
    }

    public /* bridge */ /* synthetic */ void addView(View child) {
        super.addView(child);
    }

    public /* bridge */ /* synthetic */ void addView(View child, int index) {
        super.addView(child, index);
    }

    public /* bridge */ /* synthetic */ void addView(View child, int width, int height) {
        super.addView(child, width, height);
    }

    public /* bridge */ /* synthetic */ void addView(View child, int index, ViewGroup.LayoutParams params) {
        super.addView(child, index, params);
    }

    public /* bridge */ /* synthetic */ void addView(View child, ViewGroup.LayoutParams params) {
        super.addView(child, params);
    }

    public /* bridge */ /* synthetic */ void bringChildToFront(View child) {
        super.bringChildToFront(child);
    }

    public /* bridge */ /* synthetic */ void removeAllViews() {
        super.removeAllViews();
    }

    public /* bridge */ /* synthetic */ void removeView(View child) {
        super.removeView(child);
    }

    public NativeAdContentLayout(@NonNull Context context) {
        this(context, null);
    }

    public NativeAdContentLayout(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public NativeAdContentLayout(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.clickableViewRefs = new HashSet();
        this.titleViewId = -1;
        this.callToActionViewId = -1;
        this.ratingViewId = -1;
        this.descriptionViewId = -1;
        this.providerViewId = -1;
        this.iconViewId = -1;
        this.mediaViewId = -1;
        if (attrs == null) {
            return;
        }
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attrs, R.styleable.NativeAdContentLayout, defStyleAttr, 0);
        try {
            this.titleViewId = typedArrayObtainStyledAttributes.getResourceId(R.styleable.NativeAdContentLayout_titleViewId, -1);
            this.callToActionViewId = typedArrayObtainStyledAttributes.getResourceId(R.styleable.NativeAdContentLayout_callToActionViewId, -1);
            this.ratingViewId = typedArrayObtainStyledAttributes.getResourceId(R.styleable.NativeAdContentLayout_ratingViewId, -1);
            this.descriptionViewId = typedArrayObtainStyledAttributes.getResourceId(R.styleable.NativeAdContentLayout_descriptionViewId, -1);
            this.providerViewId = typedArrayObtainStyledAttributes.getResourceId(R.styleable.NativeAdContentLayout_providerViewId, -1);
            this.iconViewId = typedArrayObtainStyledAttributes.getResourceId(R.styleable.NativeAdContentLayout_iconViewId, -1);
            this.mediaViewId = typedArrayObtainStyledAttributes.getResourceId(R.styleable.NativeAdContentLayout_mediaViewId, -1);
            NativeAdContentLayout$.ExternalSyntheticApiModelOutline0.m(typedArrayObtainStyledAttributes);
        } catch (Throwable th) {
            if (typedArrayObtainStyledAttributes != null) {
                try {
                    NativeAdContentLayout$.ExternalSyntheticApiModelOutline0.m(typedArrayObtainStyledAttributes);
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onFinishInflate() {
        super/*android.view.View*/.onFinishInflate();
        setTitleView(findViewById(this.titleViewId));
        setCallToActionView(findViewById(this.callToActionViewId));
        setRatingView(findViewById(this.ratingViewId));
        setDescriptionView(findViewById(this.descriptionViewId));
        setProviderView(findViewById(this.providerViewId));
        setIconView(findViewById(this.iconViewId));
        setMediaView(findViewById(this.mediaViewId));
    }

    public void setTitleView(@Nullable View view) {
        this.titleView = view;
    }

    public void setCallToActionView(@Nullable View view) {
        this.callToActionView = view;
    }

    public void setRatingView(@Nullable View view) {
        this.ratingView = view;
    }

    public void setDescriptionView(@Nullable View view) {
        this.descriptionView = view;
    }

    public void setProviderView(@Nullable View view) {
        this.providerView = view;
    }

    public void setIconView(@Nullable View iconView) {
        this.iconView = iconView;
    }

    public void setMediaView(@Nullable NativeMediaView mediaView) {
        this.mediaView = mediaView;
    }

    @Nullable
    public View getTitleView() {
        return this.titleView;
    }

    @Nullable
    public View getCallToActionView() {
        return this.callToActionView;
    }

    @Nullable
    public View getRatingView() {
        return this.ratingView;
    }

    @Nullable
    public View getDescriptionView() {
        return this.descriptionView;
    }

    @Nullable
    public View getProviderView() {
        return this.providerView;
    }

    @Nullable
    public View getIconView() {
        return this.iconView;
    }

    @Nullable
    public NativeMediaView getMediaView() {
        return this.mediaView;
    }

    @NonNull
    public Set<View> getClickableViews() {
        HashSet hashSet = new HashSet();
        Iterator<WeakReference<View>> it = this.clickableViewRefs.iterator();
        while (it.hasNext()) {
            Utils.ifNotNull(it.next().get(), new NativeAdContentLayout$$ExternalSyntheticLambda1(hashSet));
        }
        return hashSet;
    }

    @NonNull
    private Set<View> getAllAvailableClickableViews() {
        final HashSet hashSet = new HashSet();
        Utils.ifNotNull(this.titleView, new NativeAdContentLayout$$ExternalSyntheticLambda1(hashSet));
        Utils.ifNotNull(this.callToActionView, new NativeAdContentLayout$$ExternalSyntheticLambda1(hashSet));
        Utils.ifNotNull(this.ratingView, new NativeAdContentLayout$$ExternalSyntheticLambda1(hashSet));
        Utils.ifNotNull(this.descriptionView, new NativeAdContentLayout$$ExternalSyntheticLambda1(hashSet));
        Utils.ifNotNull(this.providerView, new NativeAdContentLayout$$ExternalSyntheticLambda1(hashSet));
        Utils.ifNotNull(this.iconView, new NativeAdContentLayout$$ExternalSyntheticLambda1(hashSet));
        Utils.ifNotNull(this.mediaView, new Executable() { // from class: io.bidmachine.nativead.view.NativeAdContentLayout$$ExternalSyntheticLambda2
            public final void execute(Object obj) {
                hashSet.add((NativeMediaView) obj);
            }
        });
        return hashSet;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void bind(@Nullable NativeAd ad) {
        if (ad == null || !ad.isLoaded()) {
            return;
        }
        View view = this.titleView;
        if (view instanceof TextView) {
            ((TextView) view).setText(ad.getTitle());
        }
        View view2 = this.descriptionView;
        if (view2 instanceof TextView) {
            ((TextView) view2).setText(ad.getDescription());
        }
        View view3 = this.ratingView;
        if (view3 instanceof RatingBar) {
            RatingBar ratingBar = (RatingBar) view3;
            if (ad.getRating() == -1.0f) {
                ratingBar.setVisibility(4);
            } else {
                ratingBar.setVisibility(0);
                ratingBar.setStepSize(0.1f);
                ratingBar.setRating(ad.getRating());
            }
        }
        View view4 = this.callToActionView;
        if (view4 instanceof TextView) {
            ((TextView) view4).setText(ad.getCallToAction());
        }
        if (this.providerView instanceof ViewGroup) {
            View providerView = ad.getProviderView(getContext());
            if (providerView instanceof NativeAdOverlayContainer) {
                providerView.setVisibility(8);
            } else if (providerView != null) {
                ViewHelper.removeViewFromParent(providerView);
                ((ViewGroup) this.providerView).addView(providerView, new ViewGroup.LayoutParams(-2, -2));
            }
        }
        NativePublicData adData = ad.getAdData();
        if (adData instanceof NativeData) {
            ((NativeAdContainer) this).overlayContainer.bindNativeData((NativeData) adData);
        }
    }

    public void registerViewForInteraction(@Nullable NativeAd nativeAd) {
        registerViewForInteraction(nativeAd, getAllAvailableClickableViews());
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void registerViewForInteraction(@Nullable NativeAd nativeAd, @Nullable Set<View> clickableViews) {
        if (nativeAd == null || !nativeAd.isLoaded()) {
            Logger.d("Native ad is not loaded. Please load it before registering");
            return;
        }
        if (clickableViews == null) {
            clickableViews = Collections.emptySet();
        }
        if (clickableViews.isEmpty()) {
            Logger.w("'registerViewForInteraction' called with empty 'clickableViews' list, native ad won't be interactive");
        }
        HashSet hashSet = new HashSet();
        Iterator<View> it = clickableViews.iterator();
        while (it.hasNext()) {
            hashSet.add(new WeakReference(it.next()));
        }
        unregisterViewForInteraction();
        this.clickableViewRefs = hashSet;
        this.currentAd = nativeAd;
        nativeAd.registerView(this, getIconView(), getMediaView(), clickableViews);
    }

    public void unregisterViewForInteraction() {
        NativeAd nativeAd = this.currentAd;
        if (nativeAd != null) {
            nativeAd.unregisterView();
        }
    }

    public void destroy() {
        NativeAd nativeAd = this.currentAd;
        if (nativeAd != null) {
            nativeAd.destroy();
        }
    }

    public boolean isRegistered() {
        NativeAd nativeAd = this.currentAd;
        return nativeAd != null && nativeAd.isViewRegistered();
    }
}
