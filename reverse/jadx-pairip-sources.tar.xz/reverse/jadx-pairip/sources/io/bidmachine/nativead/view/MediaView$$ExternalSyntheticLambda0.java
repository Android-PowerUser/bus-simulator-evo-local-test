package io.bidmachine.nativead.view;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class MediaView$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ MediaView f$0;

    @Override // java.lang.Runnable
    public final void run() {
        MediaView.$r8$lambda$B60-Ptshj5JMKkcv4cr7rnjZnjg(this.f$0);
    }
}
