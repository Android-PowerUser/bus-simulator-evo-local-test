package io.bidmachine.nativead.tasks;

import android.net.Uri;
import io.bidmachine.iab.vast.VastRequest;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: DownloadVastVideoTask.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0010\u0004\u001a\u0010\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "Lkotlin/Pair;", "Landroid/net/Uri;", "Lio/bidmachine/iab/vast/VastRequest;", "<anonymous>"}, k = 3, mv = {1, 7, 1})
@DebugMetadata(c = "io.bidmachine.nativead.tasks.DownloadVastVideoTask$run$1$result$1", f = "DownloadVastVideoTask.kt", i = {}, l = {35}, m = "invokeSuspend", n = {}, s = {})
final class DownloadVastVideoTask$run$1$result$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Pair<? extends Uri, ? extends VastRequest>>, Object> {
    int label;
    final /* synthetic */ DownloadVastVideoTask this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    DownloadVastVideoTask$run$1$result$1(DownloadVastVideoTask downloadVastVideoTask, Continuation<? super DownloadVastVideoTask$run$1$result$1> continuation) {
        super(2, continuation);
        this.this$0 = downloadVastVideoTask;
    }

    @NotNull
    public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
        return new DownloadVastVideoTask$run$1$result$1(this.this$0, continuation);
    }

    @Nullable
    public final Object invoke(@NotNull CoroutineScope coroutineScope, @Nullable Continuation<? super Pair<? extends Uri, ? extends VastRequest>> continuation) {
        return ((DownloadVastVideoTask$run$1$result$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Nullable
    public final Object invokeSuspend(@NotNull Object obj) throws Throwable {
        Object obj2;
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i == 0) {
            ResultKt.throwOnFailure(obj);
            DownloadVastVideoTask downloadVastVideoTask = this.this$0;
            this.label = 1;
            obj2 = downloadVastVideoTask.execute-IoAF18A(this);
            if (obj2 == coroutine_suspended) {
                return coroutine_suspended;
            }
        } else {
            if (i != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            obj2 = ((Result) obj).unbox-impl();
        }
        if (Result.isFailure-impl(obj2)) {
            return null;
        }
        return obj2;
    }
}
