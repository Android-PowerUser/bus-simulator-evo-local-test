package io.bidmachine.media3.exoplayer.drm;

import com.google.common.util.concurrent.SettableFuture;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class OfflineLicenseHelper$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ OfflineLicenseHelper f$0;
    public final /* synthetic */ DrmSession f$1;
    public final /* synthetic */ SettableFuture f$2;

    public /* synthetic */ OfflineLicenseHelper$$ExternalSyntheticLambda1(OfflineLicenseHelper offlineLicenseHelper, DrmSession drmSession, SettableFuture settableFuture) {
        this.f$0 = offlineLicenseHelper;
        this.f$1 = drmSession;
        this.f$2 = settableFuture;
    }

    @Override // java.lang.Runnable
    public final void run() {
        OfflineLicenseHelper.$r8$lambda$mDE5Vxojv1x2aFUzQ5DGeP4wYCo(this.f$0, this.f$1, this.f$2);
    }
}
