package io.bidmachine.media3.exoplayer.audio;

import android.media.AudioTrack;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class DefaultAudioSink$StreamEventCallbackV29$1 extends AudioTrack.StreamEventCallback {
    final /* synthetic */ DefaultAudioSink.StreamEventCallbackV29 this$1;
    final /* synthetic */ DefaultAudioSink val$this$0;

    DefaultAudioSink$StreamEventCallbackV29$1(DefaultAudioSink.StreamEventCallbackV29 streamEventCallbackV29, DefaultAudioSink defaultAudioSink) {
        this.this$1 = streamEventCallbackV29;
        this.val$this$0 = defaultAudioSink;
    }

    @Override // android.media.AudioTrack.StreamEventCallback
    public void onDataRequest(AudioTrack audioTrack, int i) {
        if (audioTrack.equals(DefaultAudioSink.access$1200(this.this$1.this$0)) && DefaultAudioSink.access$1300(this.this$1.this$0) != null && DefaultAudioSink.access$1400(this.this$1.this$0)) {
            DefaultAudioSink.access$1300(this.this$1.this$0).onOffloadBufferEmptying();
        }
    }

    @Override // android.media.AudioTrack.StreamEventCallback
    public void onPresentationEnded(AudioTrack audioTrack) {
        if (audioTrack.equals(DefaultAudioSink.access$1200(this.this$1.this$0))) {
            DefaultAudioSink.access$1502(this.this$1.this$0, true);
        }
    }

    @Override // android.media.AudioTrack.StreamEventCallback
    public void onTearDown(AudioTrack audioTrack) {
        if (audioTrack.equals(DefaultAudioSink.access$1200(this.this$1.this$0)) && DefaultAudioSink.access$1300(this.this$1.this$0) != null && DefaultAudioSink.access$1400(this.this$1.this$0)) {
            DefaultAudioSink.access$1300(this.this$1.this$0).onOffloadBufferEmptying();
        }
    }
}
