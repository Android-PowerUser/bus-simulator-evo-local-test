package io.bidmachine.media3.exoplayer.dash;

import io.bidmachine.media3.common.util.UnstableApi;
import io.bidmachine.media3.exoplayer.dash.manifest.RangedUri;
import io.bidmachine.media3.extractor.ChunkIndex;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@UnstableApi
public final class DashWrappingSegmentIndex implements DashSegmentIndex {
    private final ChunkIndex chunkIndex;
    private final long timeOffsetUs;

    public long getFirstAvailableSegmentNum(long j, long j2) {
        return 0L;
    }

    public long getFirstSegmentNum() {
        return 0L;
    }

    public long getNextSegmentAvailableTimeUs(long j, long j2) {
        return -9223372036854775807L;
    }

    public boolean isExplicit() {
        return true;
    }

    public DashWrappingSegmentIndex(ChunkIndex chunkIndex, long j) {
        this.chunkIndex = chunkIndex;
        this.timeOffsetUs = j;
    }

    public long getSegmentCount(long j) {
        return this.chunkIndex.length;
    }

    public long getAvailableSegmentCount(long j, long j2) {
        return this.chunkIndex.length;
    }

    public long getTimeUs(long j) {
        return this.chunkIndex.timesUs[(int) j] - this.timeOffsetUs;
    }

    public long getDurationUs(long j, long j2) {
        return this.chunkIndex.durationsUs[(int) j];
    }

    public RangedUri getSegmentUrl(long j) {
        ChunkIndex chunkIndex = this.chunkIndex;
        int i = (int) j;
        return new RangedUri((String) null, chunkIndex.offsets[i], chunkIndex.sizes[i]);
    }

    public long getSegmentNum(long j, long j2) {
        return this.chunkIndex.getChunkIndex(j + this.timeOffsetUs);
    }
}
