package io.bidmachine.media3.exoplayer.hls;

import android.net.Uri;
import java.util.LinkedHashMap;
import java.util.Map;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class FullSegmentEncryptionKeyCache$1 extends LinkedHashMap<Uri, byte[]> {
    final /* synthetic */ FullSegmentEncryptionKeyCache this$0;
    final /* synthetic */ int val$maxSize;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    FullSegmentEncryptionKeyCache$1(FullSegmentEncryptionKeyCache fullSegmentEncryptionKeyCache, int i, float f, boolean z, int i2) {
        super(i, f, z);
        this.this$0 = fullSegmentEncryptionKeyCache;
        this.val$maxSize = i2;
    }

    @Override // java.util.LinkedHashMap
    protected boolean removeEldestEntry(Map.Entry<Uri, byte[]> entry) {
        return size() > this.val$maxSize;
    }
}
