package io.bidmachine.media3.extractor.text.webvtt;

import java.util.Comparator;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class WebvttSubtitle$$ExternalSyntheticLambda0 implements Comparator {
    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        return WebvttSubtitle.$r8$lambda$thH90I4ObUIon-oqFoXePiuktf8((WebvttCueInfo) obj, (WebvttCueInfo) obj2);
    }
}
