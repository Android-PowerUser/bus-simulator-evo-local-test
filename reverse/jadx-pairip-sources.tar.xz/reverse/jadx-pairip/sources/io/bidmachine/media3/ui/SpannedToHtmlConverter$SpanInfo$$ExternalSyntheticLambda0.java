package io.bidmachine.media3.ui;

import java.util.Comparator;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class SpannedToHtmlConverter$SpanInfo$$ExternalSyntheticLambda0 implements Comparator {
    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        return SpannedToHtmlConverter.SpanInfo.$r8$lambda$A3xOWjdGdnwwzyAH_3Pw5IaGbNk((SpannedToHtmlConverter.SpanInfo) obj, (SpannedToHtmlConverter.SpanInfo) obj2);
    }
}
