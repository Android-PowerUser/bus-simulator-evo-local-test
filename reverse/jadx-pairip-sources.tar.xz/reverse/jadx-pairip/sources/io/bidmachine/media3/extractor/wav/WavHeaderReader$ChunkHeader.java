package io.bidmachine.media3.extractor.wav;

import io.bidmachine.media3.common.util.ParsableByteArray;
import io.bidmachine.media3.extractor.ExtractorInput;
import java.io.IOException;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class WavHeaderReader$ChunkHeader {
    public static final int SIZE_IN_BYTES = 8;
    public final int id;
    public final long size;

    private WavHeaderReader$ChunkHeader(int i, long j) {
        this.id = i;
        this.size = j;
    }

    public static WavHeaderReader$ChunkHeader peek(ExtractorInput extractorInput, ParsableByteArray parsableByteArray) throws IOException {
        extractorInput.peekFully(parsableByteArray.getData(), 0, 8);
        parsableByteArray.setPosition(0);
        return new WavHeaderReader$ChunkHeader(parsableByteArray.readInt(), parsableByteArray.readLittleEndianUnsignedInt());
    }
}
