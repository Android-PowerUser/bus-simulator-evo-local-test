package io.bidmachine.media3.database;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class R {
    private R() {
    }
}
