package io.bidmachine.media3.ui;

import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class PlayerControlViewLayoutManager$$ExternalSyntheticLambda10 implements View.OnClickListener {
    public final /* synthetic */ PlayerControlViewLayoutManager f$0;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        PlayerControlViewLayoutManager.$r8$lambda$d4-TMDGHO3IOVJIYakEi3SJFVso(this.f$0, view);
    }
}
