package io.bidmachine.media3.exoplayer.source.ads;

import io.bidmachine.media3.decoder.DecoderInputBuffer;
import io.bidmachine.media3.exoplayer.FormatHolder;
import io.bidmachine.media3.exoplayer.source.SampleStream;
import java.io.IOException;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class ServerSideAdInsertionMediaSource$SampleStreamImpl implements SampleStream {
    private final ServerSideAdInsertionMediaSource.MediaPeriodImpl mediaPeriod;
    private final int streamIndex;

    public ServerSideAdInsertionMediaSource$SampleStreamImpl(ServerSideAdInsertionMediaSource.MediaPeriodImpl mediaPeriodImpl, int i) {
        this.mediaPeriod = mediaPeriodImpl;
        this.streamIndex = i;
    }

    public boolean isReady() {
        return this.mediaPeriod.sharedPeriod.isReady(this.streamIndex);
    }

    public void maybeThrowError() throws IOException {
        this.mediaPeriod.sharedPeriod.maybeThrowError(this.streamIndex);
    }

    public int readData(FormatHolder formatHolder, DecoderInputBuffer decoderInputBuffer, int i) {
        ServerSideAdInsertionMediaSource.MediaPeriodImpl mediaPeriodImpl = this.mediaPeriod;
        return mediaPeriodImpl.sharedPeriod.readData(mediaPeriodImpl, this.streamIndex, formatHolder, decoderInputBuffer, i);
    }

    public int skipData(long j) {
        ServerSideAdInsertionMediaSource.MediaPeriodImpl mediaPeriodImpl = this.mediaPeriod;
        return mediaPeriodImpl.sharedPeriod.skipData(mediaPeriodImpl, this.streamIndex, j);
    }
}
