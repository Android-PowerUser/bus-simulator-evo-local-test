package io.bidmachine.media3.ui;

import android.app.Notification;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface PlayerNotificationManager$NotificationListener {
    default void onNotificationCancelled(int i, boolean z) {
    }

    default void onNotificationPosted(int i, Notification notification, boolean z) {
    }
}
