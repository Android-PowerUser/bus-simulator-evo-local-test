package io.bidmachine.media3.exoplayer.upstream;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import androidx.annotation.Nullable;
import io.bidmachine.media3.common.util.Assertions;
import io.bidmachine.media3.common.util.Log;
import io.bidmachine.media3.common.util.TraceUtil;
import io.bidmachine.media3.exoplayer.upstream.Loader.Loadable;
import java.io.IOException;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@SuppressLint({"HandlerLeak"})
public final class Loader$LoadTask<T extends Loader.Loadable> extends Handler implements Runnable {
    private static final int MSG_FATAL_ERROR = 4;
    private static final int MSG_FINISH = 2;
    private static final int MSG_IO_EXCEPTION = 3;
    private static final int MSG_START = 1;
    private static final String TAG = "LoadTask";

    @Nullable
    private Loader.Callback<T> callback;
    private boolean canceled;

    @Nullable
    private IOException currentError;
    public final int defaultMinRetryCount;
    private int errorCount;

    @Nullable
    private Thread executorThread;
    private final T loadable;
    private volatile boolean released;
    private final long startTimeMs;
    final /* synthetic */ Loader this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Loader$LoadTask(Loader loader, Looper looper, T t, Loader.Callback<T> callback, int i, long j) {
        super(looper);
        this.this$0 = loader;
        this.loadable = t;
        this.callback = callback;
        this.defaultMinRetryCount = i;
        this.startTimeMs = j;
    }

    public void maybeThrowError(int i) throws IOException {
        IOException iOException = this.currentError;
        if (iOException != null && this.errorCount > i) {
            throw iOException;
        }
    }

    public void start(long j) {
        Assertions.checkState(Loader.access$100(this.this$0) == null);
        Loader.access$102(this.this$0, this);
        if (j > 0) {
            sendEmptyMessageDelayed(1, j);
        } else {
            execute();
        }
    }

    public void cancel(boolean z) {
        this.released = z;
        this.currentError = null;
        if (hasMessages(1)) {
            this.canceled = true;
            removeMessages(1);
            if (!z) {
                sendEmptyMessage(2);
            }
        } else {
            synchronized (this) {
                this.canceled = true;
                this.loadable.cancelLoad();
                Thread thread = this.executorThread;
                if (thread != null) {
                    thread.interrupt();
                }
            }
        }
        if (z) {
            finish();
            long jElapsedRealtime = SystemClock.elapsedRealtime();
            ((Loader.Callback) Assertions.checkNotNull(this.callback)).onLoadCanceled(this.loadable, jElapsedRealtime, jElapsedRealtime - this.startTimeMs, true);
            this.callback = null;
        }
    }

    @Override // java.lang.Runnable
    public void run() {
        boolean z;
        try {
            synchronized (this) {
                z = !this.canceled;
                this.executorThread = Thread.currentThread();
            }
            if (z) {
                TraceUtil.beginSection("load:" + this.loadable.getClass().getSimpleName());
                try {
                    this.loadable.load();
                    TraceUtil.endSection();
                } catch (Throwable th) {
                    TraceUtil.endSection();
                    throw th;
                }
            }
            synchronized (this) {
                this.executorThread = null;
                Thread.interrupted();
            }
            if (this.released) {
                return;
            }
            sendEmptyMessage(2);
        } catch (IOException e) {
            if (this.released) {
                return;
            }
            obtainMessage(3, e).sendToTarget();
        } catch (Error e2) {
            if (!this.released) {
                Log.e(TAG, "Unexpected error loading stream", e2);
                obtainMessage(4, e2).sendToTarget();
            }
            throw e2;
        } catch (Exception e3) {
            if (this.released) {
                return;
            }
            Log.e(TAG, "Unexpected exception loading stream", e3);
            obtainMessage(3, new Loader$UnexpectedLoaderException(e3)).sendToTarget();
        } catch (OutOfMemoryError e4) {
            if (this.released) {
                return;
            }
            Log.e(TAG, "OutOfMemory error loading stream", e4);
            obtainMessage(3, new Loader$UnexpectedLoaderException(e4)).sendToTarget();
        }
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        long retryDelayMillis;
        if (this.released) {
            return;
        }
        int i = message.what;
        if (i == 1) {
            execute();
            return;
        }
        if (i == 4) {
            throw ((Error) message.obj);
        }
        finish();
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        long j = jElapsedRealtime - this.startTimeMs;
        Loader.Callback callback = (Loader.Callback) Assertions.checkNotNull(this.callback);
        if (this.canceled) {
            callback.onLoadCanceled(this.loadable, jElapsedRealtime, j, false);
            return;
        }
        int i2 = message.what;
        if (i2 == 2) {
            try {
                callback.onLoadCompleted(this.loadable, jElapsedRealtime, j);
                return;
            } catch (RuntimeException e) {
                Log.e(TAG, "Unexpected exception handling load completed", e);
                Loader.access$202(this.this$0, new Loader$UnexpectedLoaderException(e));
                return;
            }
        }
        if (i2 != 3) {
            return;
        }
        IOException iOException = (IOException) message.obj;
        this.currentError = iOException;
        int i3 = this.errorCount + 1;
        this.errorCount = i3;
        Loader.LoadErrorAction loadErrorActionOnLoadError = callback.onLoadError(this.loadable, jElapsedRealtime, j, iOException, i3);
        if (Loader.LoadErrorAction.access$300(loadErrorActionOnLoadError) == 3) {
            Loader.access$202(this.this$0, this.currentError);
            return;
        }
        if (Loader.LoadErrorAction.access$300(loadErrorActionOnLoadError) != 2) {
            if (Loader.LoadErrorAction.access$300(loadErrorActionOnLoadError) == 1) {
                this.errorCount = 1;
            }
            if (Loader.LoadErrorAction.access$400(loadErrorActionOnLoadError) != -9223372036854775807L) {
                retryDelayMillis = Loader.LoadErrorAction.access$400(loadErrorActionOnLoadError);
            } else {
                retryDelayMillis = getRetryDelayMillis();
            }
            start(retryDelayMillis);
        }
    }

    private void execute() {
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        ((Loader.Callback) Assertions.checkNotNull(this.callback)).onLoadStarted(this.loadable, jElapsedRealtime, jElapsedRealtime - this.startTimeMs, this.errorCount);
        this.currentError = null;
        Loader.access$500(this.this$0).execute((Runnable) Assertions.checkNotNull(Loader.access$100(this.this$0)));
    }

    private void finish() {
        Loader.access$102(this.this$0, (Loader$LoadTask) null);
    }

    private long getRetryDelayMillis() {
        return Math.min((this.errorCount - 1) * 1000, 5000);
    }
}
