package io.bidmachine.media3.exoplayer.source.preload;

import android.content.Context;
import com.google.common.base.Supplier;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class DefaultPreloadManager$Builder$$ExternalSyntheticLambda3 implements Supplier {
    public final /* synthetic */ Context f$0;

    public final Object get() {
        return DefaultPreloadManager.Builder.$r8$lambda$PCd7ypL4eT5-ConCEBJ28M9N4BE(this.f$0);
    }
}
