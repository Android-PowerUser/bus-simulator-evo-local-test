package io.bidmachine.media3.exoplayer.hls;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class R$color {
    public static final int androidx_core_ripple_material_light = 2131099674;
    public static final int androidx_core_secondary_text_default_material_light = 2131099675;
    public static final int notification_action_color_filter = 2131099880;
    public static final int notification_icon_bg_color = 2131099881;

    private R$color() {
    }
}
