package io.bidmachine.media3.datasource;

import java.util.concurrent.Callable;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class DataSourceBitmapLoader$$ExternalSyntheticLambda1 implements Callable {
    public final /* synthetic */ DataSourceBitmapLoader f$0;
    public final /* synthetic */ byte[] f$1;

    public /* synthetic */ DataSourceBitmapLoader$$ExternalSyntheticLambda1(DataSourceBitmapLoader dataSourceBitmapLoader, byte[] bArr) {
        this.f$0 = dataSourceBitmapLoader;
        this.f$1 = bArr;
    }

    @Override // java.util.concurrent.Callable
    public final Object call() {
        return DataSourceBitmapLoader.$r8$lambda$ZwKfJsWI56XdtIy5SnLKmJjYPhU(this.f$0, this.f$1);
    }
}
