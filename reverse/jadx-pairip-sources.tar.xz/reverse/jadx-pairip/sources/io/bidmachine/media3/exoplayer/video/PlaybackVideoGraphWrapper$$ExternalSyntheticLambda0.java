package io.bidmachine.media3.exoplayer.video;

import java.util.concurrent.Executor;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class PlaybackVideoGraphWrapper$$ExternalSyntheticLambda0 implements Executor {
    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        PlaybackVideoGraphWrapper.$r8$lambda$8uCXMbcHIc3RMcZTaxG1X2fJQEU(runnable);
    }
}
