package io.bidmachine.media3.datasource;

import com.google.common.base.Supplier;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class DataSourceBitmapLoader$$ExternalSyntheticLambda2 implements Supplier {
    public final Object get() {
        return DataSourceBitmapLoader.$r8$lambda$jm_W7itBXi71P3ISMf5EIStMxqM();
    }
}
