package io.bidmachine.media3.exoplayer.drm;

import com.google.common.util.concurrent.SettableFuture;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class OfflineLicenseHelper$$ExternalSyntheticLambda4 implements Runnable {
    public final /* synthetic */ OfflineLicenseHelper f$0;
    public final /* synthetic */ SettableFuture f$1;
    public final /* synthetic */ DrmSession f$2;

    public /* synthetic */ OfflineLicenseHelper$$ExternalSyntheticLambda4(OfflineLicenseHelper offlineLicenseHelper, SettableFuture settableFuture, DrmSession drmSession) {
        this.f$0 = offlineLicenseHelper;
        this.f$1 = settableFuture;
        this.f$2 = drmSession;
    }

    @Override // java.lang.Runnable
    public final void run() {
        OfflineLicenseHelper.$r8$lambda$xd-A9odlGzjBA0RUdiEL-bgv1GU(this.f$0, this.f$1, this.f$2);
    }
}
