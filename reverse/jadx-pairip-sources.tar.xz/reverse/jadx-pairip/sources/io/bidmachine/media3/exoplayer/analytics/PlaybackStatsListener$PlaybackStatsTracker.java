package io.bidmachine.media3.exoplayer.analytics;

import android.os.SystemClock;
import androidx.annotation.Nullable;
import io.bidmachine.media3.common.Format;
import io.bidmachine.media3.common.PlaybackException;
import io.bidmachine.media3.common.Player;
import io.bidmachine.media3.common.Tracks;
import io.bidmachine.media3.common.VideoSize;
import io.bidmachine.media3.common.util.Assertions;
import io.bidmachine.media3.exoplayer.source.MediaSource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class PlaybackStatsListener$PlaybackStatsTracker {
    private long audioFormatBitrateTimeProduct;
    private final List<PlaybackStats.EventTimeAndFormat> audioFormatHistory;
    private long audioFormatTimeMs;
    private long audioUnderruns;
    private long bandwidthBytes;
    private long bandwidthTimeMs;

    @Nullable
    private Format currentAudioFormat;
    private float currentPlaybackSpeed;
    private int currentPlaybackState;
    private long currentPlaybackStateStartTimeMs;

    @Nullable
    private Format currentVideoFormat;
    private long droppedFrames;
    private int fatalErrorCount;
    private final List<PlaybackStats.EventTimeAndException> fatalErrorHistory;
    private long firstReportedTimeMs;
    private boolean hasBeenReady;
    private boolean hasEnded;
    private boolean hasFatalError;
    private long initialAudioFormatBitrate;
    private long initialVideoFormatBitrate;
    private int initialVideoFormatHeight;
    private final boolean isAd;
    private boolean isForeground;
    private boolean isInterruptedByAd;
    private boolean isJoinTimeInvalid;
    private boolean isSeeking;
    private final boolean keepHistory;
    private long lastAudioFormatStartTimeMs;
    private long lastRebufferStartTimeMs;
    private long lastVideoFormatStartTimeMs;
    private long maxRebufferTimeMs;
    private final List<long[]> mediaTimeHistory;
    private int nonFatalErrorCount;
    private final List<PlaybackStats.EventTimeAndException> nonFatalErrorHistory;
    private int pauseBufferCount;
    private int pauseCount;
    private final long[] playbackStateDurationsMs = new long[16];
    private final List<PlaybackStats.EventTimeAndPlaybackState> playbackStateHistory;
    private int rebufferCount;
    private int seekCount;
    private boolean startedLoading;
    private long videoFormatBitrateTimeMs;
    private long videoFormatBitrateTimeProduct;
    private long videoFormatHeightTimeMs;
    private long videoFormatHeightTimeProduct;
    private final List<PlaybackStats.EventTimeAndFormat> videoFormatHistory;

    private static boolean isInvalidJoinTransition(int i, int i2) {
        return ((i != 1 && i != 2 && i != 14) || i2 == 1 || i2 == 2 || i2 == 14 || i2 == 3 || i2 == 4 || i2 == 9 || i2 == 11) ? false : true;
    }

    private static boolean isPausedState(int i) {
        return i == 4 || i == 7;
    }

    private static boolean isReadyState(int i) {
        return i == 3 || i == 4 || i == 9;
    }

    private static boolean isRebufferingState(int i) {
        return i == 6 || i == 7 || i == 10;
    }

    public PlaybackStatsListener$PlaybackStatsTracker(boolean z, AnalyticsListener.EventTime eventTime) {
        this.keepHistory = z;
        this.playbackStateHistory = z ? new ArrayList<>() : Collections.emptyList();
        this.mediaTimeHistory = z ? new ArrayList<>() : Collections.emptyList();
        this.videoFormatHistory = z ? new ArrayList<>() : Collections.emptyList();
        this.audioFormatHistory = z ? new ArrayList<>() : Collections.emptyList();
        this.fatalErrorHistory = z ? new ArrayList<>() : Collections.emptyList();
        this.nonFatalErrorHistory = z ? new ArrayList<>() : Collections.emptyList();
        boolean z2 = false;
        this.currentPlaybackState = 0;
        this.currentPlaybackStateStartTimeMs = eventTime.realtimeMs;
        this.firstReportedTimeMs = -9223372036854775807L;
        this.maxRebufferTimeMs = -9223372036854775807L;
        MediaSource.MediaPeriodId mediaPeriodId = eventTime.mediaPeriodId;
        if (mediaPeriodId != null && mediaPeriodId.isAd()) {
            z2 = true;
        }
        this.isAd = z2;
        this.initialAudioFormatBitrate = -1L;
        this.initialVideoFormatBitrate = -1L;
        this.initialVideoFormatHeight = -1;
        this.currentPlaybackSpeed = 1.0f;
    }

    public void onForeground() {
        this.isForeground = true;
    }

    public void onInterruptedByAd() {
        this.isInterruptedByAd = true;
        this.isSeeking = false;
    }

    public void onFinished(AnalyticsListener.EventTime eventTime, boolean z, long j) {
        int i = 11;
        if (this.currentPlaybackState != 11 && !z) {
            i = 15;
        }
        maybeUpdateMediaTimeHistory(eventTime.realtimeMs, j);
        maybeRecordVideoFormatTime(eventTime.realtimeMs);
        maybeRecordAudioFormatTime(eventTime.realtimeMs);
        updatePlaybackState(i, eventTime);
    }

    public void onEvents(Player player, AnalyticsListener.EventTime eventTime, boolean z, long j, boolean z2, int i, boolean z3, boolean z4, @Nullable PlaybackException playbackException, @Nullable Exception exc, long j2, long j3, @Nullable Format format, @Nullable Format format2, @Nullable VideoSize videoSize) {
        if (j != -9223372036854775807L) {
            maybeUpdateMediaTimeHistory(eventTime.realtimeMs, j);
            this.isSeeking = true;
        }
        if (player.getPlaybackState() != 2) {
            this.isSeeking = false;
        }
        int playbackState = player.getPlaybackState();
        if (playbackState == 1 || playbackState == 4 || z2) {
            this.isInterruptedByAd = false;
        }
        if (playbackException != null) {
            this.hasFatalError = true;
            this.fatalErrorCount++;
            if (this.keepHistory) {
                this.fatalErrorHistory.add(new PlaybackStats.EventTimeAndException(eventTime, playbackException));
            }
        } else if (player.getPlayerError() == null) {
            this.hasFatalError = false;
        }
        if (this.isForeground && !this.isInterruptedByAd) {
            Tracks currentTracks = player.getCurrentTracks();
            if (!currentTracks.isTypeSelected(2)) {
                maybeUpdateVideoFormat(eventTime, null);
            }
            if (!currentTracks.isTypeSelected(1)) {
                maybeUpdateAudioFormat(eventTime, null);
            }
        }
        if (format != null) {
            maybeUpdateVideoFormat(eventTime, format);
        }
        if (format2 != null) {
            maybeUpdateAudioFormat(eventTime, format2);
        }
        Format format3 = this.currentVideoFormat;
        if (format3 != null && format3.height == -1 && videoSize != null) {
            maybeUpdateVideoFormat(eventTime, format3.buildUpon().setWidth(videoSize.width).setHeight(videoSize.height).build());
        }
        if (z4) {
            this.startedLoading = true;
        }
        if (z3) {
            this.audioUnderruns++;
        }
        this.droppedFrames += (long) i;
        this.bandwidthTimeMs += j2;
        this.bandwidthBytes += j3;
        if (exc != null) {
            this.nonFatalErrorCount++;
            if (this.keepHistory) {
                this.nonFatalErrorHistory.add(new PlaybackStats.EventTimeAndException(eventTime, exc));
            }
        }
        int iResolveNewPlaybackState = resolveNewPlaybackState(player);
        float f = player.getPlaybackParameters().speed;
        if (this.currentPlaybackState != iResolveNewPlaybackState || this.currentPlaybackSpeed != f) {
            maybeUpdateMediaTimeHistory(eventTime.realtimeMs, z ? eventTime.eventPlaybackPositionMs : -9223372036854775807L);
            maybeRecordVideoFormatTime(eventTime.realtimeMs);
            maybeRecordAudioFormatTime(eventTime.realtimeMs);
        }
        this.currentPlaybackSpeed = f;
        if (this.currentPlaybackState != iResolveNewPlaybackState) {
            updatePlaybackState(iResolveNewPlaybackState, eventTime);
        }
    }

    public PlaybackStats build(boolean z) {
        long[] jArr;
        List<long[]> list;
        long[] jArr2 = this.playbackStateDurationsMs;
        List<long[]> list2 = this.mediaTimeHistory;
        if (z) {
            jArr = jArr2;
            list = list2;
        } else {
            long jElapsedRealtime = SystemClock.elapsedRealtime();
            long[] jArrCopyOf = Arrays.copyOf(this.playbackStateDurationsMs, 16);
            long jMax = Math.max(0L, jElapsedRealtime - this.currentPlaybackStateStartTimeMs);
            int i = this.currentPlaybackState;
            jArrCopyOf[i] = jArrCopyOf[i] + jMax;
            maybeUpdateMaxRebufferTimeMs(jElapsedRealtime);
            maybeRecordVideoFormatTime(jElapsedRealtime);
            maybeRecordAudioFormatTime(jElapsedRealtime);
            ArrayList arrayList = new ArrayList(this.mediaTimeHistory);
            if (this.keepHistory && this.currentPlaybackState == 3) {
                arrayList.add(guessMediaTimeBasedOnElapsedRealtime(jElapsedRealtime));
            }
            jArr = jArrCopyOf;
            list = arrayList;
        }
        int i2 = (this.isJoinTimeInvalid || !this.hasBeenReady) ? 1 : 0;
        long j = i2 != 0 ? -9223372036854775807L : jArr[2];
        int i3 = jArr[1] > 0 ? 1 : 0;
        List arrayList2 = z ? this.videoFormatHistory : new ArrayList(this.videoFormatHistory);
        List arrayList3 = z ? this.audioFormatHistory : new ArrayList(this.audioFormatHistory);
        List arrayList4 = z ? this.playbackStateHistory : new ArrayList(this.playbackStateHistory);
        long j2 = this.firstReportedTimeMs;
        boolean z2 = this.isForeground;
        int i4 = !this.hasBeenReady ? 1 : 0;
        boolean z3 = this.hasEnded;
        int i5 = i2 ^ 1;
        int i6 = this.pauseCount;
        int i7 = this.pauseBufferCount;
        int i8 = this.seekCount;
        int i9 = this.rebufferCount;
        long j3 = this.maxRebufferTimeMs;
        boolean z4 = this.isAd;
        long[] jArr3 = jArr;
        long j4 = this.videoFormatHeightTimeMs;
        long j5 = this.videoFormatHeightTimeProduct;
        long j6 = this.videoFormatBitrateTimeMs;
        long j7 = this.videoFormatBitrateTimeProduct;
        long j8 = this.audioFormatTimeMs;
        long j9 = this.audioFormatBitrateTimeProduct;
        int i10 = this.initialVideoFormatHeight;
        int i11 = i10 == -1 ? 0 : 1;
        long j10 = this.initialVideoFormatBitrate;
        int i12 = j10 == -1 ? 0 : 1;
        long j11 = this.initialAudioFormatBitrate;
        int i13 = j11 == -1 ? 0 : 1;
        long j12 = this.bandwidthTimeMs;
        long j13 = this.bandwidthBytes;
        long j14 = this.droppedFrames;
        long j15 = this.audioUnderruns;
        int i14 = this.fatalErrorCount;
        return new PlaybackStats(1, jArr3, arrayList4, list, j2, z2 ? 1 : 0, i4, z3 ? 1 : 0, i3, j, i5, i6, i7, i8, i9, j3, z4 ? 1 : 0, arrayList2, arrayList3, j4, j5, j6, j7, j8, j9, i11, i12, i10, j10, i13, j11, j12, j13, j14, j15, i14 > 0 ? 1 : 0, i14, this.nonFatalErrorCount, this.fatalErrorHistory, this.nonFatalErrorHistory);
    }

    private void updatePlaybackState(int i, AnalyticsListener.EventTime eventTime) {
        Assertions.checkArgument(eventTime.realtimeMs >= this.currentPlaybackStateStartTimeMs);
        long j = eventTime.realtimeMs;
        long j2 = j - this.currentPlaybackStateStartTimeMs;
        long[] jArr = this.playbackStateDurationsMs;
        int i2 = this.currentPlaybackState;
        jArr[i2] = jArr[i2] + j2;
        if (this.firstReportedTimeMs == -9223372036854775807L) {
            this.firstReportedTimeMs = j;
        }
        this.isJoinTimeInvalid |= isInvalidJoinTransition(i2, i);
        this.hasBeenReady |= isReadyState(i);
        this.hasEnded |= i == 11;
        if (!isPausedState(this.currentPlaybackState) && isPausedState(i)) {
            this.pauseCount++;
        }
        if (i == 5) {
            this.seekCount++;
        }
        if (!isRebufferingState(this.currentPlaybackState) && isRebufferingState(i)) {
            this.rebufferCount++;
            this.lastRebufferStartTimeMs = eventTime.realtimeMs;
        }
        if (isRebufferingState(this.currentPlaybackState) && this.currentPlaybackState != 7 && i == 7) {
            this.pauseBufferCount++;
        }
        maybeUpdateMaxRebufferTimeMs(eventTime.realtimeMs);
        this.currentPlaybackState = i;
        this.currentPlaybackStateStartTimeMs = eventTime.realtimeMs;
        if (this.keepHistory) {
            this.playbackStateHistory.add(new PlaybackStats.EventTimeAndPlaybackState(eventTime, i));
        }
    }

    private int resolveNewPlaybackState(Player player) {
        int playbackState = player.getPlaybackState();
        if (this.isSeeking && this.isForeground) {
            return 5;
        }
        if (this.hasFatalError) {
            return 13;
        }
        if (!this.isForeground) {
            return this.startedLoading ? 1 : 0;
        }
        if (this.isInterruptedByAd) {
            return 14;
        }
        if (playbackState == 4) {
            return 11;
        }
        if (playbackState != 2) {
            if (playbackState == 3) {
                if (player.getPlayWhenReady()) {
                    return player.getPlaybackSuppressionReason() != 0 ? 9 : 3;
                }
                return 4;
            }
            if (playbackState != 1 || this.currentPlaybackState == 0) {
                return this.currentPlaybackState;
            }
            return 12;
        }
        int i = this.currentPlaybackState;
        if (i == 0 || i == 1 || i == 2 || i == 14) {
            return 2;
        }
        if (player.getPlayWhenReady()) {
            return player.getPlaybackSuppressionReason() != 0 ? 10 : 6;
        }
        return 7;
    }

    private void maybeUpdateMaxRebufferTimeMs(long j) {
        if (isRebufferingState(this.currentPlaybackState)) {
            long j2 = j - this.lastRebufferStartTimeMs;
            long j3 = this.maxRebufferTimeMs;
            if (j3 == -9223372036854775807L || j2 > j3) {
                this.maxRebufferTimeMs = j2;
            }
        }
    }

    private void maybeUpdateMediaTimeHistory(long j, long j2) {
        if (this.keepHistory) {
            if (this.currentPlaybackState != 3) {
                if (j2 == -9223372036854775807L) {
                    return;
                }
                if (!this.mediaTimeHistory.isEmpty()) {
                    List<long[]> list = this.mediaTimeHistory;
                    long j3 = list.get(list.size() - 1)[1];
                    if (j3 != j2) {
                        this.mediaTimeHistory.add(new long[]{j, j3});
                    }
                }
            }
            if (j2 != -9223372036854775807L) {
                this.mediaTimeHistory.add(new long[]{j, j2});
            } else {
                if (this.mediaTimeHistory.isEmpty()) {
                    return;
                }
                this.mediaTimeHistory.add(guessMediaTimeBasedOnElapsedRealtime(j));
            }
        }
    }

    private long[] guessMediaTimeBasedOnElapsedRealtime(long j) {
        List<long[]> list = this.mediaTimeHistory;
        long[] jArr = list.get(list.size() - 1);
        return new long[]{j, jArr[1] + ((long) ((j - jArr[0]) * this.currentPlaybackSpeed))};
    }

    private void maybeUpdateVideoFormat(AnalyticsListener.EventTime eventTime, @Nullable Format format) {
        int i;
        int i2;
        if (Objects.equals(this.currentVideoFormat, format)) {
            return;
        }
        maybeRecordVideoFormatTime(eventTime.realtimeMs);
        if (format != null) {
            if (this.initialVideoFormatHeight == -1 && (i2 = format.height) != -1) {
                this.initialVideoFormatHeight = i2;
            }
            if (this.initialVideoFormatBitrate == -1 && (i = format.bitrate) != -1) {
                this.initialVideoFormatBitrate = i;
            }
        }
        this.currentVideoFormat = format;
        if (this.keepHistory) {
            this.videoFormatHistory.add(new PlaybackStats.EventTimeAndFormat(eventTime, format));
        }
    }

    private void maybeUpdateAudioFormat(AnalyticsListener.EventTime eventTime, @Nullable Format format) {
        int i;
        if (Objects.equals(this.currentAudioFormat, format)) {
            return;
        }
        maybeRecordAudioFormatTime(eventTime.realtimeMs);
        if (format != null && this.initialAudioFormatBitrate == -1 && (i = format.bitrate) != -1) {
            this.initialAudioFormatBitrate = i;
        }
        this.currentAudioFormat = format;
        if (this.keepHistory) {
            this.audioFormatHistory.add(new PlaybackStats.EventTimeAndFormat(eventTime, format));
        }
    }

    private void maybeRecordVideoFormatTime(long j) {
        Format format;
        if (this.currentPlaybackState == 3 && (format = this.currentVideoFormat) != null) {
            long j2 = (long) ((j - this.lastVideoFormatStartTimeMs) * this.currentPlaybackSpeed);
            int i = format.height;
            if (i != -1) {
                this.videoFormatHeightTimeMs += j2;
                this.videoFormatHeightTimeProduct += ((long) i) * j2;
            }
            int i2 = format.bitrate;
            if (i2 != -1) {
                this.videoFormatBitrateTimeMs += j2;
                this.videoFormatBitrateTimeProduct += j2 * ((long) i2);
            }
        }
        this.lastVideoFormatStartTimeMs = j;
    }

    private void maybeRecordAudioFormatTime(long j) {
        Format format;
        int i;
        if (this.currentPlaybackState == 3 && (format = this.currentAudioFormat) != null && (i = format.bitrate) != -1) {
            long j2 = (long) ((j - this.lastAudioFormatStartTimeMs) * this.currentPlaybackSpeed);
            this.audioFormatTimeMs += j2;
            this.audioFormatBitrateTimeProduct += j2 * ((long) i);
        }
        this.lastAudioFormatStartTimeMs = j;
    }
}
