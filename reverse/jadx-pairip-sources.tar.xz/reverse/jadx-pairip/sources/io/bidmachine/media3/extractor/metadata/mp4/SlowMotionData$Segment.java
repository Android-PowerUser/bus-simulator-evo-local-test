package io.bidmachine.media3.extractor.metadata.mp4;

import androidx.annotation.Nullable;
import com.google.common.collect.ComparisonChain;
import io.bidmachine.media3.common.util.Assertions;
import io.bidmachine.media3.common.util.Util;
import java.util.Comparator;
import java.util.Objects;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class SlowMotionData$Segment {
    public static final Comparator<SlowMotionData$Segment> BY_START_THEN_END_THEN_DIVISOR = new SlowMotionData$Segment$.ExternalSyntheticLambda0();
    public final long endTimeMs;
    public final int speedDivisor;
    public final long startTimeMs;

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ int lambda$static$0(SlowMotionData$Segment slowMotionData$Segment, SlowMotionData$Segment slowMotionData$Segment2) {
        return ComparisonChain.start().compare(slowMotionData$Segment.startTimeMs, slowMotionData$Segment2.startTimeMs).compare(slowMotionData$Segment.endTimeMs, slowMotionData$Segment2.endTimeMs).compare(slowMotionData$Segment.speedDivisor, slowMotionData$Segment2.speedDivisor).result();
    }

    public SlowMotionData$Segment(long j, long j2, int i) {
        Assertions.checkArgument(j < j2);
        this.startTimeMs = j;
        this.endTimeMs = j2;
        this.speedDivisor = i;
    }

    public String toString() {
        return Util.formatInvariant("Segment: startTimeMs=%d, endTimeMs=%d, speedDivisor=%d", new Object[]{Long.valueOf(this.startTimeMs), Long.valueOf(this.endTimeMs), Integer.valueOf(this.speedDivisor)});
    }

    public boolean equals(@Nullable Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || SlowMotionData$Segment.class != obj.getClass()) {
            return false;
        }
        SlowMotionData$Segment slowMotionData$Segment = (SlowMotionData$Segment) obj;
        return this.startTimeMs == slowMotionData$Segment.startTimeMs && this.endTimeMs == slowMotionData$Segment.endTimeMs && this.speedDivisor == slowMotionData$Segment.speedDivisor;
    }

    public int hashCode() {
        return Objects.hash(Long.valueOf(this.startTimeMs), Long.valueOf(this.endTimeMs), Integer.valueOf(this.speedDivisor));
    }
}
