package io.bidmachine.media3.exoplayer.audio;

import android.media.AudioRouting;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class DefaultAudioSink$OnRoutingChangedListenerApi24$$ExternalSyntheticLambda0 implements AudioRouting.OnRoutingChangedListener {
    public final /* synthetic */ DefaultAudioSink.OnRoutingChangedListenerApi24 f$0;

    @Override // android.media.AudioRouting.OnRoutingChangedListener
    public final void onRoutingChanged(AudioRouting audioRouting) {
        DefaultAudioSink.OnRoutingChangedListenerApi24.$r8$lambda$Bj-dv248RHBAZPo7KZff917KTsM(this.f$0, audioRouting);
    }
}
