package io.bidmachine.media3.ui;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface PlayerView$FullscreenButtonClickListener {
    void onFullscreenButtonClick(boolean z);
}
