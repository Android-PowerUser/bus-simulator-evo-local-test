package io.bidmachine.media3.exoplayer.audio;

import com.google.errorprone.annotations.CanIgnoreReturnValue;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class DefaultAudioTrackBufferSizeProvider$Builder {
    private int minPcmBufferDurationUs = 250000;
    private int maxPcmBufferDurationUs = 750000;
    private int pcmBufferMultiplicationFactor = 4;
    private int passthroughBufferDurationUs = 250000;
    private int offloadBufferDurationUs = 50000000;
    private int ac3BufferMultiplicationFactor = 2;
    private int dtshdBufferMultiplicationFactor = 4;

    @CanIgnoreReturnValue
    public DefaultAudioTrackBufferSizeProvider$Builder setMinPcmBufferDurationUs(int i) {
        this.minPcmBufferDurationUs = i;
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultAudioTrackBufferSizeProvider$Builder setMaxPcmBufferDurationUs(int i) {
        this.maxPcmBufferDurationUs = i;
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultAudioTrackBufferSizeProvider$Builder setPcmBufferMultiplicationFactor(int i) {
        this.pcmBufferMultiplicationFactor = i;
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultAudioTrackBufferSizeProvider$Builder setPassthroughBufferDurationUs(int i) {
        this.passthroughBufferDurationUs = i;
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultAudioTrackBufferSizeProvider$Builder setOffloadBufferDurationUs(int i) {
        this.offloadBufferDurationUs = i;
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultAudioTrackBufferSizeProvider$Builder setAc3BufferMultiplicationFactor(int i) {
        this.ac3BufferMultiplicationFactor = i;
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultAudioTrackBufferSizeProvider$Builder setDtshdBufferMultiplicationFactor(int i) {
        this.dtshdBufferMultiplicationFactor = i;
        return this;
    }

    public DefaultAudioTrackBufferSizeProvider build() {
        return new DefaultAudioTrackBufferSizeProvider(this);
    }
}
