package io.bidmachine.media3.exoplayer.trackselection;

import io.bidmachine.media3.exoplayer.Renderer;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface TrackSelector$InvalidationListener {
    default void onRendererCapabilitiesChanged(Renderer renderer) {
    }

    void onTrackSelectionsInvalidated();
}
