package io.bidmachine.media3.exoplayer.hls.playlist;

import android.net.Uri;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class HlsMediaPlaylist$RenditionReport {
    public final long lastMediaSequence;
    public final int lastPartIndex;
    public final Uri playlistUri;

    public HlsMediaPlaylist$RenditionReport(Uri uri, long j, int i) {
        this.playlistUri = uri;
        this.lastMediaSequence = j;
        this.lastPartIndex = i;
    }
}
