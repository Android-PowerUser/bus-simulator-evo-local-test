package io.bidmachine.media3.exoplayer.offline;

import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class DownloadRequest$ByteRange$1 implements Parcelable.Creator<DownloadRequest.ByteRange> {
    DownloadRequest$ByteRange$1() {
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // android.os.Parcelable.Creator
    public DownloadRequest.ByteRange createFromParcel(Parcel parcel) {
        return new DownloadRequest.ByteRange(parcel);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // android.os.Parcelable.Creator
    public DownloadRequest.ByteRange[] newArray(int i) {
        return new DownloadRequest.ByteRange[i];
    }
}
