package io.bidmachine.media3.exoplayer.trackselection;

import android.content.Context;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface TrackSelector$Factory {
    TrackSelector createTrackSelector(Context context);
}
