package io.bidmachine.media3.exoplayer.source.preload;

import com.google.common.base.Supplier;
import io.bidmachine.media3.exoplayer.upstream.BandwidthMeter;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class DefaultPreloadManager$Builder$$ExternalSyntheticLambda7 implements Supplier {
    public final /* synthetic */ BandwidthMeter f$0;

    public final Object get() {
        return DefaultPreloadManager.Builder.$r8$lambda$WBLVW3tMQ0d2ApOExCHP1BM7YjA(this.f$0);
    }
}
