package io.bidmachine.media3.exoplayer.hls;

import com.google.common.base.Function;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class HlsMediaPeriod$$ExternalSyntheticLambda0 implements Function {
    public final Object apply(Object obj) {
        return HlsMediaPeriod.$r8$lambda$WHOPL01R95fzz4Hf38XEumFGLCQ((HlsSampleStreamWrapper) obj);
    }
}
