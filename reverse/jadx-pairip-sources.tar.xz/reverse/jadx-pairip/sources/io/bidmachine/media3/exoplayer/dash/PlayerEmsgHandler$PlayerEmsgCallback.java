package io.bidmachine.media3.exoplayer.dash;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface PlayerEmsgHandler$PlayerEmsgCallback {
    void onDashManifestPublishTimeExpired(long j);

    void onDashManifestRefreshRequested();
}
