package io.bidmachine.media3.ui;

import android.view.View;
import io.bidmachine.media3.common.Player;
import io.bidmachine.media3.common.util.RepeatModeUtil;
import io.bidmachine.media3.common.util.Util;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class LegacyPlayerControlView$ComponentListener implements Player.Listener, TimeBar.OnScrubListener, View.OnClickListener {
    final /* synthetic */ LegacyPlayerControlView this$0;

    private LegacyPlayerControlView$ComponentListener(LegacyPlayerControlView legacyPlayerControlView) {
        this.this$0 = legacyPlayerControlView;
    }

    public void onEvents(Player player, Player.Events events) {
        if (events.containsAny(new int[]{4, 5})) {
            LegacyPlayerControlView.access$100(this.this$0);
        }
        if (events.containsAny(new int[]{4, 5, 7})) {
            LegacyPlayerControlView.access$200(this.this$0);
        }
        if (events.contains(8)) {
            LegacyPlayerControlView.access$300(this.this$0);
        }
        if (events.contains(9)) {
            LegacyPlayerControlView.access$400(this.this$0);
        }
        if (events.containsAny(new int[]{8, 9, 11, 0, 13})) {
            LegacyPlayerControlView.access$500(this.this$0);
        }
        if (events.containsAny(new int[]{11, 0})) {
            LegacyPlayerControlView.access$600(this.this$0);
        }
    }

    public void onScrubStart(TimeBar timeBar, long j) {
        LegacyPlayerControlView.access$702(this.this$0, true);
        if (LegacyPlayerControlView.access$800(this.this$0) != null) {
            LegacyPlayerControlView.access$800(this.this$0).setText(Util.getStringForTime(LegacyPlayerControlView.access$900(this.this$0), LegacyPlayerControlView.access$1000(this.this$0), j));
        }
    }

    public void onScrubMove(TimeBar timeBar, long j) {
        if (LegacyPlayerControlView.access$800(this.this$0) != null) {
            LegacyPlayerControlView.access$800(this.this$0).setText(Util.getStringForTime(LegacyPlayerControlView.access$900(this.this$0), LegacyPlayerControlView.access$1000(this.this$0), j));
        }
    }

    public void onScrubStop(TimeBar timeBar, long j, boolean z) {
        LegacyPlayerControlView.access$702(this.this$0, false);
        if (z || LegacyPlayerControlView.access$1100(this.this$0) == null) {
            return;
        }
        LegacyPlayerControlView legacyPlayerControlView = this.this$0;
        LegacyPlayerControlView.access$1200(legacyPlayerControlView, LegacyPlayerControlView.access$1100(legacyPlayerControlView), j);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        Player playerAccess$1100 = LegacyPlayerControlView.access$1100(this.this$0);
        if (playerAccess$1100 == null) {
            return;
        }
        if (LegacyPlayerControlView.access$1300(this.this$0) == view) {
            playerAccess$1100.seekToNext();
            return;
        }
        if (LegacyPlayerControlView.access$1400(this.this$0) == view) {
            playerAccess$1100.seekToPrevious();
            return;
        }
        if (LegacyPlayerControlView.access$1500(this.this$0) == view) {
            if (playerAccess$1100.getPlaybackState() != 4) {
                playerAccess$1100.seekForward();
                return;
            }
            return;
        }
        if (LegacyPlayerControlView.access$1600(this.this$0) == view) {
            playerAccess$1100.seekBack();
            return;
        }
        if (LegacyPlayerControlView.access$1700(this.this$0) == view) {
            Util.handlePlayButtonAction(playerAccess$1100);
            return;
        }
        if (LegacyPlayerControlView.access$1800(this.this$0) == view) {
            Util.handlePauseButtonAction(playerAccess$1100);
        } else if (LegacyPlayerControlView.access$1900(this.this$0) == view) {
            playerAccess$1100.setRepeatMode(RepeatModeUtil.getNextRepeatMode(playerAccess$1100.getRepeatMode(), LegacyPlayerControlView.access$2000(this.this$0)));
        } else if (LegacyPlayerControlView.access$2100(this.this$0) == view) {
            playerAccess$1100.setShuffleModeEnabled(!playerAccess$1100.getShuffleModeEnabled());
        }
    }
}
