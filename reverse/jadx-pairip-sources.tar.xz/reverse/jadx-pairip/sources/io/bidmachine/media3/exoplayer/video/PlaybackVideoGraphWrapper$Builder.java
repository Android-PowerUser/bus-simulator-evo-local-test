package io.bidmachine.media3.exoplayer.video;

import android.content.Context;
import com.google.common.collect.ImmutableList;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import io.bidmachine.media3.common.Effect;
import io.bidmachine.media3.common.PreviewingVideoGraph;
import io.bidmachine.media3.common.VideoCompositorSettings;
import io.bidmachine.media3.common.VideoFrameProcessor$Factory;
import io.bidmachine.media3.common.util.Assertions;
import io.bidmachine.media3.common.util.Clock;
import java.util.List;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class PlaybackVideoGraphWrapper$Builder {
    private boolean built;
    private final Context context;
    private PreviewingVideoGraph.Factory previewingVideoGraphFactory;
    private boolean requestOpenGlToneMapping;
    private VideoFrameProcessor$Factory videoFrameProcessorFactory;
    private final VideoFrameReleaseControl videoFrameReleaseControl;
    private List<Effect> compositionEffects = ImmutableList.of();
    private VideoCompositorSettings compositorSettings = VideoCompositorSettings.DEFAULT;
    private Clock clock = Clock.DEFAULT;

    public PlaybackVideoGraphWrapper$Builder(Context context, VideoFrameReleaseControl videoFrameReleaseControl) {
        this.context = context.getApplicationContext();
        this.videoFrameReleaseControl = videoFrameReleaseControl;
    }

    @CanIgnoreReturnValue
    public PlaybackVideoGraphWrapper$Builder setVideoFrameProcessorFactory(VideoFrameProcessor$Factory videoFrameProcessor$Factory) {
        this.videoFrameProcessorFactory = videoFrameProcessor$Factory;
        return this;
    }

    @CanIgnoreReturnValue
    public PlaybackVideoGraphWrapper$Builder setPreviewingVideoGraphFactory(PreviewingVideoGraph.Factory factory) {
        this.previewingVideoGraphFactory = factory;
        return this;
    }

    @CanIgnoreReturnValue
    public PlaybackVideoGraphWrapper$Builder setCompositionEffects(List<Effect> list) {
        this.compositionEffects = list;
        return this;
    }

    @CanIgnoreReturnValue
    public PlaybackVideoGraphWrapper$Builder setCompositorSettings(VideoCompositorSettings videoCompositorSettings) {
        this.compositorSettings = videoCompositorSettings;
        return this;
    }

    @CanIgnoreReturnValue
    public PlaybackVideoGraphWrapper$Builder setClock(Clock clock) {
        this.clock = clock;
        return this;
    }

    @CanIgnoreReturnValue
    public PlaybackVideoGraphWrapper$Builder setRequestOpenGlToneMapping(boolean z) {
        this.requestOpenGlToneMapping = z;
        return this;
    }

    public PlaybackVideoGraphWrapper build() {
        Assertions.checkState(!this.built);
        if (this.previewingVideoGraphFactory == null) {
            if (this.videoFrameProcessorFactory == null) {
                this.videoFrameProcessorFactory = new PlaybackVideoGraphWrapper$ReflectiveDefaultVideoFrameProcessorFactory();
            }
            this.previewingVideoGraphFactory = new PlaybackVideoGraphWrapper.ReflectivePreviewingSingleInputVideoGraphFactory(this.videoFrameProcessorFactory);
        }
        PlaybackVideoGraphWrapper playbackVideoGraphWrapper = new PlaybackVideoGraphWrapper(this, (PlaybackVideoGraphWrapper.1) null);
        this.built = true;
        return playbackVideoGraphWrapper;
    }
}
