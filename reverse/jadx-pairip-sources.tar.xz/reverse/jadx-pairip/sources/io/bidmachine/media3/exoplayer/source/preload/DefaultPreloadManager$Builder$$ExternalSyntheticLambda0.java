package io.bidmachine.media3.exoplayer.source.preload;

import com.google.common.base.Supplier;
import io.bidmachine.media3.exoplayer.LoadControl;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class DefaultPreloadManager$Builder$$ExternalSyntheticLambda0 implements Supplier {
    public final /* synthetic */ LoadControl f$0;

    public final Object get() {
        return DefaultPreloadManager.Builder.$r8$lambda$RKgW275bBt4FPMoroE6GAOz5k-o(this.f$0);
    }
}
