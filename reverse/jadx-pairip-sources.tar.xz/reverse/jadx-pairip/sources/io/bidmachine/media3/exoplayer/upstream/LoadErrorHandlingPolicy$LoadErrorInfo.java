package io.bidmachine.media3.exoplayer.upstream;

import io.bidmachine.media3.exoplayer.source.LoadEventInfo;
import io.bidmachine.media3.exoplayer.source.MediaLoadData;
import java.io.IOException;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class LoadErrorHandlingPolicy$LoadErrorInfo {
    public final int errorCount;
    public final IOException exception;
    public final LoadEventInfo loadEventInfo;
    public final MediaLoadData mediaLoadData;

    public LoadErrorHandlingPolicy$LoadErrorInfo(LoadEventInfo loadEventInfo, MediaLoadData mediaLoadData, IOException iOException, int i) {
        this.loadEventInfo = loadEventInfo;
        this.mediaLoadData = mediaLoadData;
        this.exception = iOException;
        this.errorCount = i;
    }
}
