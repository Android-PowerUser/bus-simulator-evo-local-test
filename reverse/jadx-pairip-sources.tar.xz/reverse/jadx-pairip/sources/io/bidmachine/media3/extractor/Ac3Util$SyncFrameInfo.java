package io.bidmachine.media3.extractor;

import androidx.annotation.Nullable;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class Ac3Util$SyncFrameInfo {
    public static final int STREAM_TYPE_TYPE0 = 0;
    public static final int STREAM_TYPE_TYPE1 = 1;
    public static final int STREAM_TYPE_TYPE2 = 2;
    public static final int STREAM_TYPE_UNDEFINED = -1;
    public final int bitrate;
    public final int channelCount;
    public final int frameSize;

    @Nullable
    public final String mimeType;
    public final int sampleCount;
    public final int sampleRate;
    public final int streamType;

    private Ac3Util$SyncFrameInfo(@Nullable String str, int i, int i2, int i3, int i4, int i5, int i6) {
        this.mimeType = str;
        this.streamType = i;
        this.channelCount = i2;
        this.sampleRate = i3;
        this.frameSize = i4;
        this.sampleCount = i5;
        this.bitrate = i6;
    }
}
