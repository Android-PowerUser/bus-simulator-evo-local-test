package io.bidmachine.media3.exoplayer.dash;

import androidx.annotation.Nullable;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import io.bidmachine.media3.common.Format;
import io.bidmachine.media3.datasource.TransferListener;
import io.bidmachine.media3.exoplayer.analytics.PlayerId;
import io.bidmachine.media3.exoplayer.dash.manifest.DashManifest;
import io.bidmachine.media3.exoplayer.trackselection.ExoTrackSelection;
import io.bidmachine.media3.exoplayer.upstream.CmcdConfiguration;
import io.bidmachine.media3.exoplayer.upstream.LoaderErrorThrower;
import io.bidmachine.media3.extractor.text.SubtitleParser;
import java.util.List;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface DashChunkSource$Factory {
    DashChunkSource createDashChunkSource(LoaderErrorThrower loaderErrorThrower, DashManifest dashManifest, BaseUrlExclusionList baseUrlExclusionList, int i, int[] iArr, ExoTrackSelection exoTrackSelection, int i2, long j, boolean z, List<Format> list, @Nullable PlayerEmsgHandler.PlayerTrackEmsgHandler playerTrackEmsgHandler, @Nullable TransferListener transferListener, PlayerId playerId, @Nullable CmcdConfiguration cmcdConfiguration);

    @CanIgnoreReturnValue
    default DashChunkSource$Factory experimentalParseSubtitlesDuringExtraction(boolean z) {
        return this;
    }

    @CanIgnoreReturnValue
    default DashChunkSource$Factory experimentalSetCodecsToParseWithinGopSampleDependencies(int i) {
        return this;
    }

    default Format getOutputTextFormat(Format format) {
        return format;
    }

    @CanIgnoreReturnValue
    default DashChunkSource$Factory setSubtitleParserFactory(SubtitleParser.Factory factory) {
        return this;
    }
}
