package io.bidmachine.media3.exoplayer.video;

import io.bidmachine.media3.common.VideoFrameProcessingException;
import io.bidmachine.media3.common.VideoSize;
import java.util.Iterator;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class PlaybackVideoGraphWrapper$DefaultVideoSinkListener implements VideoSink.Listener {
    final /* synthetic */ PlaybackVideoGraphWrapper this$0;

    private PlaybackVideoGraphWrapper$DefaultVideoSinkListener(PlaybackVideoGraphWrapper playbackVideoGraphWrapper) {
        this.this$0 = playbackVideoGraphWrapper;
    }

    public void onFirstFrameRendered(VideoSink videoSink) {
        Iterator it = PlaybackVideoGraphWrapper.access$3000(this.this$0).iterator();
        while (it.hasNext()) {
            ((PlaybackVideoGraphWrapper$Listener) it.next()).onFirstFrameRendered(this.this$0);
        }
    }

    public void onFrameDropped(VideoSink videoSink) {
        Iterator it = PlaybackVideoGraphWrapper.access$3000(this.this$0).iterator();
        while (it.hasNext()) {
            ((PlaybackVideoGraphWrapper$Listener) it.next()).onFrameDropped(this.this$0);
        }
    }

    public void onVideoSizeChanged(VideoSink videoSink, VideoSize videoSize) {
        Iterator it = PlaybackVideoGraphWrapper.access$3000(this.this$0).iterator();
        while (it.hasNext()) {
            ((PlaybackVideoGraphWrapper$Listener) it.next()).onVideoSizeChanged(this.this$0, videoSize);
        }
    }

    public void onError(VideoSink videoSink, VideoSink.VideoSinkException videoSinkException) {
        Iterator it = PlaybackVideoGraphWrapper.access$3000(this.this$0).iterator();
        while (it.hasNext()) {
            ((PlaybackVideoGraphWrapper$Listener) it.next()).onError(this.this$0, VideoFrameProcessingException.from(videoSinkException));
        }
    }
}
