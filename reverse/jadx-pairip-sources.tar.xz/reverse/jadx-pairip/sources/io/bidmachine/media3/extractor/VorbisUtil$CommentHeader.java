package io.bidmachine.media3.extractor;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class VorbisUtil$CommentHeader {
    public final String[] comments;
    public final int length;
    public final String vendor;

    public VorbisUtil$CommentHeader(String str, String[] strArr, int i) {
        this.vendor = str;
        this.comments = strArr;
        this.length = i;
    }
}
