package io.bidmachine.media3.container;

import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class Mp4Box$ContainerBox extends Mp4Box {
    public final List<Mp4Box$ContainerBox> containerChildren;
    public final long endPosition;
    public final List<Mp4Box.LeafBox> leafChildren;

    public Mp4Box$ContainerBox(int i, long j) {
        super(i, (Mp4Box.1) null);
        this.endPosition = j;
        this.leafChildren = new ArrayList();
        this.containerChildren = new ArrayList();
    }

    public void add(Mp4Box.LeafBox leafBox) {
        this.leafChildren.add(leafBox);
    }

    public void add(Mp4Box$ContainerBox mp4Box$ContainerBox) {
        this.containerChildren.add(mp4Box$ContainerBox);
    }

    @Nullable
    public Mp4Box.LeafBox getLeafBoxOfType(int i) {
        int size = this.leafChildren.size();
        for (int i2 = 0; i2 < size; i2++) {
            Mp4Box.LeafBox leafBox = this.leafChildren.get(i2);
            if (((Mp4Box) leafBox).type == i) {
                return leafBox;
            }
        }
        return null;
    }

    @Nullable
    public Mp4Box$ContainerBox getContainerBoxOfType(int i) {
        int size = this.containerChildren.size();
        for (int i2 = 0; i2 < size; i2++) {
            Mp4Box$ContainerBox mp4Box$ContainerBox = this.containerChildren.get(i2);
            if (((Mp4Box) mp4Box$ContainerBox).type == i) {
                return mp4Box$ContainerBox;
            }
        }
        return null;
    }

    public String toString() {
        return Mp4Box.getBoxTypeString(((Mp4Box) this).type) + " leaves: " + Arrays.toString(this.leafChildren.toArray()) + " containers: " + Arrays.toString(this.containerChildren.toArray());
    }
}
