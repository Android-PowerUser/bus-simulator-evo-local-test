package io.bidmachine.media3.exoplayer.video;

import android.content.Context;
import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;
import io.bidmachine.media3.common.ColorInfo;
import io.bidmachine.media3.common.DebugViewProvider;
import io.bidmachine.media3.common.VideoFrameProcessingException;
import io.bidmachine.media3.common.VideoFrameProcessor;
import io.bidmachine.media3.common.VideoFrameProcessor$Factory;
import io.bidmachine.media3.common.VideoFrameProcessor$Listener;
import io.bidmachine.media3.common.util.Assertions;
import java.util.concurrent.Executor;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class PlaybackVideoGraphWrapper$ReflectiveDefaultVideoFrameProcessorFactory implements VideoFrameProcessor$Factory {
    private static final Supplier<VideoFrameProcessor$Factory> VIDEO_FRAME_PROCESSOR_FACTORY_SUPPLIER = Suppliers.memoize(new PlaybackVideoGraphWrapper$ReflectiveDefaultVideoFrameProcessorFactory$.ExternalSyntheticLambda0());

    private PlaybackVideoGraphWrapper$ReflectiveDefaultVideoFrameProcessorFactory() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ VideoFrameProcessor$Factory lambda$static$0() {
        try {
            Class<?> cls = Class.forName("io.bidmachine.media3.effect.DefaultVideoFrameProcessor$Factory$Builder");
            return (VideoFrameProcessor$Factory) Assertions.checkNotNull(cls.getMethod("build", new Class[0]).invoke(cls.getConstructor(new Class[0]).newInstance(new Object[0]), new Object[0]));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    @Override // io.bidmachine.media3.common.VideoFrameProcessor$Factory
    public VideoFrameProcessor create(Context context, DebugViewProvider debugViewProvider, ColorInfo colorInfo, boolean z, Executor executor, VideoFrameProcessor$Listener videoFrameProcessor$Listener) throws VideoFrameProcessingException {
        return ((VideoFrameProcessor$Factory) VIDEO_FRAME_PROCESSOR_FACTORY_SUPPLIER.get()).create(context, debugViewProvider, colorInfo, z, executor, videoFrameProcessor$Listener);
    }
}
