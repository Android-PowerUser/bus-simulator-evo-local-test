package io.bidmachine.media3.extractor.ts;

import io.bidmachine.media3.common.util.ParsableByteArray;
import io.bidmachine.media3.common.util.TimestampAdjuster;
import io.bidmachine.media3.common.util.Util;
import io.bidmachine.media3.extractor.BinarySearchSeeker;
import io.bidmachine.media3.extractor.ExtractorInput;
import java.io.IOException;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class TsBinarySearchSeeker$TsPcrSeeker implements BinarySearchSeeker.TimestampSeeker {
    private final ParsableByteArray packetBuffer = new ParsableByteArray();
    private final int pcrPid;
    private final TimestampAdjuster pcrTimestampAdjuster;
    private final int timestampSearchBytes;

    public TsBinarySearchSeeker$TsPcrSeeker(int i, TimestampAdjuster timestampAdjuster, int i2) {
        this.pcrPid = i;
        this.pcrTimestampAdjuster = timestampAdjuster;
        this.timestampSearchBytes = i2;
    }

    public BinarySearchSeeker.TimestampSearchResult searchForTimestamp(ExtractorInput extractorInput, long j) throws IOException {
        long position = extractorInput.getPosition();
        int iMin = (int) Math.min(this.timestampSearchBytes, extractorInput.getLength() - position);
        this.packetBuffer.reset(iMin);
        extractorInput.peekFully(this.packetBuffer.getData(), 0, iMin);
        return searchForPcrValueInBuffer(this.packetBuffer, j, position);
    }

    private BinarySearchSeeker.TimestampSearchResult searchForPcrValueInBuffer(ParsableByteArray parsableByteArray, long j, long j2) {
        int iFindSyncBytePosition;
        int iFindSyncBytePosition2;
        int iLimit = parsableByteArray.limit();
        long j3 = -1;
        long j4 = -1;
        long j5 = -9223372036854775807L;
        while (parsableByteArray.bytesLeft() >= 188 && (iFindSyncBytePosition2 = (iFindSyncBytePosition = TsUtil.findSyncBytePosition(parsableByteArray.getData(), parsableByteArray.getPosition(), iLimit)) + 188) <= iLimit) {
            long pcrFromPacket = TsUtil.readPcrFromPacket(parsableByteArray, iFindSyncBytePosition, this.pcrPid);
            if (pcrFromPacket != -9223372036854775807L) {
                long jAdjustTsTimestamp = this.pcrTimestampAdjuster.adjustTsTimestamp(pcrFromPacket);
                if (jAdjustTsTimestamp > j) {
                    if (j5 == -9223372036854775807L) {
                        return BinarySearchSeeker.TimestampSearchResult.overestimatedResult(jAdjustTsTimestamp, j2);
                    }
                    return BinarySearchSeeker.TimestampSearchResult.targetFoundResult(j2 + j4);
                }
                if (100000 + jAdjustTsTimestamp > j) {
                    return BinarySearchSeeker.TimestampSearchResult.targetFoundResult(j2 + ((long) iFindSyncBytePosition));
                }
                j4 = iFindSyncBytePosition;
                j5 = jAdjustTsTimestamp;
            }
            parsableByteArray.setPosition(iFindSyncBytePosition2);
            j3 = iFindSyncBytePosition2;
        }
        if (j5 != -9223372036854775807L) {
            return BinarySearchSeeker.TimestampSearchResult.underestimatedResult(j5, j2 + j3);
        }
        return BinarySearchSeeker.TimestampSearchResult.NO_TIMESTAMP_IN_RANGE_RESULT;
    }

    public void onSeekFinished() {
        this.packetBuffer.reset(Util.EMPTY_BYTE_ARRAY);
    }
}
