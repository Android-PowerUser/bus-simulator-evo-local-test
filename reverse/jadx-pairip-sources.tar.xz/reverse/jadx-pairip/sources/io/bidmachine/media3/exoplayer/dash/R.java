package io.bidmachine.media3.exoplayer.dash;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class R {

    public static final class color {
        public static final int androidx_core_ripple_material_light = 0x7f06001a;
        public static final int androidx_core_secondary_text_default_material_light = 0x7f06001b;
        public static final int notification_action_color_filter = 0x7f0600e8;
        public static final int notification_icon_bg_color = 0x7f0600e9;

        private color() {
        }
    }

    public static final class integer {
        public static final int status_bar_notification_info_maxnum = 0x7f0b000a;

        private integer() {
        }
    }

    private R() {
    }
}
