package io.bidmachine.media3.exoplayer.audio;

import io.bidmachine.media3.common.Format;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class AudioSink$WriteException extends Exception {
    public final int errorCode;
    public final Format format;
    public final boolean isRecoverable;

    public AudioSink$WriteException(int i, Format format, boolean z) {
        super("AudioTrack write failed: " + i);
        this.isRecoverable = z;
        this.errorCode = i;
        this.format = format;
    }
}
