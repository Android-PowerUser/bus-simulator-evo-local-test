package io.bidmachine.media3.exoplayer.upstream;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.ImmutableList;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import io.bidmachine.media3.common.util.Assertions;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class CmcdData$CmcdStatus {
    public final boolean bufferStarvation;
    public final ImmutableList<String> customDataList;
    public final int maximumRequestedThroughputKbps;

    public static final class Builder {
        private boolean bufferStarvation;
        private int maximumRequestedThroughputKbps = -2147483647;
        private ImmutableList<String> customDataList = ImmutableList.of();

        @CanIgnoreReturnValue
        public Builder setMaximumRequestedThroughputKbps(int i) {
            Assertions.checkArgument(i >= 0 || i == -2147483647);
            if (i != -2147483647) {
                i = ((i + 50) / 100) * 100;
            }
            this.maximumRequestedThroughputKbps = i;
            return this;
        }

        @CanIgnoreReturnValue
        public Builder setBufferStarvation(boolean z) {
            this.bufferStarvation = z;
            return this;
        }

        @CanIgnoreReturnValue
        public Builder setCustomDataList(List<String> list) {
            this.customDataList = ImmutableList.copyOf((Collection) list);
            return this;
        }

        public CmcdData$CmcdStatus build() {
            return new CmcdData$CmcdStatus(this);
        }
    }

    private CmcdData$CmcdStatus(Builder builder) {
        this.maximumRequestedThroughputKbps = builder.maximumRequestedThroughputKbps;
        this.bufferStarvation = builder.bufferStarvation;
        this.customDataList = builder.customDataList;
    }

    public void populateCmcdDataMap(ArrayListMultimap<String, String> arrayListMultimap) {
        ArrayList arrayList = new ArrayList();
        if (this.maximumRequestedThroughputKbps != -2147483647) {
            arrayList.add("rtp=" + this.maximumRequestedThroughputKbps);
        }
        if (this.bufferStarvation) {
            arrayList.add("bs");
        }
        arrayList.addAll(this.customDataList);
        if (arrayList.isEmpty()) {
            return;
        }
        arrayListMultimap.putAll("CMCD-Status", arrayList);
    }
}
