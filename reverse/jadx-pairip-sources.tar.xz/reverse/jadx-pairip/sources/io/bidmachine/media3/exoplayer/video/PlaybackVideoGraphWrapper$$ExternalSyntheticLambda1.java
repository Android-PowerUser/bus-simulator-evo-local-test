package io.bidmachine.media3.exoplayer.video;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class PlaybackVideoGraphWrapper$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ PlaybackVideoGraphWrapper f$0;

    @Override // java.lang.Runnable
    public final void run() {
        PlaybackVideoGraphWrapper.$r8$lambda$3_FNOtllSc33jGdvWZdaYRbHbgM(this.f$0);
    }
}
