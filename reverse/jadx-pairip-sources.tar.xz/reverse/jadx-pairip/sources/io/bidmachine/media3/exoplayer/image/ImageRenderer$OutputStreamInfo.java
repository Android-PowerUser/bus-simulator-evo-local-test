package io.bidmachine.media3.exoplayer.image;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class ImageRenderer$OutputStreamInfo {
    public static final ImageRenderer$OutputStreamInfo UNSET = new ImageRenderer$OutputStreamInfo(-9223372036854775807L, -9223372036854775807L);
    public final long previousStreamLastBufferTimeUs;
    public final long streamOffsetUs;

    public ImageRenderer$OutputStreamInfo(long j, long j2) {
        this.previousStreamLastBufferTimeUs = j;
        this.streamOffsetUs = j2;
    }
}
