package io.bidmachine.media3.ui;

import android.animation.ValueAnimator;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class PlayerControlViewLayoutManager$$ExternalSyntheticLambda12 implements ValueAnimator.AnimatorUpdateListener {
    public final /* synthetic */ PlayerControlViewLayoutManager f$0;

    @Override // android.animation.ValueAnimator.AnimatorUpdateListener
    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        PlayerControlViewLayoutManager.$r8$lambda$T6bYGTzn43JmW3GH_rpFSEzVL3E(this.f$0, valueAnimator);
    }
}
