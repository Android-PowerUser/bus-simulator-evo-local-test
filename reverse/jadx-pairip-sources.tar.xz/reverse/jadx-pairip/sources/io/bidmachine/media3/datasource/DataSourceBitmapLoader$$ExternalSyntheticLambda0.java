package io.bidmachine.media3.datasource;

import android.net.Uri;
import java.util.concurrent.Callable;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class DataSourceBitmapLoader$$ExternalSyntheticLambda0 implements Callable {
    public final /* synthetic */ DataSourceBitmapLoader f$0;
    public final /* synthetic */ Uri f$1;

    public /* synthetic */ DataSourceBitmapLoader$$ExternalSyntheticLambda0(DataSourceBitmapLoader dataSourceBitmapLoader, Uri uri) {
        this.f$0 = dataSourceBitmapLoader;
        this.f$1 = uri;
    }

    @Override // java.util.concurrent.Callable
    public final Object call() {
        return DataSourceBitmapLoader.$r8$lambda$_5QZr-2GbYa9GTG7fpQ_LCCpzRM(this.f$0, this.f$1);
    }
}
