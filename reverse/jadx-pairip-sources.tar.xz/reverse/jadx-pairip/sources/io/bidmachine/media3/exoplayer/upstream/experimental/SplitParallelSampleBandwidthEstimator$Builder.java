package io.bidmachine.media3.exoplayer.upstream.experimental;

import androidx.annotation.VisibleForTesting;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import io.bidmachine.media3.common.util.Assertions;
import io.bidmachine.media3.common.util.Clock;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class SplitParallelSampleBandwidthEstimator$Builder {
    private BandwidthStatistic bandwidthStatistic = new SlidingWeightedAverageBandwidthStatistic();
    private Clock clock = Clock.DEFAULT;
    private long minBytesTransferred;
    private int minSamples;

    @CanIgnoreReturnValue
    public SplitParallelSampleBandwidthEstimator$Builder setBandwidthStatistic(BandwidthStatistic bandwidthStatistic) {
        Assertions.checkNotNull(bandwidthStatistic);
        this.bandwidthStatistic = bandwidthStatistic;
        return this;
    }

    @CanIgnoreReturnValue
    public SplitParallelSampleBandwidthEstimator$Builder setMinSamples(int i) {
        Assertions.checkArgument(i >= 0);
        this.minSamples = i;
        return this;
    }

    @CanIgnoreReturnValue
    public SplitParallelSampleBandwidthEstimator$Builder setMinBytesTransferred(long j) {
        Assertions.checkArgument(j >= 0);
        this.minBytesTransferred = j;
        return this;
    }

    @CanIgnoreReturnValue
    @VisibleForTesting
    SplitParallelSampleBandwidthEstimator$Builder setClock(Clock clock) {
        this.clock = clock;
        return this;
    }

    public SplitParallelSampleBandwidthEstimator build() {
        return new SplitParallelSampleBandwidthEstimator(this, (SplitParallelSampleBandwidthEstimator.1) null);
    }
}
