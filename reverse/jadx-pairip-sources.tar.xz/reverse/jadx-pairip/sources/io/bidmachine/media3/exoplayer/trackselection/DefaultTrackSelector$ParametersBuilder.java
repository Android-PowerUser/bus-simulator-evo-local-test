package io.bidmachine.media3.exoplayer.trackselection;

import android.content.Context;
import androidx.annotation.Nullable;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import io.bidmachine.media3.common.TrackGroup;
import io.bidmachine.media3.common.TrackSelectionOverride;
import io.bidmachine.media3.common.TrackSelectionParameters;
import io.bidmachine.media3.exoplayer.source.TrackGroupArray;
import java.util.Set;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Deprecated
public final class DefaultTrackSelector$ParametersBuilder extends TrackSelectionParameters.Builder {
    private final DefaultTrackSelector.Parameters.Builder delegate;

    @CanIgnoreReturnValue
    @Deprecated
    public /* bridge */ /* synthetic */ TrackSelectionParameters.Builder setDisabledTrackTypes(Set set) {
        return m1233setDisabledTrackTypes((Set<Integer>) set);
    }

    public DefaultTrackSelector$ParametersBuilder() {
        this.delegate = new DefaultTrackSelector.Parameters.Builder();
    }

    public DefaultTrackSelector$ParametersBuilder(Context context) {
        this.delegate = new DefaultTrackSelector.Parameters.Builder(context);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder set(TrackSelectionParameters trackSelectionParameters) {
        this.delegate.set(trackSelectionParameters);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setMaxVideoSizeSd() {
        this.delegate.setMaxVideoSizeSd();
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder clearVideoSizeConstraints() {
        this.delegate.clearVideoSizeConstraints();
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setMaxVideoSize(int i, int i2) {
        this.delegate.setMaxVideoSize(i, i2);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setMaxVideoFrameRate(int i) {
        this.delegate.setMaxVideoFrameRate(i);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setMaxVideoBitrate(int i) {
        this.delegate.setMaxVideoBitrate(i);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setMinVideoSize(int i, int i2) {
        this.delegate.setMinVideoSize(i, i2);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setMinVideoFrameRate(int i) {
        this.delegate.setMinVideoFrameRate(i);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setMinVideoBitrate(int i) {
        this.delegate.setMinVideoBitrate(i);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setExceedVideoConstraintsIfNecessary(boolean z) {
        this.delegate.setExceedVideoConstraintsIfNecessary(z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setAllowVideoMixedMimeTypeAdaptiveness(boolean z) {
        this.delegate.setAllowVideoMixedMimeTypeAdaptiveness(z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setAllowVideoNonSeamlessAdaptiveness(boolean z) {
        this.delegate.setAllowVideoNonSeamlessAdaptiveness(z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setAllowVideoMixedDecoderSupportAdaptiveness(boolean z) {
        this.delegate.setAllowVideoMixedDecoderSupportAdaptiveness(z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setViewportSizeToPhysicalDisplaySize(boolean z) {
        this.delegate.setViewportSizeToPhysicalDisplaySize(z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setViewportSizeToPhysicalDisplaySize(Context context, boolean z) {
        this.delegate.setViewportSizeToPhysicalDisplaySize(context, z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder clearViewportSizeConstraints() {
        this.delegate.clearViewportSizeConstraints();
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setViewportSize(int i, int i2, boolean z) {
        this.delegate.setViewportSize(i, i2, z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setPreferredVideoMimeType(@Nullable String str) {
        this.delegate.setPreferredVideoMimeType(str);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setPreferredVideoMimeTypes(String... strArr) {
        this.delegate.setPreferredVideoMimeTypes(strArr);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setPreferredVideoLanguage(@Nullable String str) {
        super.setPreferredVideoLanguage(str);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setPreferredVideoLanguages(String... strArr) {
        super.setPreferredVideoLanguages(strArr);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setPreferredVideoRoleFlags(int i) {
        this.delegate.setPreferredVideoRoleFlags(i);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setPreferredAudioLanguage(@Nullable String str) {
        this.delegate.setPreferredAudioLanguage(str);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setPreferredAudioLanguages(String... strArr) {
        this.delegate.setPreferredAudioLanguages(strArr);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setPreferredAudioRoleFlags(int i) {
        this.delegate.setPreferredAudioRoleFlags(i);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setMaxAudioChannelCount(int i) {
        this.delegate.setMaxAudioChannelCount(i);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setMaxAudioBitrate(int i) {
        this.delegate.setMaxAudioBitrate(i);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setExceedAudioConstraintsIfNecessary(boolean z) {
        this.delegate.setExceedAudioConstraintsIfNecessary(z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setAllowAudioMixedMimeTypeAdaptiveness(boolean z) {
        this.delegate.setAllowAudioMixedMimeTypeAdaptiveness(z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setAllowAudioMixedSampleRateAdaptiveness(boolean z) {
        this.delegate.setAllowAudioMixedSampleRateAdaptiveness(z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setAllowAudioMixedChannelCountAdaptiveness(boolean z) {
        this.delegate.setAllowAudioMixedChannelCountAdaptiveness(z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setAllowAudioMixedDecoderSupportAdaptiveness(boolean z) {
        this.delegate.setAllowAudioMixedDecoderSupportAdaptiveness(z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setPreferredAudioMimeType(@Nullable String str) {
        this.delegate.setPreferredAudioMimeType(str);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setPreferredAudioMimeTypes(String... strArr) {
        this.delegate.setPreferredAudioMimeTypes(strArr);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setAudioOffloadPreferences(TrackSelectionParameters.AudioOffloadPreferences audioOffloadPreferences) {
        this.delegate.setAudioOffloadPreferences(audioOffloadPreferences);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setPreferredTextLanguageAndRoleFlagsToCaptioningManagerSettings() {
        this.delegate.setPreferredTextLanguageAndRoleFlagsToCaptioningManagerSettings();
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setPreferredTextLanguageAndRoleFlagsToCaptioningManagerSettings(Context context) {
        this.delegate.setPreferredTextLanguageAndRoleFlagsToCaptioningManagerSettings(context);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setPreferredTextLanguage(@Nullable String str) {
        this.delegate.setPreferredTextLanguage(str);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setPreferredTextLanguages(String... strArr) {
        this.delegate.setPreferredTextLanguages(strArr);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setPreferredTextRoleFlags(int i) {
        this.delegate.setPreferredTextRoleFlags(i);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setIgnoredTextSelectionFlags(int i) {
        this.delegate.setIgnoredTextSelectionFlags(i);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setSelectUndeterminedTextLanguage(boolean z) {
        this.delegate.setSelectUndeterminedTextLanguage(z);
        return this;
    }

    @CanIgnoreReturnValue
    @Deprecated
    public DefaultTrackSelector$ParametersBuilder setDisabledTextTrackSelectionFlags(int i) {
        this.delegate.setDisabledTextTrackSelectionFlags(i);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setPrioritizeImageOverVideoEnabled(boolean z) {
        this.delegate.setPrioritizeImageOverVideoEnabled(z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setForceLowestBitrate(boolean z) {
        this.delegate.setForceLowestBitrate(z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setForceHighestSupportedBitrate(boolean z) {
        this.delegate.setForceHighestSupportedBitrate(z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder addOverride(TrackSelectionOverride trackSelectionOverride) {
        this.delegate.addOverride(trackSelectionOverride);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder clearOverride(TrackGroup trackGroup) {
        this.delegate.clearOverride(trackGroup);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setOverrideForType(TrackSelectionOverride trackSelectionOverride) {
        this.delegate.setOverrideForType(trackSelectionOverride);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder clearOverridesOfType(int i) {
        this.delegate.clearOverridesOfType(i);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder clearOverrides() {
        this.delegate.clearOverrides();
        return this;
    }

    @CanIgnoreReturnValue
    @Deprecated
    /* JADX INFO: renamed from: setDisabledTrackTypes, reason: collision with other method in class */
    public DefaultTrackSelector$ParametersBuilder m1233setDisabledTrackTypes(Set<Integer> set) {
        this.delegate.setDisabledTrackTypes(set);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setTrackTypeDisabled(int i, boolean z) {
        this.delegate.setTrackTypeDisabled(i, z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setExceedRendererCapabilitiesIfNecessary(boolean z) {
        this.delegate.setExceedRendererCapabilitiesIfNecessary(z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setTunnelingEnabled(boolean z) {
        this.delegate.setTunnelingEnabled(z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setAllowMultipleAdaptiveSelections(boolean z) {
        this.delegate.setAllowMultipleAdaptiveSelections(z);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultTrackSelector$ParametersBuilder setRendererDisabled(int i, boolean z) {
        this.delegate.setRendererDisabled(i, z);
        return this;
    }

    @CanIgnoreReturnValue
    @Deprecated
    public DefaultTrackSelector$ParametersBuilder setSelectionOverride(int i, TrackGroupArray trackGroupArray, @Nullable DefaultTrackSelector.SelectionOverride selectionOverride) {
        this.delegate.setSelectionOverride(i, trackGroupArray, selectionOverride);
        return this;
    }

    @CanIgnoreReturnValue
    @Deprecated
    public DefaultTrackSelector$ParametersBuilder clearSelectionOverride(int i, TrackGroupArray trackGroupArray) {
        this.delegate.clearSelectionOverride(i, trackGroupArray);
        return this;
    }

    @CanIgnoreReturnValue
    @Deprecated
    public DefaultTrackSelector$ParametersBuilder clearSelectionOverrides(int i) {
        this.delegate.clearSelectionOverrides(i);
        return this;
    }

    @CanIgnoreReturnValue
    @Deprecated
    public DefaultTrackSelector$ParametersBuilder clearSelectionOverrides() {
        this.delegate.clearSelectionOverrides();
        return this;
    }

    public DefaultTrackSelector.Parameters build() {
        return this.delegate.build();
    }
}
