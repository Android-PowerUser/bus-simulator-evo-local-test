package io.bidmachine.media3.exoplayer.video.spherical;

import android.graphics.SurfaceTexture;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class SceneRenderer$$ExternalSyntheticLambda0 implements SurfaceTexture.OnFrameAvailableListener {
    public final /* synthetic */ SceneRenderer f$0;

    @Override // android.graphics.SurfaceTexture.OnFrameAvailableListener
    public final void onFrameAvailable(SurfaceTexture surfaceTexture) {
        SceneRenderer.$r8$lambda$a8MTVSpCxIpP16_CQr9plW9XXOw(this.f$0, surfaceTexture);
    }
}
