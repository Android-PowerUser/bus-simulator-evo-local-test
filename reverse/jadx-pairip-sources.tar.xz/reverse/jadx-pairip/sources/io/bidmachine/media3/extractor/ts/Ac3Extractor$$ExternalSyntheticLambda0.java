package io.bidmachine.media3.extractor.ts;

import io.bidmachine.media3.extractor.Extractor;
import io.bidmachine.media3.extractor.ExtractorsFactory;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class Ac3Extractor$$ExternalSyntheticLambda0 implements ExtractorsFactory {
    public final Extractor[] createExtractors() {
        return Ac3Extractor.$r8$lambda$aTV9p5zCruIT3csQt3Vb0LmzMJU();
    }
}
