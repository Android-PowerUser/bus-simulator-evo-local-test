package io.bidmachine.media3.ui;

import android.content.Context;
import android.content.Intent;
import androidx.core.app.NotificationCompat;
import io.bidmachine.media3.common.Player;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface PlayerNotificationManager$CustomActionReceiver {
    Map<String, NotificationCompat.Action> createCustomActions(Context context, int i);

    List<String> getCustomActions(Player player);

    void onCustomAction(Player player, String str, Intent intent);
}
