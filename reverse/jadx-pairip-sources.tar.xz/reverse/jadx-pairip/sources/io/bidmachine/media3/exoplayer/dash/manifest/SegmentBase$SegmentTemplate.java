package io.bidmachine.media3.exoplayer.dash.manifest;

import androidx.annotation.Nullable;
import com.google.common.math.BigIntegerMath;
import io.bidmachine.media3.common.Format;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.List;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class SegmentBase$SegmentTemplate extends SegmentBase.MultiSegmentBase {
    final long endNumber;

    @Nullable
    final UrlTemplate initializationTemplate;

    @Nullable
    final UrlTemplate mediaTemplate;

    public SegmentBase$SegmentTemplate(RangedUri rangedUri, long j, long j2, long j3, long j4, long j5, @Nullable List<SegmentBase.SegmentTimelineElement> list, long j6, @Nullable UrlTemplate urlTemplate, @Nullable UrlTemplate urlTemplate2, long j7, long j8) {
        super(rangedUri, j, j2, j3, j5, list, j6, j7, j8);
        this.initializationTemplate = urlTemplate;
        this.mediaTemplate = urlTemplate2;
        this.endNumber = j4;
    }

    @Nullable
    public RangedUri getInitialization(Representation representation) {
        UrlTemplate urlTemplate = this.initializationTemplate;
        if (urlTemplate != null) {
            Format format = representation.format;
            return new RangedUri(urlTemplate.buildUri(format.id, 0L, format.bitrate, 0L), 0L, -1L);
        }
        return super/*io.bidmachine.media3.exoplayer.dash.manifest.SegmentBase*/.getInitialization(representation);
    }

    public RangedUri getSegmentUrl(Representation representation, long j) {
        long j2;
        List list = ((SegmentBase.MultiSegmentBase) this).segmentTimeline;
        if (list != null) {
            j2 = ((SegmentBase.SegmentTimelineElement) list.get((int) (j - ((SegmentBase.MultiSegmentBase) this).startNumber))).startTime;
        } else {
            j2 = (j - ((SegmentBase.MultiSegmentBase) this).startNumber) * ((SegmentBase.MultiSegmentBase) this).duration;
        }
        long j3 = j2;
        UrlTemplate urlTemplate = this.mediaTemplate;
        Format format = representation.format;
        return new RangedUri(urlTemplate.buildUri(format.id, j, format.bitrate, j3), 0L, -1L);
    }

    public long getSegmentCount(long j) {
        List list = ((SegmentBase.MultiSegmentBase) this).segmentTimeline;
        if (list != null) {
            return list.size();
        }
        long j2 = this.endNumber;
        if (j2 != -1) {
            return (j2 - ((SegmentBase.MultiSegmentBase) this).startNumber) + 1;
        }
        if (j != -9223372036854775807L) {
            return BigIntegerMath.divide(BigInteger.valueOf(j).multiply(BigInteger.valueOf(((SegmentBase) this).timescale)), BigInteger.valueOf(((SegmentBase.MultiSegmentBase) this).duration).multiply(BigInteger.valueOf(1000000L)), RoundingMode.CEILING).longValue();
        }
        return -1L;
    }
}
