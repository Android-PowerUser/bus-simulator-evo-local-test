package io.bidmachine.media3.extractor.jpeg;

import io.bidmachine.media3.extractor.ForwardingSeekMap;
import io.bidmachine.media3.extractor.SeekMap;
import io.bidmachine.media3.extractor.SeekPoint;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class StartOffsetExtractorOutput$1 extends ForwardingSeekMap {
    final /* synthetic */ StartOffsetExtractorOutput this$0;
    final /* synthetic */ SeekMap val$seekMap;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    StartOffsetExtractorOutput$1(StartOffsetExtractorOutput startOffsetExtractorOutput, SeekMap seekMap, SeekMap seekMap2) {
        super(seekMap);
        this.this$0 = startOffsetExtractorOutput;
        this.val$seekMap = seekMap2;
    }

    public SeekMap.SeekPoints getSeekPoints(long j) {
        SeekMap.SeekPoints seekPoints = this.val$seekMap.getSeekPoints(j);
        SeekPoint seekPoint = seekPoints.first;
        SeekPoint seekPoint2 = new SeekPoint(seekPoint.timeUs, seekPoint.position + StartOffsetExtractorOutput.access$000(this.this$0));
        SeekPoint seekPoint3 = seekPoints.second;
        return new SeekMap.SeekPoints(seekPoint2, new SeekPoint(seekPoint3.timeUs, seekPoint3.position + StartOffsetExtractorOutput.access$000(this.this$0)));
    }
}
