package io.bidmachine.media3.exoplayer.drm;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class FrameworkMediaDrm$Api31$$ExternalSyntheticApiModelOutline0 {
}
