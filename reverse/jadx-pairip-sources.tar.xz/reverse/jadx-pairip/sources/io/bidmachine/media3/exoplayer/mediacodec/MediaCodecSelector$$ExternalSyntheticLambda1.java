package io.bidmachine.media3.exoplayer.mediacodec;

import java.util.List;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class MediaCodecSelector$$ExternalSyntheticLambda1 implements MediaCodecSelector {
    public final List getDecoderInfos(String str, boolean z, boolean z2) {
        return MediaCodecSelector.$r8$lambda$hFJmHe_MfBd4pSJzlXdPH7bQu8U(str, z, z2);
    }
}
