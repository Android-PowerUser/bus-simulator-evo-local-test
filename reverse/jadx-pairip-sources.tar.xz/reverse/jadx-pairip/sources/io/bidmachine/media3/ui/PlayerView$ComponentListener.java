package io.bidmachine.media3.ui;

import android.view.SurfaceView;
import android.view.View;
import androidx.annotation.Nullable;
import io.bidmachine.media3.common.Player;
import io.bidmachine.media3.common.Timeline;
import io.bidmachine.media3.common.Tracks;
import io.bidmachine.media3.common.VideoSize;
import io.bidmachine.media3.common.text.CueGroup;
import io.bidmachine.media3.common.util.Assertions;
import io.bidmachine.media3.common.util.Util;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class PlayerView$ComponentListener implements Player.Listener, View.OnClickListener, PlayerControlView.VisibilityListener, PlayerControlView.OnFullScreenModeChangedListener {

    @Nullable
    private Object lastPeriodUidWithTracks;
    private final Timeline.Period period = new Timeline.Period();
    final /* synthetic */ PlayerView this$0;

    public PlayerView$ComponentListener(PlayerView playerView) {
        this.this$0 = playerView;
    }

    public void onCues(CueGroup cueGroup) {
        if (PlayerView.access$100(this.this$0) != null) {
            PlayerView.access$100(this.this$0).setCues(cueGroup.cues);
        }
    }

    public void onVideoSizeChanged(VideoSize videoSize) {
        if (videoSize.equals(VideoSize.UNKNOWN) || PlayerView.access$200(this.this$0) == null || PlayerView.access$200(this.this$0).getPlaybackState() == 1) {
            return;
        }
        PlayerView.access$300(this.this$0);
    }

    public void onSurfaceSizeChanged(int i, int i2) {
        if (Util.SDK_INT == 34 && (PlayerView.access$400(this.this$0) instanceof SurfaceView) && PlayerView.access$500(this.this$0)) {
            ((PlayerView.SurfaceSyncGroupCompatV34) Assertions.checkNotNull(PlayerView.access$700(this.this$0))).postRegister(PlayerView.access$600(this.this$0), (SurfaceView) PlayerView.access$400(this.this$0), new PlayerView$ComponentListener$.ExternalSyntheticLambda0(this.this$0));
        }
    }

    public void onRenderedFirstFrame() {
        if (PlayerView.access$800(this.this$0) != null) {
            PlayerView.access$800(this.this$0).setVisibility(4);
            if (PlayerView.access$900(this.this$0)) {
                PlayerView.access$1000(this.this$0);
            } else {
                PlayerView.access$1100(this.this$0);
            }
        }
    }

    public void onTracksChanged(Tracks tracks) {
        Timeline currentTimeline;
        Player player = (Player) Assertions.checkNotNull(PlayerView.access$200(this.this$0));
        if (player.isCommandAvailable(17)) {
            currentTimeline = player.getCurrentTimeline();
        } else {
            currentTimeline = Timeline.EMPTY;
        }
        if (currentTimeline.isEmpty()) {
            this.lastPeriodUidWithTracks = null;
        } else if (player.isCommandAvailable(30) && !player.getCurrentTracks().isEmpty()) {
            this.lastPeriodUidWithTracks = currentTimeline.getPeriod(player.getCurrentPeriodIndex(), this.period, true).uid;
        } else {
            Object obj = this.lastPeriodUidWithTracks;
            if (obj != null) {
                int indexOfPeriod = currentTimeline.getIndexOfPeriod(obj);
                if (indexOfPeriod != -1) {
                    if (player.getCurrentMediaItemIndex() == currentTimeline.getPeriod(indexOfPeriod, this.period).windowIndex) {
                        return;
                    }
                }
                this.lastPeriodUidWithTracks = null;
            }
        }
        PlayerView.access$1200(this.this$0, false);
    }

    public void onPlaybackStateChanged(int i) {
        PlayerView.access$1300(this.this$0);
        PlayerView.access$1400(this.this$0);
        PlayerView.access$1500(this.this$0);
    }

    public void onPlayWhenReadyChanged(boolean z, int i) {
        PlayerView.access$1300(this.this$0);
        PlayerView.access$1500(this.this$0);
    }

    public void onPositionDiscontinuity(Player.PositionInfo positionInfo, Player.PositionInfo positionInfo2, int i) {
        if (PlayerView.access$1600(this.this$0) && PlayerView.access$1700(this.this$0)) {
            this.this$0.hideController();
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        PlayerView.access$1800(this.this$0);
    }

    public void onVisibilityChange(int i) {
        PlayerView.access$1900(this.this$0);
        if (PlayerView.access$2000(this.this$0) != null) {
            PlayerView.access$2000(this.this$0).onVisibilityChanged(i);
        }
    }

    public void onFullScreenModeChanged(boolean z) {
        if (PlayerView.access$2100(this.this$0) != null) {
            PlayerView.access$2100(this.this$0).onFullscreenButtonClick(z);
        }
    }
}
