package io.bidmachine.media3.exoplayer.video;

import android.content.Context;
import android.os.Handler;
import androidx.annotation.Nullable;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import io.bidmachine.media3.common.util.Assertions;
import io.bidmachine.media3.exoplayer.mediacodec.MediaCodecAdapter$Factory;
import io.bidmachine.media3.exoplayer.mediacodec.MediaCodecSelector;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class MediaCodecVideoRenderer$Builder {
    private long allowedJoiningTimeMs;
    private boolean buildCalled;
    private MediaCodecAdapter$Factory codecAdapterFactory;
    private final Context context;
    private boolean enableDecoderFallback;

    @Nullable
    private Handler eventHandler;

    @Nullable
    private VideoRendererEventListener eventListener;
    private int maxDroppedFramesToNotify;
    private boolean parseAv1SampleDependencies;

    @Nullable
    private VideoSink videoSink;
    private MediaCodecSelector mediaCodecSelector = MediaCodecSelector.DEFAULT;
    private float assumedMinimumCodecOperatingRate = 30.0f;
    private long lateThresholdToDropDecoderInputUs = -9223372036854775807L;

    public MediaCodecVideoRenderer$Builder(Context context) {
        this.context = context;
        this.codecAdapterFactory = MediaCodecAdapter$Factory.getDefault(context);
    }

    @CanIgnoreReturnValue
    public MediaCodecVideoRenderer$Builder setMediaCodecSelector(MediaCodecSelector mediaCodecSelector) {
        this.mediaCodecSelector = mediaCodecSelector;
        return this;
    }

    @CanIgnoreReturnValue
    public MediaCodecVideoRenderer$Builder setCodecAdapterFactory(MediaCodecAdapter$Factory mediaCodecAdapter$Factory) {
        this.codecAdapterFactory = mediaCodecAdapter$Factory;
        return this;
    }

    @CanIgnoreReturnValue
    public MediaCodecVideoRenderer$Builder setAllowedJoiningTimeMs(long j) {
        this.allowedJoiningTimeMs = j;
        return this;
    }

    @CanIgnoreReturnValue
    public MediaCodecVideoRenderer$Builder setEnableDecoderFallback(boolean z) {
        this.enableDecoderFallback = z;
        return this;
    }

    @CanIgnoreReturnValue
    public MediaCodecVideoRenderer$Builder setEventHandler(@Nullable Handler handler) {
        this.eventHandler = handler;
        return this;
    }

    @CanIgnoreReturnValue
    public MediaCodecVideoRenderer$Builder setEventListener(@Nullable VideoRendererEventListener videoRendererEventListener) {
        this.eventListener = videoRendererEventListener;
        return this;
    }

    @CanIgnoreReturnValue
    public MediaCodecVideoRenderer$Builder setMaxDroppedFramesToNotify(int i) {
        this.maxDroppedFramesToNotify = i;
        return this;
    }

    @CanIgnoreReturnValue
    public MediaCodecVideoRenderer$Builder setAssumedMinimumCodecOperatingRate(float f) {
        this.assumedMinimumCodecOperatingRate = f;
        return this;
    }

    @CanIgnoreReturnValue
    public MediaCodecVideoRenderer$Builder setVideoSink(@Nullable VideoSink videoSink) {
        this.videoSink = videoSink;
        return this;
    }

    @CanIgnoreReturnValue
    public MediaCodecVideoRenderer$Builder experimentalSetParseAv1SampleDependencies(boolean z) {
        this.parseAv1SampleDependencies = z;
        return this;
    }

    @CanIgnoreReturnValue
    public MediaCodecVideoRenderer$Builder experimentalSetLateThresholdToDropDecoderInputUs(long j) {
        this.lateThresholdToDropDecoderInputUs = j;
        return this;
    }

    public MediaCodecVideoRenderer build() {
        Assertions.checkState(!this.buildCalled);
        Handler handler = this.eventHandler;
        Assertions.checkState((handler == null && this.eventListener == null) || !(handler == null || this.eventListener == null));
        this.buildCalled = true;
        return new MediaCodecVideoRenderer(this);
    }
}
