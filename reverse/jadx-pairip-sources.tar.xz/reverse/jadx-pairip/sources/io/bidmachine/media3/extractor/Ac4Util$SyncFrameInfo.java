package io.bidmachine.media3.extractor;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class Ac4Util$SyncFrameInfo {
    public final int bitstreamVersion;
    public final int channelCount;
    public final int frameSize;
    public final int sampleCount;
    public final int sampleRate;

    private Ac4Util$SyncFrameInfo(int i, int i2, int i3, int i4, int i5) {
        this.bitstreamVersion = i;
        this.channelCount = i2;
        this.sampleRate = i3;
        this.frameSize = i4;
        this.sampleCount = i5;
    }
}
