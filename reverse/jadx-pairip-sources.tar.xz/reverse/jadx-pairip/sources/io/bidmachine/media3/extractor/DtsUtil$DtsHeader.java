package io.bidmachine.media3.extractor;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class DtsUtil$DtsHeader {
    public final int bitrate;
    public final int channelCount;
    public final long frameDurationUs;
    public final int frameSize;
    public final String mimeType;
    public final int sampleRate;

    private DtsUtil$DtsHeader(String str, int i, int i2, int i3, long j, int i4) {
        this.mimeType = str;
        this.channelCount = i;
        this.sampleRate = i2;
        this.frameSize = i3;
        this.frameDurationUs = j;
        this.bitrate = i4;
    }
}
