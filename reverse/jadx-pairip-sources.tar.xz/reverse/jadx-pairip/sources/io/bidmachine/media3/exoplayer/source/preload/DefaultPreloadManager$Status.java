package io.bidmachine.media3.exoplayer.source.preload;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class DefaultPreloadManager$Status implements TargetPreloadStatusControl.PreloadStatus {
    public static final int STAGE_LOADED_FOR_DURATION_MS = 2;
    public static final int STAGE_SOURCE_PREPARED = 0;
    public static final int STAGE_TRACKS_SELECTED = 1;
    private final int stage;
    private final long value;

    @Target({ElementType.TYPE_USE})
    @Documented
    @Retention(RetentionPolicy.SOURCE)
    public @interface Stage {
    }

    public DefaultPreloadManager$Status(int i, long j) {
        this.stage = i;
        this.value = j;
    }

    public DefaultPreloadManager$Status(int i) {
        this(i, -9223372036854775807L);
    }

    public int getStage() {
        return this.stage;
    }

    public long getValue() {
        return this.value;
    }
}
