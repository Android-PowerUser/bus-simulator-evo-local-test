package io.bidmachine.media3.exoplayer.drm;

import com.google.common.util.concurrent.SettableFuture;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class OfflineLicenseHelper$$ExternalSyntheticLambda2 implements Runnable {
    public final /* synthetic */ OfflineLicenseHelper f$0;
    public final /* synthetic */ SettableFuture f$1;

    public /* synthetic */ OfflineLicenseHelper$$ExternalSyntheticLambda2(OfflineLicenseHelper offlineLicenseHelper, SettableFuture settableFuture) {
        this.f$0 = offlineLicenseHelper;
        this.f$1 = settableFuture;
    }

    @Override // java.lang.Runnable
    public final void run() {
        OfflineLicenseHelper.$r8$lambda$w_IrQvZNKVfuUkjBX6fT5gRoSaQ(this.f$0, this.f$1);
    }
}
