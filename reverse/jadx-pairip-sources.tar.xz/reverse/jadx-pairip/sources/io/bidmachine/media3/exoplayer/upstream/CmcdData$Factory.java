package io.bidmachine.media3.exoplayer.upstream;

import androidx.annotation.Nullable;
import com.google.common.collect.ImmutableListMultimap;
import com.google.common.collect.UnmodifiableIterator;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import io.bidmachine.media3.common.Format;
import io.bidmachine.media3.common.MimeTypes;
import io.bidmachine.media3.common.TrackGroup;
import io.bidmachine.media3.common.util.Assertions;
import io.bidmachine.media3.common.util.Util;
import io.bidmachine.media3.exoplayer.trackselection.ExoTrackSelection;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class CmcdData$Factory {
    private static final Pattern CUSTOM_KEY_NAME_PATTERN = Pattern.compile(".*-.*");
    private final CmcdConfiguration cmcdConfiguration;
    private boolean didRebuffer;
    private boolean isBufferEmpty;

    @Nullable
    private Boolean isLive;

    @Nullable
    private String nextObjectRequest;

    @Nullable
    private String nextRangeRequest;

    @Nullable
    private String objectType;
    private final String streamingFormat;

    @Nullable
    private ExoTrackSelection trackSelection;
    private long bufferedDurationUs = -9223372036854775807L;
    private float playbackRate = -3.4028235E38f;
    private long chunkDurationUs = -9223372036854775807L;

    public CmcdData$Factory(CmcdConfiguration cmcdConfiguration, String str) {
        this.cmcdConfiguration = cmcdConfiguration;
        this.streamingFormat = str;
    }

    @CanIgnoreReturnValue
    public CmcdData$Factory setChunkDurationUs(long j) {
        Assertions.checkArgument(j >= 0);
        this.chunkDurationUs = j;
        return this;
    }

    @CanIgnoreReturnValue
    public CmcdData$Factory setObjectType(@Nullable String str) {
        this.objectType = str;
        return this;
    }

    @CanIgnoreReturnValue
    public CmcdData$Factory setNextObjectRequest(@Nullable String str) {
        this.nextObjectRequest = str;
        return this;
    }

    @CanIgnoreReturnValue
    public CmcdData$Factory setNextRangeRequest(@Nullable String str) {
        this.nextRangeRequest = str;
        return this;
    }

    @CanIgnoreReturnValue
    public CmcdData$Factory setTrackSelection(ExoTrackSelection exoTrackSelection) {
        this.trackSelection = exoTrackSelection;
        return this;
    }

    @CanIgnoreReturnValue
    public CmcdData$Factory setBufferedDurationUs(long j) {
        Assertions.checkArgument(j >= 0);
        this.bufferedDurationUs = j;
        return this;
    }

    @CanIgnoreReturnValue
    public CmcdData$Factory setPlaybackRate(float f) {
        Assertions.checkArgument(f == -3.4028235E38f || f > 0.0f);
        this.playbackRate = f;
        return this;
    }

    @CanIgnoreReturnValue
    public CmcdData$Factory setIsLive(boolean z) {
        this.isLive = Boolean.valueOf(z);
        return this;
    }

    @CanIgnoreReturnValue
    public CmcdData$Factory setDidRebuffer(boolean z) {
        this.didRebuffer = z;
        return this;
    }

    @CanIgnoreReturnValue
    public CmcdData$Factory setIsBufferEmpty(boolean z) {
        this.isBufferEmpty = z;
        return this;
    }

    public CmcdData createCmcdData() {
        int iCeilDivide;
        int requestedMaximumThroughputKbps;
        int iCeilDivide2;
        boolean zIsManifestObjectType = isManifestObjectType(this.objectType);
        if (!zIsManifestObjectType) {
            Assertions.checkStateNotNull(this.trackSelection, "Track selection must be set");
        }
        if (this.objectType == null) {
            this.objectType = getObjectTypeFromFormat(((ExoTrackSelection) Assertions.checkNotNull(this.trackSelection)).getSelectedFormat());
        }
        boolean zIsMediaObjectType = isMediaObjectType(this.objectType);
        boolean z = true;
        if (zIsMediaObjectType) {
            Assertions.checkState(this.bufferedDurationUs != -9223372036854775807L, "Buffered duration must be set");
            Assertions.checkState(this.chunkDurationUs != -9223372036854775807L, "Chunk duration must be set");
        }
        ImmutableListMultimap customData = this.cmcdConfiguration.requestConfig.getCustomData();
        UnmodifiableIterator it = customData.m852keySet().iterator();
        while (it.hasNext()) {
            validateCustomDataListFormat(customData.get((String) it.next()));
        }
        long jCeilDivide = -2147483647L;
        if (zIsManifestObjectType) {
            iCeilDivide = -2147483647;
            requestedMaximumThroughputKbps = -2147483647;
            iCeilDivide2 = -2147483647;
        } else {
            ExoTrackSelection exoTrackSelection = (ExoTrackSelection) Assertions.checkNotNull(this.trackSelection);
            int iMax = exoTrackSelection.getSelectedFormat().bitrate;
            iCeilDivide = Util.ceilDivide(iMax, 1000);
            TrackGroup trackGroup = exoTrackSelection.getTrackGroup();
            for (int i = 0; i < trackGroup.length; i++) {
                iMax = Math.max(iMax, trackGroup.getFormat(i).bitrate);
            }
            iCeilDivide2 = Util.ceilDivide(iMax, 1000);
            jCeilDivide = exoTrackSelection.getLatestBitrateEstimate() != -2147483647L ? Util.ceilDivide(exoTrackSelection.getLatestBitrateEstimate(), 1000L) : -2147483647L;
            requestedMaximumThroughputKbps = this.cmcdConfiguration.requestConfig.getRequestedMaximumThroughputKbps(iCeilDivide);
        }
        CmcdData.CmcdObject.Builder builder = new CmcdData.CmcdObject.Builder();
        if (this.cmcdConfiguration.isBitrateLoggingAllowed()) {
            builder.setBitrateKbps(iCeilDivide);
        }
        if (this.cmcdConfiguration.isTopBitrateLoggingAllowed()) {
            builder.setTopBitrateKbps(iCeilDivide2);
        }
        if (zIsMediaObjectType && this.cmcdConfiguration.isObjectDurationLoggingAllowed()) {
            builder.setObjectDurationMs(Util.usToMs(this.chunkDurationUs));
        }
        if (this.cmcdConfiguration.isObjectTypeLoggingAllowed()) {
            builder.setObjectType(this.objectType);
        }
        if (customData.containsKey("CMCD-Object")) {
            builder.setCustomDataList(customData.get("CMCD-Object"));
        }
        CmcdData.CmcdRequest.Builder builder2 = new CmcdData.CmcdRequest.Builder();
        if (zIsMediaObjectType) {
            if (this.cmcdConfiguration.isBufferLengthLoggingAllowed()) {
                builder2.setBufferLengthMs(Util.usToMs(this.bufferedDurationUs));
            }
            if (this.cmcdConfiguration.isDeadlineLoggingAllowed()) {
                builder2.setDeadlineMs(Util.usToMs((long) (this.bufferedDurationUs / this.playbackRate)));
            }
        }
        if (this.cmcdConfiguration.isMeasuredThroughputLoggingAllowed()) {
            builder2.setMeasuredThroughputInKbps(jCeilDivide);
        }
        if (this.cmcdConfiguration.isStartupLoggingAllowed()) {
            if (!this.didRebuffer && !this.isBufferEmpty) {
                z = false;
            }
            builder2.setStartup(z);
        }
        if (this.cmcdConfiguration.isNextObjectRequestLoggingAllowed()) {
            builder2.setNextObjectRequest(this.nextObjectRequest);
        }
        if (this.cmcdConfiguration.isNextRangeRequestLoggingAllowed()) {
            builder2.setNextRangeRequest(this.nextRangeRequest);
        }
        if (customData.containsKey("CMCD-Request")) {
            builder2.setCustomDataList(customData.get("CMCD-Request"));
        }
        CmcdData.CmcdSession.Builder builder3 = new CmcdData.CmcdSession.Builder();
        if (this.cmcdConfiguration.isContentIdLoggingAllowed()) {
            builder3.setContentId(this.cmcdConfiguration.contentId);
        }
        if (this.cmcdConfiguration.isSessionIdLoggingAllowed()) {
            builder3.setSessionId(this.cmcdConfiguration.sessionId);
        }
        if (this.cmcdConfiguration.isStreamingFormatLoggingAllowed()) {
            builder3.setStreamingFormat(this.streamingFormat);
        }
        if (this.isLive != null && this.cmcdConfiguration.isStreamTypeLoggingAllowed()) {
            builder3.setStreamType(((Boolean) Assertions.checkNotNull(this.isLive)).booleanValue() ? "l" : "v");
        }
        if (this.cmcdConfiguration.isPlaybackRateLoggingAllowed()) {
            builder3.setPlaybackRate(this.playbackRate);
        }
        if (customData.containsKey("CMCD-Session")) {
            builder3.setCustomDataList(customData.get("CMCD-Session"));
        }
        CmcdData$CmcdStatus.Builder builder4 = new CmcdData$CmcdStatus.Builder();
        if (this.cmcdConfiguration.isMaximumRequestThroughputLoggingAllowed()) {
            builder4.setMaximumRequestedThroughputKbps(requestedMaximumThroughputKbps);
        }
        if (this.cmcdConfiguration.isBufferStarvationLoggingAllowed()) {
            builder4.setBufferStarvation(this.didRebuffer);
        }
        if (customData.containsKey("CMCD-Status")) {
            builder4.setCustomDataList(customData.get("CMCD-Status"));
        }
        return new CmcdData(builder.build(), builder2.build(), builder3.build(), builder4.build(), this.cmcdConfiguration.dataTransmissionMode, (CmcdData.1) null);
    }

    @Nullable
    private static String getObjectTypeFromFormat(Format format) {
        String audioMediaMimeType = MimeTypes.getAudioMediaMimeType(format.codecs);
        String videoMediaMimeType = MimeTypes.getVideoMediaMimeType(format.codecs);
        if (audioMediaMimeType != null && videoMediaMimeType != null) {
            return "av";
        }
        int trackType = MimeTypes.getTrackType(format.sampleMimeType);
        if (trackType == -1) {
            trackType = MimeTypes.getTrackType(format.containerMimeType);
        }
        if (trackType == 1) {
            return "a";
        }
        if (trackType == 2) {
            return "v";
        }
        return null;
    }

    private static boolean isManifestObjectType(@Nullable String str) {
        return Objects.equals(str, "m");
    }

    private static boolean isMediaObjectType(@Nullable String str) {
        return Objects.equals(str, "a") || Objects.equals(str, "v") || Objects.equals(str, "av");
    }

    private void validateCustomDataListFormat(List<String> list) {
        Iterator<String> it = list.iterator();
        while (it.hasNext()) {
            Assertions.checkState(CUSTOM_KEY_NAME_PATTERN.matcher(Util.split(it.next(), "=")[0]).matches());
        }
    }
}
