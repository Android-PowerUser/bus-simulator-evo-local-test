package io.bidmachine.media3.exoplayer.drm;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface DefaultDrmSession$ReferenceCountListener {
    void onReferenceCountDecremented(DefaultDrmSession defaultDrmSession, int i);

    void onReferenceCountIncremented(DefaultDrmSession defaultDrmSession, int i);
}
