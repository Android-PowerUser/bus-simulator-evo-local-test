package io.bidmachine.media3.exoplayer.mediacodec;

import android.content.Context;
import java.io.IOException;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface MediaCodecAdapter$Factory {

    @Deprecated
    public static final MediaCodecAdapter$Factory DEFAULT = new DefaultMediaCodecAdapterFactory();

    MediaCodecAdapter createAdapter(MediaCodecAdapter.Configuration configuration) throws IOException;

    static MediaCodecAdapter$Factory getDefault(Context context) {
        return new DefaultMediaCodecAdapterFactory(context);
    }
}
