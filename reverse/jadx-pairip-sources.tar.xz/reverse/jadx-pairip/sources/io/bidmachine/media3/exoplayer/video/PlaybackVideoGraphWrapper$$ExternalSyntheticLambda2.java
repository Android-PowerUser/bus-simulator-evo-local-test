package io.bidmachine.media3.exoplayer.video;

import io.bidmachine.media3.common.util.HandlerWrapper;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class PlaybackVideoGraphWrapper$$ExternalSyntheticLambda2 implements Executor {
    public final /* synthetic */ HandlerWrapper f$0;

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        this.f$0.post(runnable);
    }
}
