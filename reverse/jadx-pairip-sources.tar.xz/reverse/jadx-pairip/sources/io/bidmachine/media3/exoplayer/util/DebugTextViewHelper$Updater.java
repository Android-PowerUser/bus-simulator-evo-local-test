package io.bidmachine.media3.exoplayer.util;

import io.bidmachine.media3.common.Player;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class DebugTextViewHelper$Updater implements Player.Listener, Runnable {
    final /* synthetic */ DebugTextViewHelper this$0;

    private DebugTextViewHelper$Updater(DebugTextViewHelper debugTextViewHelper) {
        this.this$0 = debugTextViewHelper;
    }

    public void onPlaybackStateChanged(int i) {
        this.this$0.updateAndPost();
    }

    public void onPlayWhenReadyChanged(boolean z, int i) {
        this.this$0.updateAndPost();
    }

    public void onPositionDiscontinuity(Player.PositionInfo positionInfo, Player.PositionInfo positionInfo2, int i) {
        this.this$0.updateAndPost();
    }

    @Override // java.lang.Runnable
    public void run() {
        this.this$0.updateAndPost();
    }
}
