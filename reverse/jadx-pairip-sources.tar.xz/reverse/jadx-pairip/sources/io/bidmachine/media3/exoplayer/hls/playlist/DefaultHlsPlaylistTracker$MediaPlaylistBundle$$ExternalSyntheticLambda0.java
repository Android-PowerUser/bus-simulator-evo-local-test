package io.bidmachine.media3.exoplayer.hls.playlist;

import android.net.Uri;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class DefaultHlsPlaylistTracker$MediaPlaylistBundle$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ DefaultHlsPlaylistTracker.MediaPlaylistBundle f$0;
    public final /* synthetic */ Uri f$1;

    public /* synthetic */ DefaultHlsPlaylistTracker$MediaPlaylistBundle$$ExternalSyntheticLambda0(DefaultHlsPlaylistTracker.MediaPlaylistBundle mediaPlaylistBundle, Uri uri) {
        this.f$0 = mediaPlaylistBundle;
        this.f$1 = uri;
    }

    @Override // java.lang.Runnable
    public final void run() {
        DefaultHlsPlaylistTracker.MediaPlaylistBundle.$r8$lambda$UyzKWroAtZ3FTMs2Qakaci8F5eU(this.f$0, this.f$1);
    }
}
