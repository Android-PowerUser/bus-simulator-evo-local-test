package io.bidmachine.media3.ui;

import android.app.Notification;
import android.media.session.MediaSession;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationBuilderWithBuilderAccessor;
import androidx.core.app.NotificationCompat;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class PlayerNotificationManager$MediaStyle extends NotificationCompat.Style {
    private final int[] actionsToShowInCompact;

    @Nullable
    private final MediaSession.Token token;

    public PlayerNotificationManager$MediaStyle(@Nullable MediaSession.Token token, int[] iArr) {
        this.token = token;
        this.actionsToShowInCompact = iArr;
    }

    public void apply(NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
        Notification.MediaStyle mediaStyle = new Notification.MediaStyle();
        mediaStyle.setShowActionsInCompactView(this.actionsToShowInCompact);
        MediaSession.Token token = this.token;
        if (token != null) {
            mediaStyle.setMediaSession(token);
        }
        notificationBuilderWithBuilderAccessor.getBuilder().setStyle(mediaStyle);
    }
}
