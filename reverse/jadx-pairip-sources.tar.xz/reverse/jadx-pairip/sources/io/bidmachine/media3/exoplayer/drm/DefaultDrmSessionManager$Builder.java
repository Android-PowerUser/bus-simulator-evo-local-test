package io.bidmachine.media3.exoplayer.drm;

import androidx.annotation.Nullable;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import io.bidmachine.media3.common.C;
import io.bidmachine.media3.common.util.Assertions;
import io.bidmachine.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy;
import io.bidmachine.media3.exoplayer.upstream.LoadErrorHandlingPolicy;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class DefaultDrmSessionManager$Builder {
    private boolean multiSession;
    private final HashMap<String, String> keyRequestParameters = new HashMap<>();
    private UUID uuid = C.WIDEVINE_UUID;
    private ExoMediaDrm.Provider exoMediaDrmProvider = FrameworkMediaDrm.DEFAULT_PROVIDER;
    private int[] useDrmSessionsForClearContentTrackTypes = new int[0];
    private boolean playClearSamplesWithoutKeys = true;
    private LoadErrorHandlingPolicy loadErrorHandlingPolicy = new DefaultLoadErrorHandlingPolicy();
    private long sessionKeepaliveMs = 300000;

    @CanIgnoreReturnValue
    public DefaultDrmSessionManager$Builder setKeyRequestParameters(@Nullable Map<String, String> map) {
        this.keyRequestParameters.clear();
        if (map != null) {
            this.keyRequestParameters.putAll(map);
        }
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultDrmSessionManager$Builder setUuidAndExoMediaDrmProvider(UUID uuid, ExoMediaDrm.Provider provider) {
        this.uuid = (UUID) Assertions.checkNotNull(uuid);
        this.exoMediaDrmProvider = (ExoMediaDrm.Provider) Assertions.checkNotNull(provider);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultDrmSessionManager$Builder setMultiSession(boolean z) {
        this.multiSession = z;
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultDrmSessionManager$Builder setUseDrmSessionsForClearContent(int... iArr) {
        for (int i : iArr) {
            boolean z = true;
            if (i != 2 && i != 1) {
                z = false;
            }
            Assertions.checkArgument(z);
        }
        this.useDrmSessionsForClearContentTrackTypes = (int[]) iArr.clone();
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultDrmSessionManager$Builder setPlayClearSamplesWithoutKeys(boolean z) {
        this.playClearSamplesWithoutKeys = z;
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultDrmSessionManager$Builder setLoadErrorHandlingPolicy(LoadErrorHandlingPolicy loadErrorHandlingPolicy) {
        this.loadErrorHandlingPolicy = (LoadErrorHandlingPolicy) Assertions.checkNotNull(loadErrorHandlingPolicy);
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultDrmSessionManager$Builder setSessionKeepaliveMs(long j) {
        Assertions.checkArgument(j > 0 || j == -9223372036854775807L);
        this.sessionKeepaliveMs = j;
        return this;
    }

    public DefaultDrmSessionManager build(MediaDrmCallback mediaDrmCallback) {
        return new DefaultDrmSessionManager(this.uuid, this.exoMediaDrmProvider, mediaDrmCallback, this.keyRequestParameters, this.multiSession, this.useDrmSessionsForClearContentTrackTypes, this.playClearSamplesWithoutKeys, this.loadErrorHandlingPolicy, this.sessionKeepaliveMs, (DefaultDrmSessionManager.1) null);
    }
}
