package io.bidmachine.media3.common.text;

import io.bidmachine.media3.common.util.UnstableApi;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@UnstableApi
public final class HorizontalTextInVerticalContextSpan implements LanguageFeatureSpan {
}
