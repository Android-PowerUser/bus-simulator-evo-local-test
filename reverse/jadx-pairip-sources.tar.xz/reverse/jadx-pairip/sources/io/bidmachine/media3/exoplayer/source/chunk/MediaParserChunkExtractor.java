package io.bidmachine.media3.exoplayer.source.chunk;

import android.annotation.SuppressLint;
import android.media.MediaParser;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.media3.exoplayer.source.MediaParserExtractorAdapter$;
import androidx.media3.exoplayer.source.chunk.MediaParserChunkExtractor$;
import io.bidmachine.media3.common.Format;
import io.bidmachine.media3.common.MimeTypes;
import io.bidmachine.media3.common.util.Assertions;
import io.bidmachine.media3.common.util.UnstableApi;
import io.bidmachine.media3.common.util.Util;
import io.bidmachine.media3.exoplayer.analytics.PlayerId;
import io.bidmachine.media3.exoplayer.source.mediaparser.InputReaderAdapterV30;
import io.bidmachine.media3.exoplayer.source.mediaparser.MediaParserUtil;
import io.bidmachine.media3.exoplayer.source.mediaparser.OutputConsumerAdapterV30;
import io.bidmachine.media3.extractor.ChunkIndex;
import io.bidmachine.media3.extractor.DiscardingTrackOutput;
import io.bidmachine.media3.extractor.ExtractorInput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@RequiresApi(30)
@UnstableApi
public final class MediaParserChunkExtractor implements ChunkExtractor {

    @Deprecated
    public static final ChunkExtractor.Factory FACTORY = new Factory();
    private static final String TAG = "MediaPrsrChunkExtractor";
    private final DiscardingTrackOutput discardingTrackOutput;
    private final InputReaderAdapterV30 inputReaderAdapter;
    private final MediaParser mediaParser;
    private final OutputConsumerAdapterV30 outputConsumerAdapter;
    private long pendingSeekUs;

    @Nullable
    private Format[] sampleFormats;

    @Nullable
    private ChunkExtractor.TrackOutputProvider trackOutputProvider;
    private final TrackOutputProviderAdapter trackOutputProviderAdapter;

    @SuppressLint({"WrongConstant"})
    public MediaParserChunkExtractor(int i, Format format, List<Format> list, PlayerId playerId) {
        OutputConsumerAdapterV30 outputConsumerAdapterV30 = new OutputConsumerAdapterV30(format, i, true);
        this.outputConsumerAdapter = outputConsumerAdapterV30;
        this.inputReaderAdapter = new InputReaderAdapterV30();
        String str = MimeTypes.isMatroska((String) Assertions.checkNotNull(format.containerMimeType)) ? "android.media.mediaparser.MatroskaParser" : "android.media.mediaparser.FragmentedMp4Parser";
        outputConsumerAdapterV30.setSelectedParserName(str);
        MediaParser mediaParserM = MediaParserChunkExtractor$.ExternalSyntheticApiModelOutline1.m(str, outputConsumerAdapterV30);
        this.mediaParser = mediaParserM;
        Boolean bool = Boolean.TRUE;
        MediaParserExtractorAdapter$.ExternalSyntheticApiModelOutline1.m(mediaParserM, "android.media.mediaparser.matroska.disableCuesSeeking", bool);
        MediaParserExtractorAdapter$.ExternalSyntheticApiModelOutline1.m(mediaParserM, "android.media.mediaparser.inBandCryptoInfo", bool);
        MediaParserExtractorAdapter$.ExternalSyntheticApiModelOutline1.m(mediaParserM, "android.media.mediaparser.includeSupplementalData", bool);
        MediaParserExtractorAdapter$.ExternalSyntheticApiModelOutline1.m(mediaParserM, "android.media.mediaparser.eagerlyExposeTrackType", bool);
        MediaParserExtractorAdapter$.ExternalSyntheticApiModelOutline1.m(mediaParserM, "android.media.mediaparser.exposeDummySeekMap", bool);
        MediaParserExtractorAdapter$.ExternalSyntheticApiModelOutline1.m(mediaParserM, "android.media.mediaParser.exposeChunkIndexAsMediaFormat", bool);
        MediaParserExtractorAdapter$.ExternalSyntheticApiModelOutline1.m(mediaParserM, "android.media.mediaParser.overrideInBandCaptionDeclarations", bool);
        ArrayList arrayList = new ArrayList();
        for (int i2 = 0; i2 < list.size(); i2++) {
            arrayList.add(MediaParserUtil.toCaptionsMediaFormat(list.get(i2)));
        }
        MediaParserExtractorAdapter$.ExternalSyntheticApiModelOutline1.m(this.mediaParser, "android.media.mediaParser.exposeCaptionFormats", arrayList);
        if (Util.SDK_INT >= 31) {
            MediaParserUtil.setLogSessionIdOnMediaParser(this.mediaParser, playerId);
        }
        this.outputConsumerAdapter.setMuxedCaptionFormats(list);
        this.trackOutputProviderAdapter = new TrackOutputProviderAdapter(this, (1) null);
        this.discardingTrackOutput = new DiscardingTrackOutput();
        this.pendingSeekUs = -9223372036854775807L;
    }

    public void init(@Nullable ChunkExtractor.TrackOutputProvider trackOutputProvider, long j, long j2) {
        this.trackOutputProvider = trackOutputProvider;
        this.outputConsumerAdapter.setSampleTimestampUpperLimitFilterUs(j2);
        this.outputConsumerAdapter.setExtractorOutput(this.trackOutputProviderAdapter);
        this.pendingSeekUs = j;
    }

    public void release() {
        MediaParserExtractorAdapter$.ExternalSyntheticApiModelOutline6.m(this.mediaParser);
    }

    public boolean read(ExtractorInput extractorInput) throws IOException {
        maybeExecutePendingSeek();
        this.inputReaderAdapter.setDataReader(extractorInput, extractorInput.getLength());
        return MediaParserExtractorAdapter$.ExternalSyntheticApiModelOutline2.m(this.mediaParser, this.inputReaderAdapter);
    }

    @Nullable
    public ChunkIndex getChunkIndex() {
        return this.outputConsumerAdapter.getChunkIndex();
    }

    @Nullable
    public Format[] getSampleFormats() {
        return this.sampleFormats;
    }

    private void maybeExecutePendingSeek() {
        MediaParser.SeekMap dummySeekMap = this.outputConsumerAdapter.getDummySeekMap();
        long j = this.pendingSeekUs;
        if (j == -9223372036854775807L || dummySeekMap == null) {
            return;
        }
        MediaParserExtractorAdapter$.ExternalSyntheticApiModelOutline5.m(this.mediaParser, (MediaParser.SeekPoint) MediaParserChunkExtractor$.ExternalSyntheticApiModelOutline0.m(dummySeekMap, j).first);
        this.pendingSeekUs = -9223372036854775807L;
    }
}
