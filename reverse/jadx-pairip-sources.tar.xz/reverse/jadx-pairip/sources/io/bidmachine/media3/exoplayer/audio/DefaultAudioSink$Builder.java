package io.bidmachine.media3.exoplayer.audio;

import android.content.Context;
import androidx.annotation.Nullable;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import io.bidmachine.media3.common.audio.AudioProcessor;
import io.bidmachine.media3.common.audio.AudioProcessorChain;
import io.bidmachine.media3.common.util.Assertions;
import io.bidmachine.media3.exoplayer.ExoPlayer$AudioOffloadListener;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class DefaultAudioSink$Builder {
    private AudioCapabilities audioCapabilities;

    @Nullable
    private ExoPlayer$AudioOffloadListener audioOffloadListener;
    private DefaultAudioSink.AudioOffloadSupportProvider audioOffloadSupportProvider;

    @Nullable
    private AudioProcessorChain audioProcessorChain;
    private DefaultAudioSink.AudioTrackBufferSizeProvider audioTrackBufferSizeProvider;
    private DefaultAudioSink.AudioTrackProvider audioTrackProvider;
    private boolean buildCalled;

    @Nullable
    private final Context context;
    private boolean enableAudioTrackPlaybackParams;
    private boolean enableFloatOutput;

    @Deprecated
    public DefaultAudioSink$Builder() {
        this.context = null;
        this.audioCapabilities = AudioCapabilities.DEFAULT_AUDIO_CAPABILITIES;
        this.audioTrackBufferSizeProvider = DefaultAudioSink.AudioTrackBufferSizeProvider.DEFAULT;
        this.audioTrackProvider = DefaultAudioSink.AudioTrackProvider.DEFAULT;
    }

    public DefaultAudioSink$Builder(Context context) {
        this.context = context;
        this.audioCapabilities = AudioCapabilities.DEFAULT_AUDIO_CAPABILITIES;
        this.audioTrackBufferSizeProvider = DefaultAudioSink.AudioTrackBufferSizeProvider.DEFAULT;
        this.audioTrackProvider = DefaultAudioSink.AudioTrackProvider.DEFAULT;
    }

    @CanIgnoreReturnValue
    @Deprecated
    public DefaultAudioSink$Builder setAudioCapabilities(AudioCapabilities audioCapabilities) {
        Assertions.checkNotNull(audioCapabilities);
        this.audioCapabilities = audioCapabilities;
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultAudioSink$Builder setAudioProcessors(AudioProcessor[] audioProcessorArr) {
        Assertions.checkNotNull(audioProcessorArr);
        return setAudioProcessorChain(new DefaultAudioSink.DefaultAudioProcessorChain(audioProcessorArr));
    }

    @CanIgnoreReturnValue
    public DefaultAudioSink$Builder setAudioProcessorChain(AudioProcessorChain audioProcessorChain) {
        Assertions.checkNotNull(audioProcessorChain);
        this.audioProcessorChain = audioProcessorChain;
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultAudioSink$Builder setEnableFloatOutput(boolean z) {
        this.enableFloatOutput = z;
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultAudioSink$Builder setEnableAudioTrackPlaybackParams(boolean z) {
        this.enableAudioTrackPlaybackParams = z;
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultAudioSink$Builder setAudioTrackBufferSizeProvider(DefaultAudioSink.AudioTrackBufferSizeProvider audioTrackBufferSizeProvider) {
        this.audioTrackBufferSizeProvider = audioTrackBufferSizeProvider;
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultAudioSink$Builder setAudioOffloadSupportProvider(DefaultAudioSink.AudioOffloadSupportProvider audioOffloadSupportProvider) {
        this.audioOffloadSupportProvider = audioOffloadSupportProvider;
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultAudioSink$Builder setExperimentalAudioOffloadListener(@Nullable ExoPlayer$AudioOffloadListener exoPlayer$AudioOffloadListener) {
        this.audioOffloadListener = exoPlayer$AudioOffloadListener;
        return this;
    }

    @CanIgnoreReturnValue
    public DefaultAudioSink$Builder setAudioTrackProvider(DefaultAudioSink.AudioTrackProvider audioTrackProvider) {
        this.audioTrackProvider = audioTrackProvider;
        return this;
    }

    public DefaultAudioSink build() {
        Assertions.checkState(!this.buildCalled);
        this.buildCalled = true;
        if (this.audioProcessorChain == null) {
            this.audioProcessorChain = new DefaultAudioSink.DefaultAudioProcessorChain(new AudioProcessor[0]);
        }
        if (this.audioOffloadSupportProvider == null) {
            this.audioOffloadSupportProvider = new DefaultAudioOffloadSupportProvider(this.context);
        }
        return new DefaultAudioSink(this, (DefaultAudioSink.1) null);
    }
}
