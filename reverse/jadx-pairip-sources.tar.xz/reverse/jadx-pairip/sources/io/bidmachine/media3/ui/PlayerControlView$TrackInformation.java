package io.bidmachine.media3.ui;

import io.bidmachine.media3.common.Tracks;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class PlayerControlView$TrackInformation {
    public final Tracks.Group trackGroup;
    public final int trackIndex;
    public final String trackName;

    public PlayerControlView$TrackInformation(Tracks tracks, int i, int i2, String str) {
        this.trackGroup = (Tracks.Group) tracks.getGroups().get(i);
        this.trackIndex = i2;
        this.trackName = str;
    }

    public boolean isSelected() {
        return this.trackGroup.isTrackSelected(this.trackIndex);
    }
}
