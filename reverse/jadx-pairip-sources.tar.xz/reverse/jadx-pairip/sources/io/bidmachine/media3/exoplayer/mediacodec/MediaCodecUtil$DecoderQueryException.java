package io.bidmachine.media3.exoplayer.mediacodec;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class MediaCodecUtil$DecoderQueryException extends Exception {
    private MediaCodecUtil$DecoderQueryException(Throwable th) {
        super("Failed to query underlying media codecs", th);
    }
}
