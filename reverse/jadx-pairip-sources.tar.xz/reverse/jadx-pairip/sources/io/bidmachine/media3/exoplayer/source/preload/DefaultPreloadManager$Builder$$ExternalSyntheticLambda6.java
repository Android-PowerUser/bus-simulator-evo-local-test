package io.bidmachine.media3.exoplayer.source.preload;

import com.google.common.base.Supplier;
import io.bidmachine.media3.exoplayer.RenderersFactory;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class DefaultPreloadManager$Builder$$ExternalSyntheticLambda6 implements Supplier {
    public final /* synthetic */ RenderersFactory f$0;

    public final Object get() {
        return DefaultPreloadManager.Builder.$r8$lambda$DBS_WBL_8P4FEbiv7Pz0EfueroU(this.f$0);
    }
}
