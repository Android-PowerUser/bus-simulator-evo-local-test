package io.bidmachine.media3.exoplayer.drm;

import com.google.common.util.concurrent.SettableFuture;
import io.bidmachine.media3.common.Format;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class OfflineLicenseHelper$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ OfflineLicenseHelper f$0;
    public final /* synthetic */ int f$1;
    public final /* synthetic */ byte[] f$2;
    public final /* synthetic */ SettableFuture f$3;
    public final /* synthetic */ Format f$4;

    public /* synthetic */ OfflineLicenseHelper$$ExternalSyntheticLambda0(OfflineLicenseHelper offlineLicenseHelper, int i, byte[] bArr, SettableFuture settableFuture, Format format) {
        this.f$0 = offlineLicenseHelper;
        this.f$1 = i;
        this.f$2 = bArr;
        this.f$3 = settableFuture;
        this.f$4 = format;
    }

    @Override // java.lang.Runnable
    public final void run() {
        OfflineLicenseHelper.$r8$lambda$ViMihODnILCcjU2wj7zvny1zUxI(this.f$0, this.f$1, this.f$2, this.f$3, this.f$4);
    }
}
