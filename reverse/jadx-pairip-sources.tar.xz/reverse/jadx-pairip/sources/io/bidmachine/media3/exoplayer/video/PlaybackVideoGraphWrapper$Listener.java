package io.bidmachine.media3.exoplayer.video;

import io.bidmachine.media3.common.VideoFrameProcessingException;
import io.bidmachine.media3.common.VideoSize;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface PlaybackVideoGraphWrapper$Listener {
    void onError(PlaybackVideoGraphWrapper playbackVideoGraphWrapper, VideoFrameProcessingException videoFrameProcessingException);

    void onFirstFrameRendered(PlaybackVideoGraphWrapper playbackVideoGraphWrapper);

    void onFrameDropped(PlaybackVideoGraphWrapper playbackVideoGraphWrapper);

    void onVideoSizeChanged(PlaybackVideoGraphWrapper playbackVideoGraphWrapper, VideoSize videoSize);
}
