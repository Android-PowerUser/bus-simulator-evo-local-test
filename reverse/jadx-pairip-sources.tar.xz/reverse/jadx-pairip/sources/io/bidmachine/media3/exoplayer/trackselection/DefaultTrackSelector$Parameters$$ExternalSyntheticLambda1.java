package io.bidmachine.media3.exoplayer.trackselection;

import com.google.common.base.Function;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class DefaultTrackSelector$Parameters$$ExternalSyntheticLambda1 implements Function {
    public final Object apply(Object obj) {
        return ((DefaultTrackSelector.SelectionOverride) obj).toBundle();
    }
}
