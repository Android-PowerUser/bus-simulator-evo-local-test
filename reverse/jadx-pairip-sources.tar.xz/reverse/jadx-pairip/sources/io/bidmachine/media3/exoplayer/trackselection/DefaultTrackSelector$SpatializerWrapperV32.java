package io.bidmachine.media3.exoplayer.trackselection;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.Spatializer;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.media3.exoplayer.audio.DefaultAudioSink$StreamEventCallbackV29$;
import io.bidmachine.media3.common.AudioAttributes;
import io.bidmachine.media3.common.Format;
import io.bidmachine.media3.common.audio.AudioManagerCompat;
import io.bidmachine.media3.common.util.Assertions;
import io.bidmachine.media3.common.util.Util;
import java.util.Objects;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@RequiresApi(32)
public class DefaultTrackSelector$SpatializerWrapperV32 {

    @Nullable
    private final Handler handler;

    @Nullable
    private final Spatializer.OnSpatializerStateChangedListener listener;
    private final boolean spatializationSupported;

    @Nullable
    private final Spatializer spatializer;

    public DefaultTrackSelector$SpatializerWrapperV32(@Nullable Context context, DefaultTrackSelector defaultTrackSelector) {
        AudioManager audioManager = context == null ? null : AudioManagerCompat.getAudioManager(context);
        if (audioManager == null || Util.isTv((Context) Assertions.checkNotNull(context))) {
            this.spatializer = null;
            this.spatializationSupported = false;
            this.handler = null;
            this.listener = null;
            return;
        }
        Spatializer spatializer = audioManager.getSpatializer();
        this.spatializer = spatializer;
        this.spatializationSupported = spatializer.getImmersiveAudioLevel() != 0;
        1 r0 = new 1(this, defaultTrackSelector);
        this.listener = r0;
        Handler handler = new Handler((Looper) Assertions.checkStateNotNull(Looper.myLooper()));
        this.handler = handler;
        Objects.requireNonNull(handler);
        spatializer.addOnSpatializerStateChangedListener(new DefaultAudioSink$StreamEventCallbackV29$.ExternalSyntheticLambda2(handler), r0);
    }

    public boolean isSpatializationSupported() {
        return this.spatializationSupported;
    }

    public boolean isAvailable() {
        return ((Spatializer) Assertions.checkNotNull(this.spatializer)).isAvailable();
    }

    public boolean isEnabled() {
        return ((Spatializer) Assertions.checkNotNull(this.spatializer)).isEnabled();
    }

    public boolean canBeSpatialized(AudioAttributes audioAttributes, Format format) {
        int i;
        if (Objects.equals(format.sampleMimeType, "audio/eac3-joc")) {
            i = format.channelCount;
            if (i == 16) {
                i = 12;
            }
        } else if (Objects.equals(format.sampleMimeType, "audio/iamf")) {
            i = format.channelCount;
            if (i == -1) {
                i = 6;
            }
        } else if (Objects.equals(format.sampleMimeType, "audio/ac4")) {
            i = format.channelCount;
            if (i == 18 || i == 21) {
                i = 24;
            }
        } else {
            i = format.channelCount;
        }
        int audioTrackChannelConfig = Util.getAudioTrackChannelConfig(i);
        if (audioTrackChannelConfig == 0) {
            return false;
        }
        AudioFormat.Builder channelMask = new AudioFormat.Builder().setEncoding(2).setChannelMask(audioTrackChannelConfig);
        int i2 = format.sampleRate;
        if (i2 != -1) {
            channelMask.setSampleRate(i2);
        }
        return ((Spatializer) Assertions.checkNotNull(this.spatializer)).canBeSpatialized(audioAttributes.getAudioAttributesV21().audioAttributes, channelMask.build());
    }

    public void release() {
        Spatializer.OnSpatializerStateChangedListener onSpatializerStateChangedListener;
        Spatializer spatializer = this.spatializer;
        if (spatializer == null || (onSpatializerStateChangedListener = this.listener) == null || this.handler == null) {
            return;
        }
        spatializer.removeOnSpatializerStateChangedListener(onSpatializerStateChangedListener);
        this.handler.removeCallbacksAndMessages(null);
    }
}
