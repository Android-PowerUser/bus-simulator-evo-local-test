package io.bidmachine.media3.exoplayer.audio;

import androidx.annotation.Nullable;
import io.bidmachine.media3.common.Format;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class AudioSink$InitializationException extends Exception {
    public final int audioTrackState;
    public final Format format;
    public final boolean isRecoverable;

    public AudioSink$InitializationException(String str, int i, Format format, boolean z, @Nullable Throwable th) {
        super(str, th);
        this.audioTrackState = i;
        this.isRecoverable = z;
        this.format = format;
    }

    public AudioSink$InitializationException(int i, int i2, int i3, int i4, Format format, boolean z, @Nullable Exception exc) {
        StringBuilder sb = new StringBuilder();
        sb.append("AudioTrack init failed ");
        sb.append(i);
        sb.append(" ");
        sb.append("Config(");
        sb.append(i2);
        sb.append(", ");
        sb.append(i3);
        sb.append(", ");
        sb.append(i4);
        sb.append(")");
        sb.append(" ");
        sb.append(format);
        sb.append(z ? " (recoverable)" : "");
        this(sb.toString(), i, format, z, exc);
    }
}
