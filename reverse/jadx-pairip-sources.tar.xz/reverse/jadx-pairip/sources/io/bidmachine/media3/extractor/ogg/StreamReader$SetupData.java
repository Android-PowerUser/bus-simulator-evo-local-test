package io.bidmachine.media3.extractor.ogg;

import io.bidmachine.media3.common.Format;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class StreamReader$SetupData {
    Format format;
    OggSeeker oggSeeker;

    StreamReader$SetupData() {
    }
}
