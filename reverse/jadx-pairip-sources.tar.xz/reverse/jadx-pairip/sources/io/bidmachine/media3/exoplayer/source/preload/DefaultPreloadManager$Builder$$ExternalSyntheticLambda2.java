package io.bidmachine.media3.exoplayer.source.preload;

import android.content.Context;
import io.bidmachine.media3.exoplayer.trackselection.DefaultTrackSelector;
import io.bidmachine.media3.exoplayer.trackselection.TrackSelector;
import io.bidmachine.media3.exoplayer.trackselection.TrackSelector$Factory;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class DefaultPreloadManager$Builder$$ExternalSyntheticLambda2 implements TrackSelector$Factory {
    @Override // io.bidmachine.media3.exoplayer.trackselection.TrackSelector$Factory
    public final TrackSelector createTrackSelector(Context context) {
        return new DefaultTrackSelector(context);
    }
}
