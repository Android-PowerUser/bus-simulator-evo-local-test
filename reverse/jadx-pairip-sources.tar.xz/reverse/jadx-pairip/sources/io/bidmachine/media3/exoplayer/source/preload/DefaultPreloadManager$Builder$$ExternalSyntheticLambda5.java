package io.bidmachine.media3.exoplayer.source.preload;

import com.google.common.base.Supplier;
import io.bidmachine.media3.exoplayer.source.MediaSource;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class DefaultPreloadManager$Builder$$ExternalSyntheticLambda5 implements Supplier {
    public final /* synthetic */ MediaSource.Factory f$0;

    public final Object get() {
        return DefaultPreloadManager.Builder.$r8$lambda$10zlYm5jeL_5G0PF_kX3gWojvmU(this.f$0);
    }
}
