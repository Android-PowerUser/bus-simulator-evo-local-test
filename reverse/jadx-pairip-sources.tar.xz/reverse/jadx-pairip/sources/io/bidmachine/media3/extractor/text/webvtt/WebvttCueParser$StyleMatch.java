package io.bidmachine.media3.extractor.text.webvtt;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class WebvttCueParser$StyleMatch implements Comparable<WebvttCueParser$StyleMatch> {
    public final int score;
    public final WebvttCssStyle style;

    public WebvttCueParser$StyleMatch(int i, WebvttCssStyle webvttCssStyle) {
        this.score = i;
        this.style = webvttCssStyle;
    }

    @Override // java.lang.Comparable
    public int compareTo(WebvttCueParser$StyleMatch webvttCueParser$StyleMatch) {
        return Integer.compare(this.score, webvttCueParser$StyleMatch.score);
    }
}
