package io.bidmachine.media3.exoplayer.offline;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import androidx.core.view.accessibility.AccessibilityEventCompat;
import io.bidmachine.media3.common.Timeline;
import io.bidmachine.media3.common.util.Util;
import io.bidmachine.media3.datasource.TransferListener;
import io.bidmachine.media3.exoplayer.ExoPlaybackException;
import io.bidmachine.media3.exoplayer.LoadingInfo;
import io.bidmachine.media3.exoplayer.analytics.PlayerId;
import io.bidmachine.media3.exoplayer.source.MediaPeriod;
import io.bidmachine.media3.exoplayer.source.MediaSource;
import io.bidmachine.media3.exoplayer.upstream.Allocator;
import io.bidmachine.media3.exoplayer.upstream.DefaultAllocator;
import java.io.IOException;
import java.util.ArrayList;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class DownloadHelper$MediaPreparer implements MediaSource.MediaSourceCaller, MediaPeriod.Callback, Handler.Callback {
    private static final int DOWNLOAD_HELPER_CALLBACK_MESSAGE_FAILED = 2;
    private static final int DOWNLOAD_HELPER_CALLBACK_MESSAGE_PREPARED = 1;
    private static final int MESSAGE_CHECK_FOR_FAILURE = 2;
    private static final int MESSAGE_CONTINUE_LOADING = 3;
    private static final int MESSAGE_PREPARE_SOURCE = 1;
    private static final int MESSAGE_RELEASE = 4;
    private final DownloadHelper downloadHelper;
    public MediaPeriod[] mediaPeriods;
    private final MediaSource mediaSource;
    private final Handler mediaSourceHandler;
    private final HandlerThread mediaSourceThread;
    private boolean released;
    public Timeline timeline;
    private final Allocator allocator = new DefaultAllocator(true, AccessibilityEventCompat.TYPE_VIEW_ACCESSIBILITY_FOCUS_CLEARED);
    private final ArrayList<MediaPeriod> pendingMediaPeriods = new ArrayList<>();
    private final Handler downloadHelperHandler = Util.createHandlerForCurrentOrMainLooper(new DownloadHelper$MediaPreparer$.ExternalSyntheticLambda0(this));

    public DownloadHelper$MediaPreparer(MediaSource mediaSource, DownloadHelper downloadHelper) {
        this.mediaSource = mediaSource;
        this.downloadHelper = downloadHelper;
        HandlerThread handlerThread = new HandlerThread("ExoPlayer:DownloadHelper");
        this.mediaSourceThread = handlerThread;
        handlerThread.start();
        Handler handlerCreateHandler = Util.createHandler(handlerThread.getLooper(), this);
        this.mediaSourceHandler = handlerCreateHandler;
        handlerCreateHandler.sendEmptyMessage(1);
    }

    public void release() {
        if (this.released) {
            return;
        }
        this.released = true;
        this.mediaSourceHandler.sendEmptyMessage(4);
    }

    @Override // android.os.Handler.Callback
    public boolean handleMessage(Message message) {
        int i = message.what;
        if (i == 1) {
            this.mediaSource.prepareSource(this, (TransferListener) null, PlayerId.UNSET);
            this.mediaSourceHandler.sendEmptyMessage(2);
            return true;
        }
        int i2 = 0;
        if (i == 2) {
            try {
                if (this.mediaPeriods == null) {
                    this.mediaSource.maybeThrowSourceInfoRefreshError();
                } else {
                    while (i2 < this.pendingMediaPeriods.size()) {
                        this.pendingMediaPeriods.get(i2).maybeThrowPrepareError();
                        i2++;
                    }
                }
                this.mediaSourceHandler.sendEmptyMessageDelayed(2, 100L);
            } catch (IOException e) {
                this.downloadHelperHandler.obtainMessage(2, e).sendToTarget();
            }
            return true;
        }
        if (i == 3) {
            MediaPeriod mediaPeriod = (MediaPeriod) message.obj;
            if (this.pendingMediaPeriods.contains(mediaPeriod)) {
                mediaPeriod.continueLoading(new LoadingInfo.Builder().setPlaybackPositionUs(0L).build());
            }
            return true;
        }
        if (i != 4) {
            return false;
        }
        MediaPeriod[] mediaPeriodArr = this.mediaPeriods;
        if (mediaPeriodArr != null) {
            int length = mediaPeriodArr.length;
            while (i2 < length) {
                this.mediaSource.releasePeriod(mediaPeriodArr[i2]);
                i2++;
            }
        }
        this.mediaSource.releaseSource(this);
        this.mediaSourceHandler.removeCallbacksAndMessages(null);
        this.mediaSourceThread.quit();
        return true;
    }

    public void onSourceInfoRefreshed(MediaSource mediaSource, Timeline timeline) {
        MediaPeriod[] mediaPeriodArr;
        if (this.timeline != null) {
            return;
        }
        if (timeline.getWindow(0, new Timeline.Window()).isLive()) {
            this.downloadHelperHandler.obtainMessage(2, new DownloadHelper.LiveContentUnsupportedException()).sendToTarget();
            return;
        }
        this.timeline = timeline;
        this.mediaPeriods = new MediaPeriod[timeline.getPeriodCount()];
        int i = 0;
        while (true) {
            mediaPeriodArr = this.mediaPeriods;
            if (i >= mediaPeriodArr.length) {
                break;
            }
            MediaPeriod mediaPeriodCreatePeriod = this.mediaSource.createPeriod(new MediaSource.MediaPeriodId(timeline.getUidOfPeriod(i)), this.allocator, 0L);
            this.mediaPeriods[i] = mediaPeriodCreatePeriod;
            this.pendingMediaPeriods.add(mediaPeriodCreatePeriod);
            i++;
        }
        for (MediaPeriod mediaPeriod : mediaPeriodArr) {
            mediaPeriod.prepare(this, 0L);
        }
    }

    public void onPrepared(MediaPeriod mediaPeriod) {
        this.pendingMediaPeriods.remove(mediaPeriod);
        if (this.pendingMediaPeriods.isEmpty()) {
            this.mediaSourceHandler.removeMessages(2);
            this.downloadHelperHandler.sendEmptyMessage(1);
        }
    }

    public void onContinueLoadingRequested(MediaPeriod mediaPeriod) {
        if (this.pendingMediaPeriods.contains(mediaPeriod)) {
            this.mediaSourceHandler.obtainMessage(3, mediaPeriod).sendToTarget();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean handleDownloadHelperCallbackMessage(Message message) {
        if (this.released) {
            return false;
        }
        int i = message.what;
        if (i == 1) {
            try {
                DownloadHelper.access$300(this.downloadHelper);
            } catch (ExoPlaybackException e) {
                this.downloadHelperHandler.obtainMessage(2, new IOException((Throwable) e)).sendToTarget();
            }
            return true;
        }
        if (i != 2) {
            return false;
        }
        release();
        DownloadHelper.access$400(this.downloadHelper, (IOException) Util.castNonNull(message.obj));
        return true;
    }
}
