package io.bidmachine.media3.exoplayer.dash;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class PlayerEmsgHandler$ManifestExpiryEventInfo {
    public final long eventTimeUs;
    public final long manifestPublishTimeMsInEmsg;

    public PlayerEmsgHandler$ManifestExpiryEventInfo(long j, long j2) {
        this.eventTimeUs = j;
        this.manifestPublishTimeMsInEmsg = j2;
    }
}
