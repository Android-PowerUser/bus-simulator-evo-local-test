package io.bidmachine.media3.exoplayer.source.preload;

import android.content.Context;
import com.google.common.base.Supplier;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class DefaultPreloadManager$Builder$$ExternalSyntheticLambda1 implements Supplier {
    public final /* synthetic */ Context f$0;

    public final Object get() {
        return DefaultPreloadManager.Builder.$r8$lambda$q8C42rKY4W0A-b3i1meyq55QEV8(this.f$0);
    }
}
