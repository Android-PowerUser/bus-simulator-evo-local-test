package io.bidmachine.media3.common.util;

import java.lang.ref.WeakReference;
import java.util.concurrent.Executor;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class NetworkTypeObserver$ListenerHolder {
    private final Executor executor;
    private final WeakReference<NetworkTypeObserver.Listener> listener;
    final /* synthetic */ NetworkTypeObserver this$0;

    public NetworkTypeObserver$ListenerHolder(NetworkTypeObserver networkTypeObserver, NetworkTypeObserver.Listener listener, Executor executor) {
        this.this$0 = networkTypeObserver;
        this.listener = new WeakReference<>(listener);
        this.executor = executor;
    }

    public boolean canBeRemoved() {
        return this.listener.get() == null;
    }

    public void callOnNetworkTypeChanged() {
        this.executor.execute(new NetworkTypeObserver$ListenerHolder$.ExternalSyntheticLambda0(this));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$callOnNetworkTypeChanged$0() {
        NetworkTypeObserver.Listener listener = this.listener.get();
        if (listener != null) {
            listener.onNetworkTypeChanged(this.this$0.getNetworkType());
        }
    }
}
