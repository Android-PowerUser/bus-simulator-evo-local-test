package io.bidmachine.media3.ui;

import android.app.PendingIntent;
import android.graphics.Bitmap;
import androidx.annotation.Nullable;
import io.bidmachine.media3.common.Player;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface PlayerNotificationManager$MediaDescriptionAdapter {
    @Nullable
    PendingIntent createCurrentContentIntent(Player player);

    @Nullable
    CharSequence getCurrentContentText(Player player);

    CharSequence getCurrentContentTitle(Player player);

    @Nullable
    Bitmap getCurrentLargeIcon(Player player, PlayerNotificationManager.BitmapCallback bitmapCallback);

    @Nullable
    default CharSequence getCurrentSubText(Player player) {
        return null;
    }
}
