package io.bidmachine.media3.exoplayer.upstream;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final class Loader$ReleaseTask implements Runnable {
    private final Loader.ReleaseCallback callback;

    public Loader$ReleaseTask(Loader.ReleaseCallback releaseCallback) {
        this.callback = releaseCallback;
    }

    @Override // java.lang.Runnable
    public void run() {
        this.callback.onLoaderReleased();
    }
}
