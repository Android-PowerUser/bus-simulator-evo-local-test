package io.bidmachine.media3.exoplayer.audio;

import android.media.AudioTrack;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import io.bidmachine.media3.common.util.Util;
import java.math.RoundingMode;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@RequiresApi(23)
public final class DefaultAudioSink$Api23 {
    private DefaultAudioSink$Api23() {
    }

    public static void setPreferredDeviceOnAudioTrack(AudioTrack audioTrack, @Nullable AudioDeviceInfoApi23 audioDeviceInfoApi23) {
        audioTrack.setPreferredDevice(audioDeviceInfoApi23 == null ? null : audioDeviceInfoApi23.audioDeviceInfo);
    }

    public static long getAudioTrackBufferSizeUs(AudioTrack audioTrack, DefaultAudioSink.Configuration configuration) {
        if (configuration.outputMode == 0) {
            return configuration.framesToDurationUs(audioTrack.getBufferSizeInFrames());
        }
        return Util.scaleLargeValue(audioTrack.getBufferSizeInFrames(), 1000000L, DefaultAudioTrackBufferSizeProvider.getMaximumEncodedRateBytesPerSecond(configuration.outputEncoding), RoundingMode.DOWN);
    }
}
