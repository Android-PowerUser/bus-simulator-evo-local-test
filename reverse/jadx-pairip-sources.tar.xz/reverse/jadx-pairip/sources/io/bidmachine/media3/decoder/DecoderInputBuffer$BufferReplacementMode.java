package io.bidmachine.media3.decoder;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Target({ElementType.TYPE_USE})
@Documented
@Retention(RetentionPolicy.SOURCE)
public @interface DecoderInputBuffer$BufferReplacementMode {
}
