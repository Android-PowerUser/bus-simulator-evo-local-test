package io.bidmachine.displays;

import io.bidmachine.LabelData;
import io.bidmachine.util.Executable;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class NativeAdObjectParams$$ExternalSyntheticLambda0 implements Executable {
    public final /* synthetic */ NativeAdObjectParams f$0;

    public final void execute(Object obj) {
        NativeAdObjectParams.$r8$lambda$0J3LyVjFVndoGP69KHPEgi7b3lk(this.f$0, (LabelData) obj);
    }
}
