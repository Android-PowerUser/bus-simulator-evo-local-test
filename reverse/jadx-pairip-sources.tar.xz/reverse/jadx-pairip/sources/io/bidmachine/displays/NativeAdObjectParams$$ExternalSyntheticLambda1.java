package io.bidmachine.displays;

import io.bidmachine.PrivacySheetData;
import io.bidmachine.util.Executable;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class NativeAdObjectParams$$ExternalSyntheticLambda1 implements Executable {
    public final /* synthetic */ NativeAdObjectParams f$0;

    public final void execute(Object obj) {
        NativeAdObjectParams.$r8$lambda$GBzayXc_7gMyY2vmnR6_jBbQjec(this.f$0, (PrivacySheetData) obj);
    }
}
