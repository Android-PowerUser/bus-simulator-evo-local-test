package io.bidmachine.displays;

import androidx.annotation.NonNull;
import com.explorestack.protobuf.adcom.Ad;
import io.bidmachine.models.AdObjectParams;
import io.bidmachine.protobuf.headerbidding.HeaderBiddingAd;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
class HeaderBiddingAdObjectParams extends AdObjectParams {
    @Override // io.bidmachine.models.AdObjectParams
    public boolean isValid() {
        return true;
    }

    HeaderBiddingAdObjectParams(@NonNull Ad ad, @NonNull HeaderBiddingAd headerBiddingAd) {
        super(ad);
        getData().putAll(headerBiddingAd.getClientParamsMap());
        getData().putAll(headerBiddingAd.getServerParamsMap());
    }
}
