package io.bidmachine.displays.mapper;

import com.explorestack.protobuf.adcom.NativeAssetPosition;
import io.bidmachine.PositionData;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: PositionDataMapper.kt */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0000\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u0006¨\u0006\u0007"}, d2 = {"Lio/bidmachine/displays/mapper/PositionDataMapper;", "", "()V", "map", "Lio/bidmachine/PositionData;", "data", "Lcom/explorestack/protobuf/adcom/NativeAssetPosition;", "bidmachine-android-sdk_bh_3_5_1"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class PositionDataMapper {
    @Nullable
    public final PositionData map(@NotNull NativeAssetPosition data) {
        PositionData positionData;
        Intrinsics.checkNotNullParameter(data, "data");
        try {
            int i = WhenMappings.$EnumSwitchMapping$0[data.ordinal()];
            if (i == 1) {
                positionData = PositionData.TopLeft;
            } else if (i == 2) {
                positionData = PositionData.TopRight;
            } else if (i == 3) {
                positionData = PositionData.BottomLeft;
            } else {
                if (i != 4) {
                    return null;
                }
                positionData = PositionData.BottomRight;
            }
            return positionData;
        } catch (Throwable unused) {
            return null;
        }
    }
}
