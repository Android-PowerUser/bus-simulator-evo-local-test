package io.bidmachine.displays;

import io.bidmachine.CustomParams;
import io.bidmachine.Executable;
import io.bidmachine.protobuf.sdk.Placement;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class PlacementBuilder$$ExternalSyntheticLambda0 implements Executable {
    public final /* synthetic */ Placement.Builder f$0;

    public final void execute(Object obj) {
        PlacementBuilder.$r8$lambda$PKz7T509Mbe4-1a6Yx1rbi15wXc(this.f$0, (CustomParams) obj);
    }
}
