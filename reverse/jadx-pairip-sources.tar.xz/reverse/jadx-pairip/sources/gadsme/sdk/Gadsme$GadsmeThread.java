package gadsme.sdk;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class Gadsme$GadsmeThread extends Thread {
    private static native void nativeThreadLoop();

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        nativeThreadLoop();
    }
}
