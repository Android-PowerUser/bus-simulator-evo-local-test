package gadsme.sdk;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class Gadsme$AudioAdStatus {
    public static final int AnotherAudioAdActive = -6;
    public static final int FinishedComplete = 4;
    public static final int FinishedIncomplete = -9;
    public static final int InvalidData = -3;
    public static final int Loading = 1;
    public static final int MissingAudioPlacement = -7;
    public static final int NetworkError = -2;
    public static final int NoAd = -8;
    public static final int None = 0;
    public static final int Playing = 3;
    public static final int PlayingWithVolumeTooLowOrMuted = -5;
    public static final int ReadyToPlay = 2;
    public static final int Stopped = -11;
    public static final int UnknownError = -1;
    public static final int VolumeTooLowOrMuted = -4;
    public static final int VolumeUnresolved = -10;
}
