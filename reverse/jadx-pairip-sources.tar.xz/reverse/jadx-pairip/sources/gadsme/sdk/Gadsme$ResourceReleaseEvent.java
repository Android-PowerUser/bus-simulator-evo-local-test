package gadsme.sdk;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class Gadsme$ResourceReleaseEvent {
    public final int kind;
    public final int resourceId;

    private Gadsme$ResourceReleaseEvent(int i, int i2) {
        this.resourceId = i;
        this.kind = i2;
    }
}
