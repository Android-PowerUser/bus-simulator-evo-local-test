package gadsme.sdk;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public interface Gadsme$OnResourceInitHandler {
    void onResourceInit(Gadsme.ResourceInitEvent resourceInitEvent);
}
