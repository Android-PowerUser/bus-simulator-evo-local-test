package gadsme.support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_Image$4$1 implements Runnable {
    final /* synthetic */ bind_Image.4 this$0;
    final /* synthetic */ String val$warning_jni_;

    public bind_Image$4$1(bind_Image.4 r1, String str) {
        this.this$0 = r1;
        this.val$warning_jni_ = str;
    }

    @Override // java.lang.Runnable
    public void run() {
        bind_Image.callN_StringVoid(this.this$0.val$onWarning_java_hobj_.address, this.val$warning_jni_);
    }
}
