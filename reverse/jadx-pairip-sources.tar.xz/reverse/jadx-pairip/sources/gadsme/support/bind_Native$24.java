package gadsme.support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_Native$24 implements Runnable {
    final /* synthetic */ String val$GADSME_SDK_VERSION;

    public bind_Native$24(String str) {
        this.val$GADSME_SDK_VERSION = str;
    }

    @Override // java.lang.Runnable
    public void run() {
        bind_Native.setGADSME_SDK_VERSION(this.val$GADSME_SDK_VERSION);
    }
}
