package gadsme.support;

import android.app.Activity;
import android.graphics.Bitmap;
import android.webkit.WebView;
import gadsme.bind.Support;
import gadsme.support.resource.Resource;
import gadsme.support.webview.WebResource;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class Web {
    public static void captureHtml(int i, String str) {
        WebResource resource = Resource.getInstance(i);
        if (resource != null) {
            resource.captureHtml(str);
        }
    }

    public static void click(int i, double d, double d2) {
        WebResource resource = Resource.getInstance(i);
        if (resource != null) {
            resource.click((int) Math.round(((double) resource.getContentWidth()) * d), (int) Math.round(((double) resource.getContentHeight()) * d2));
        }
    }

    public static void load(int i, String str, String str2, boolean z, int i2, int i3, int i4, int i5, int i6, Support.Func0<Void> func0, Support.Func3<Integer, Integer, Integer, Void> func3, Support.Func1<String, Void> func1, Support.Func1<String, Void> func2, Support.Func0<Void> func4, Support.Func1<String, Void> func5, Support.Func2<String, Integer, Void> func6, Support.Func1<String, Void> func7) {
        WebResource webResource;
        WebResource resource = Resource.getInstance(i);
        if (resource == null) {
            webResource = new WebResource(i, (Activity) Support.getContext(), z, i2, i3, -1.0d);
        } else {
            if (resource.getWidth() != i2 || resource.getHeight() != i3) {
                throw new RuntimeException("Requesting a texture size different from the initial call for the same resource id: " + i);
            }
            webResource = null;
        }
        if (resource == null) {
            resource = webResource;
        }
        if (webResource != null) {
            Bitmap.Config config = Bitmap.Config.RGB_565;
            if (i6 != 1) {
                config = Bitmap.Config.ARGB_8888;
            }
            webResource.initBitmap(config, i6);
            webResource.requestBitmapRender();
        }
        resource.load(str, str2, i4, i5, new 1(func0, func3, resource, func1, func2, func5, func6, func4, func7));
    }

    public static void release(int i, Support.Func2<Boolean, String, Void> func2) {
        WebResource resource = Resource.getInstance(i);
        if (resource == null) {
            func2.run(Boolean.FALSE, "No web resource to release associated with resource id #" + i);
            return;
        }
        try {
            resource.destroy();
            func2.run(Boolean.TRUE, (Object) null);
        } catch (Throwable th) {
            th.printStackTrace();
            func2.run(Boolean.FALSE, "Failed to release web resource #" + i + ": " + th);
        }
    }

    public static void requestBitmapRender(int i) {
        WebResource resource = Resource.getInstance(i);
        if (resource != null) {
            resource.requestBitmapRender();
        }
    }

    public static void setGadsmeBridgeJs(String str) {
        WebResource.setGadsmeBridgeJavascript(str);
    }

    public static void setGadsmeBridgeJsAddon(String str) {
        WebResource.setGadsmeBridgeJavascriptAddon(str);
    }

    public static void setHtmlCaptureEnabled(boolean z) {
        WebResource.setHtmlCaptureEnabled(z);
    }

    public static void setRenderMode(int i) {
        WebResource.setRenderMode(i);
    }

    public static void setVisibility(int i, double d, double d2, double d3) {
        WebResource resource = Resource.getInstance(i);
        if (resource != null) {
            resource.mraidSetExposure((1.0f - ((float) d3)) * 100.0f);
        }
    }

    public static void testWebviewAvailability(Support.Func1<Boolean, Void> func1) {
        try {
            new WebView((Activity) Support.getContext()).destroy();
            func1.run(Boolean.TRUE);
        } catch (Exception unused) {
            func1.run(Boolean.FALSE);
        }
    }
}
