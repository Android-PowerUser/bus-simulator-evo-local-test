package gadsme.support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_Web$12 implements Runnable {
    final /* synthetic */ String val$captureId;
    final /* synthetic */ int val$resourceId;

    public bind_Web$12(int i, String str) {
        this.val$resourceId = i;
        this.val$captureId = str;
    }

    @Override // java.lang.Runnable
    public void run() {
        bind_Web.captureHtml(this.val$resourceId, this.val$captureId);
    }
}
