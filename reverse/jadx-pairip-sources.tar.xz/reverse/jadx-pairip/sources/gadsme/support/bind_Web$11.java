package gadsme.support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_Web$11 implements Runnable {
    final /* synthetic */ int val$enabled;

    public bind_Web$11(int i) {
        this.val$enabled = i;
    }

    @Override // java.lang.Runnable
    public void run() {
        bind_Web.setHtmlCaptureEnabled(this.val$enabled);
    }
}
