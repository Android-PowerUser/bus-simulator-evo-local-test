package gadsme.support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_Web$18 implements Runnable {
    final /* synthetic */ String val$gadsmeBridgeJs;

    public bind_Web$18(String str) {
        this.val$gadsmeBridgeJs = str;
    }

    @Override // java.lang.Runnable
    public void run() {
        bind_Web.setGadsmeBridgeJs(this.val$gadsmeBridgeJs);
    }
}
