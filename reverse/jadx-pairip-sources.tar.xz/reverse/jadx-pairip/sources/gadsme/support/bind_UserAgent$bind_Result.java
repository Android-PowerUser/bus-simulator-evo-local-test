package gadsme.support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_UserAgent$bind_Result {
    Object value = null;

    private bind_UserAgent$bind_Result() {
    }
}
