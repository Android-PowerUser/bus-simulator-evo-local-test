package gadsme.support;

import gadsme.bind.Support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_Native$12 implements Support.Func1<String, Void> {
    final /* synthetic */ Support.HObject val$callback_java_hobj_;

    public bind_Native$12(Support.HObject hObject) {
        this.val$callback_java_hobj_ = hObject;
    }

    public Void run(String str) {
        Support.runInNativeThread(new 1(this, str));
        return null;
    }
}
