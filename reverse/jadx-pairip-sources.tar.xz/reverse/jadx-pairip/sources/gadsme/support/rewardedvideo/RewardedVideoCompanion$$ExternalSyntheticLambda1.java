package gadsme.support.rewardedvideo;

import android.graphics.Bitmap;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class RewardedVideoCompanion$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ RewardedVideoCompanion f$0;
    public final /* synthetic */ Bitmap f$1;

    public /* synthetic */ RewardedVideoCompanion$$ExternalSyntheticLambda1(RewardedVideoCompanion rewardedVideoCompanion, Bitmap bitmap) {
        this.f$0 = rewardedVideoCompanion;
        this.f$1 = bitmap;
    }

    @Override // java.lang.Runnable
    public final void run() {
        RewardedVideoCompanion.$r8$lambda$YcuIvZFceKnSfU_EElkebb3bCbY(this.f$0, this.f$1);
    }
}
