package gadsme.support.rewardedvideo;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class RewardedVideoCompanion$$ExternalSyntheticLambda2 implements Runnable {
    public final /* synthetic */ RewardedVideoCompanion f$0;

    @Override // java.lang.Runnable
    public final void run() {
        RewardedVideoCompanion.$r8$lambda$aJmnP-n0JwyUhvYF_IRB3DHs_UE(this.f$0);
    }
}
