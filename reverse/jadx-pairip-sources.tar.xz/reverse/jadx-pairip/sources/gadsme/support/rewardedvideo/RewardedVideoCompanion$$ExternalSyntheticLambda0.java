package gadsme.support.rewardedvideo;

import android.view.View;

/* JADX INFO: compiled from: R8$$SyntheticClass */
/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public final /* synthetic */ class RewardedVideoCompanion$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ RewardedVideoCompanion f$0;

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        RewardedVideoCompanion.$r8$lambda$dFAmWFC6vmPu2_mvG9YSEOabG0U(this.f$0, view);
    }
}
