package gadsme.support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_Web$13 implements Runnable {
    final /* synthetic */ double val$relativeX;
    final /* synthetic */ double val$relativeY;
    final /* synthetic */ int val$resourceId;

    public bind_Web$13(int i, double d, double d2) {
        this.val$resourceId = i;
        this.val$relativeX = d;
        this.val$relativeY = d2;
    }

    @Override // java.lang.Runnable
    public void run() {
        bind_Web.click(this.val$resourceId, this.val$relativeX, this.val$relativeY);
    }
}
