package gadsme.support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_RewardedVideo$7$1 implements Runnable {
    final /* synthetic */ bind_RewardedVideo.7 this$0;
    final /* synthetic */ String val$warning_jni_;

    public bind_RewardedVideo$7$1(bind_RewardedVideo.7 r1, String str) {
        this.this$0 = r1;
        this.val$warning_jni_ = str;
    }

    @Override // java.lang.Runnable
    public void run() {
        bind_RewardedVideo.callN_StringVoid(this.this$0.val$onWarning_java_hobj_.address, this.val$warning_jni_);
    }
}
