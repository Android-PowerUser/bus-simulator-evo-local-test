package gadsme.support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_Video$3$1 implements Runnable {
    final /* synthetic */ bind_Video.3 this$0;
    final /* synthetic */ int val$bitmapFormat_jni_;
    final /* synthetic */ int val$height_jni_;
    final /* synthetic */ int val$width_jni_;

    public bind_Video$3$1(bind_Video.3 r1, int i, int i2, int i3) {
        this.this$0 = r1;
        this.val$bitmapFormat_jni_ = i;
        this.val$width_jni_ = i2;
        this.val$height_jni_ = i3;
    }

    @Override // java.lang.Runnable
    public void run() {
        bind_Video.callN_IntegerIntegerIntegerVoid(this.this$0.val$onBitmapReady_java_hobj_.address, this.val$bitmapFormat_jni_, this.val$width_jni_, this.val$height_jni_);
    }
}
