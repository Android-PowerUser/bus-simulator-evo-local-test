package gadsme.support;

import android.graphics.Bitmap;
import gadsme.bind.Support;
import gadsme.support.video.VideoResource;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class Video$1 implements VideoResource.Listener {
    final /* synthetic */ Support.Func3 val$onBitmapReady;
    final /* synthetic */ Support.Func2 val$onError;
    final /* synthetic */ Support.Func4 val$onProgress;
    final /* synthetic */ Support.Func1 val$onWarning;
    final /* synthetic */ VideoResource val$videoResource;

    public Video$1(Support.Func4 func4, Support.Func3 func3, VideoResource videoResource, Support.Func2 func2, Support.Func1 func1) {
        this.val$onProgress = func4;
        this.val$onBitmapReady = func3;
        this.val$videoResource = videoResource;
        this.val$onError = func2;
        this.val$onWarning = func1;
    }

    public void onBitmapReady(Bitmap.Config config, int i, int i2) {
        this.val$onBitmapReady.run(Integer.valueOf(this.val$videoResource.getTargetBitmapFormat()), Integer.valueOf(i), Integer.valueOf(i2));
    }

    public void onError(String str, int i) {
        this.val$onError.run(str, Integer.valueOf(i));
    }

    public void onProgress(boolean z, boolean z2, double d, double d2) {
        this.val$onProgress.run(Boolean.valueOf(z), Boolean.valueOf(z2), Double.valueOf(d), Double.valueOf(d2));
    }

    public void onReset() {
    }

    public void onWarning(String str) {
        this.val$onWarning.run(str);
    }
}
