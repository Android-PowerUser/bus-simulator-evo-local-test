package gadsme.support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_Web$19 implements Runnable {
    final /* synthetic */ String val$gadsmeBridgeJsAddon;

    public bind_Web$19(String str) {
        this.val$gadsmeBridgeJsAddon = str;
    }

    @Override // java.lang.Runnable
    public void run() {
        bind_Web.setGadsmeBridgeJsAddon(this.val$gadsmeBridgeJsAddon);
    }
}
