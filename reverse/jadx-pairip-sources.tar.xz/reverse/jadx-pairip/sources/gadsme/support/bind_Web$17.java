package gadsme.support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_Web$17 implements Runnable {
    final /* synthetic */ double val$angle;
    final /* synthetic */ double val$occlusion;
    final /* synthetic */ int val$resourceId;
    final /* synthetic */ double val$size;

    public bind_Web$17(int i, double d, double d2, double d3) {
        this.val$resourceId = i;
        this.val$size = d;
        this.val$angle = d2;
        this.val$occlusion = d3;
    }

    @Override // java.lang.Runnable
    public void run() {
        bind_Web.setVisibility(this.val$resourceId, this.val$size, this.val$angle, this.val$occlusion);
    }
}
