package gadsme.support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_Web$16 implements Runnable {
    final /* synthetic */ int val$resourceId;

    public bind_Web$16(int i) {
        this.val$resourceId = i;
    }

    @Override // java.lang.Runnable
    public void run() {
        bind_Web.requestBitmapRender(this.val$resourceId);
    }
}
