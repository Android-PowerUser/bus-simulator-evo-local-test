package gadsme.support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_Native$13 implements Runnable {
    final /* synthetic */ String val$callback;

    public bind_Native$13(String str) {
        this.val$callback = str;
    }

    @Override // java.lang.Runnable
    public void run() {
        bind_Native.requestDeviceChipset(this.val$callback);
    }
}
