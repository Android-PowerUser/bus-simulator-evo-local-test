package gadsme.support.audio;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class AudioResource$6$1 implements Runnable {
    final /* synthetic */ AudioResource.6 this$1;
    final /* synthetic */ int val$extra;
    final /* synthetic */ int val$what;

    public AudioResource$6$1(AudioResource.6 r1, int i, int i2) {
        this.this$1 = r1;
        this.val$what = i;
        this.val$extra = i2;
    }

    @Override // java.lang.Runnable
    public void run() {
        AudioResource.access$1002(this.this$1.this$0, false);
        if (AudioResource.access$900(this.this$1.this$0) != null) {
            AudioResource.access$900(this.this$1.this$0).onError("Error in media player with url: " + AudioResource.access$1300(this.this$1.this$0) + " / " + this.val$what + " / " + this.val$extra, this.val$what == 100 ? 1 : 2);
        }
    }
}
