package gadsme.support;

import gadsme.bind.Support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_Native$23 implements Runnable {
    final /* synthetic */ Support.BindResult val$_bind_result;

    public bind_Native$23(Support.BindResult bindResult) {
        this.val$_bind_result = bindResult;
    }

    @Override // java.lang.Runnable
    public void run() {
        synchronized (this.val$_bind_result) {
            try {
                this.val$_bind_result.value = bind_Native.getGADSME_SDK_VERSION();
            } catch (Throwable th) {
                th.printStackTrace();
            }
            Support.BindResult bindResult = this.val$_bind_result;
            bindResult.resolved = true;
            bindResult.notifyAll();
        }
    }
}
