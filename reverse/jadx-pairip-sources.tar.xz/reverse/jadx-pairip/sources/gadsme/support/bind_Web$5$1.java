package gadsme.support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_Web$5$1 implements Runnable {
    final /* synthetic */ bind_Web.5 this$0;
    final /* synthetic */ String val$url_jni_;

    public bind_Web$5$1(bind_Web.5 r1, String str) {
        this.this$0 = r1;
        this.val$url_jni_ = str;
    }

    @Override // java.lang.Runnable
    public void run() {
        bind_Web.callN_StringVoid(this.this$0.val$onPageClick_java_hobj_.address, this.val$url_jni_);
    }
}
