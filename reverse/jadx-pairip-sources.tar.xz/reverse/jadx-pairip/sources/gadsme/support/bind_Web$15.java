package gadsme.support;

import gadsme.bind.Support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_Web$15 implements Support.Func2<Boolean, String, Void> {
    final /* synthetic */ Support.HObject val$callback_java_hobj_;

    public bind_Web$15(Support.HObject hObject) {
        this.val$callback_java_hobj_ = hObject;
    }

    public Void run(Boolean bool, String str) {
        Support.runInNativeThread(new 1(this, bool.booleanValue() ? 1 : 0, str));
        return null;
    }
}
