package gadsme.support;

import gadsme.bind.Support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_Native$20 implements Support.Func4<Integer, Integer, Integer, Integer, Void> {
    final /* synthetic */ Support.HObject val$callback_java_hobj_;

    public bind_Native$20(Support.HObject hObject) {
        this.val$callback_java_hobj_ = hObject;
    }

    public Void run(Integer num, Integer num2, Integer num3, Integer num4) {
        Support.runInNativeThread(new 1(this, num.intValue(), num2.intValue(), num3.intValue(), num4.intValue()));
        return null;
    }
}
