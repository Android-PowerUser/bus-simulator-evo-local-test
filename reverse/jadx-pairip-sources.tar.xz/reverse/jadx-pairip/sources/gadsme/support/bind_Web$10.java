package gadsme.support;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public class bind_Web$10 implements Runnable {
    final /* synthetic */ int val$mode;

    public bind_Web$10(int i) {
        this.val$mode = i;
    }

    @Override // java.lang.Runnable
    public void run() {
        bind_Web.setRenderMode(this.val$mode);
    }
}
