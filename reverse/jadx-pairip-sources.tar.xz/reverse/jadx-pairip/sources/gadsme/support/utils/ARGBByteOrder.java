package gadsme.support.utils;

/* JADX INFO: loaded from: /home/user/bus-simulator-evo-local-test/reverse/extracted/stock/classes10.dex */
public enum ARGBByteOrder {
    ARGB,
    RGBA,
    BGRA,
    ABGR
}
